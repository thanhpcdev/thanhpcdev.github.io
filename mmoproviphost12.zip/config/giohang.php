<?php
session_start();

class Cart {
    private $items = array();

    public function __construct() {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = array();
        }
        $this->items = $_SESSION['cart'];
    }
    public function addToCart($id, $price, $name, $image) {
    if (isset($this->items[$id])) {
        return false;
    }
    else {
        $this->items[$id] = array('price' => $price, 'name' => $name, 'image' => $image, 'quantity' => 1);
        $_SESSION['cart'] = $this->items;
        return true;
    }
}
public function getTotal() {
        $total = 0;
        foreach ($this->items as $item) {
            $total += $item['price'] * $item['quantity'];
        }
        return $total;
}
public function getTotalQuantity() {
    return count($this->items);
}
public function getUniqueItemCount() {
    return count($this->items);
    }
}
?>
