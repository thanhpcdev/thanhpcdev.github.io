<?php
require_once "../../config/config.php";
require_once "../../config/function.php";

if($_GET)
{
    $pin            = check_string($_GET['code']);
    $seri           = check_string($_GET['serial']);
    $randid         = check_string($_GET['request_id']);
    $status         = check_string($_GET['status']);
    $data           = $NHNTAK->get_row(" SELECT * FROM `cards` WHERE `requestid` = '$randid' AND `pin` = '$pin' AND `seri` = '$seri' AND `status` = 'xuly'");
    if($data)
    {
        $sotien = $data['thucnhan'];
        $user   = $data['username'];
        if($status == 1)
        {
            $NHNTAK->update("cards", array(
                'status'  => 'thanhcong'
            ), " `id` = '".$data['id']."' ");
            $isMoney = $NHNTAK->cong("users", "money", $sotien, " `username` = '$user'");
            $NHNTAK->cong("users", "total_money", $sotien, " `username` = '$user'");
            if($isMoney)
            {
                $NHNTAK->insert("dongtien", [
                    'username'      => $user,
                    'note'          => "Nạp thẻ cào mệnh giá ".format_cash($data['menhgia'])." thành công. Nhận ".format_cash($sotien)." đ. Có số mã thẻ là $pin",
                    'tongtien'      => $sotien,
                    'thoigian'          => gettime()
                ]);
            }
        }
        else
        {
            $NHNTAK->update("cards", array(
                'status'  => 'thatbai'
            ), " `id` = '".$data['id']."' ");
        }
    }
}