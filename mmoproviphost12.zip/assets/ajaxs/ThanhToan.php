<?php
require_once "../../config/config.php";
require_once "../../config/function.php";
require_once('../../class/class.smtp.php');
require_once('../../class/PHPMailerAutoload.php');
require_once('../../class/class.phpmailer.php');

if(isset($_POST['type']))
{
    if($_POST['type'] == 'MuaCode')
        {
            $id            = check_string($_POST['id']);
            }
            $price = $SourceCode['price'];
            if($getUser['money'] < $price)
            {
                exit(json_encode(['status' => '1', 'msg' => 'Bạn không đủ số dư để Mua Code']));
            }
            if(!$SourceCode = $NHNTAK->get_row(" SELECT * FROM `SourceCode` WHERE `id` = '$id' "))
            {
                exit(json_encode(['status' => '1', 'msg' => 'Shop này không tồn tại hoặc đã bị xóa']));
            }
            if(empty($_SESSION['username']))
            {
                exit(json_encode(['status' => '1', 'msg' => 'Không thể thao tác khi chưa Login']));
            }
            $create = $NHNTAK->insert("HistorySource", [
                'username'         => $getUser['username'],
                'link'            => $SourceCode['link'],
                'name'           => $SourceCode['name'],
                'price'      => $SourceCode['price'],
                'download'          => $download,
                'time'      => gettime()
            ]);
            $isMoney = $NHNTAK->tru("users", "money", $price, " `username` = '".$getUser['username']."'");   
            if($create)
            {
                $NHNTAK->insert("dongtien", array(
                    'sotientruoc'   => $getUser['money'],
                    'sotienthaydoi' => $sotien,
                    'thoigian'      => gettime(),
                    'noidung'       => 'Mua Code với tên '.$name.'',
                    'username'      => $getUser['username']
            ));
            $guitoi = $NHNTAK->site('email_admin');   
            $subject = 'THÔNG BÁO CÓ 1 SHOP ĐAMG CHỜ XỬ LÝ';
            $bcc = $NHNTAK->site('tenweb');
            $hoten ='TBS';
            $noi_dung = '<h2>Thông tin tạo shop</h2>
            <table >
            <tbody>
            <tr>
            <td>Tên khách hàng:</td>
            <td><b>'.$getUser['username'].'</b></td>
            </tr>
            <tr>
            <td>Thông tin domain shop:</td>
            <td><b>'.$domain.'</b></td>
            </tr>
            <tr>
            <td>Thông tin Admin:</td>
            <td><b style="color:blue;">Tài khoản: '.$tkadmin.' - Mật khẩu: '.$mkadmin.'</b></td>
            </tr>
            <tr>
            <td>Loại shop:</td>
            <td><b>'.$dichvuweb['title'].'</b></td>
            </tr>
            <tr>
            <td>Tổng tiền thanh toán</td>
            <td><b>'.format_cash($sotien).'đ</b></td>
            </tr>
            </tbody>
            </table>';
            sendCSM($guitoi, $hoten, $subject, $noi_dung, $bcc);

            exit(json_encode(['status' => '2', 'msg' => 'Mua Code thành công']));

        }
        else
        {
            exit(json_encode(['status' => '1', 'msg' => 'Vui lòng thao tác lại, cảm ơn']));
        }
}