<?php
require_once("../../config/config.php");
require_once("../../config/function.php");
require_once('../../class/class.smtp.php');
require_once('../../class/PHPMailerAutoload.php');
require_once('../../class/class.phpmailer.php');

if(isset($_POST['type']) && $getUser['level'] === 'admin')
{
    if($_POST['type'] == 'Thongtin')
    {
        $username   = check_string($_POST['user']);
        $chucnang   = check_string($_POST['chucnang']);
        $id   = check_string($_POST['id']);
        if(!$username || !$id)
        {
            msg_error2("Chưa nhận được dữ liệu gửi lên");
        }
        $row = $NHNTAK->get_row(" SELECT * FROM `historyhost` WHERE `taikhoan` = '$username'");
        if(!$row)
        {
            msg_error2("Tài khoản này không tồn tại trong hệ thống");
        }
        else
        {
            if($row['status'] !== 'hoatdong' && $chucnang == 1)
            {
                msg_error2("Hosting này phải hoạt động mới có thể xem được thông tin");
            }
        }
        $row4 = $NHNTAK->get_row(" SELECT * FROM `historyhost` WHERE `taikhoan` = '$username' AND `id` = '$id'");
        $row3 = $NHNTAK->get_row(" SELECT * FROM `users` WHERE `username` = '".$row['username']."' AND `banned` = 'OFF'");
        $row2 = $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '".$row['server']."' AND `status` = 'SHOW' AND `loai` = '".$row4['loai']."' ");
        if(!$row4)
        {
            msg_error2("Dữ liệu không không khớp với DATABASE");
        }
        if(!$row2)
        {
            msg_error2("Máy chủ không tồn tại hoặc đang ngưng hoạt động");
        }
        if($chucnang == 1)
        {
            $data = json_decode(apiWHM($row2['taikhoanrsl'], $row2['matkhaursl'], $row['linklogin'].':2087/json-api/accountsummary?api.version=1&user='.$username), true);
            if(isset($data['metadata']))
            {
                if($data['metadata']['result'] == 1)
                {
                    msg_success2("IP của bạn là: ".$data['data']['acct'][0]['ip']." <br/> Đã dùng: ".$data['data']['acct'][0]['diskused']." <br/> Tổng dung lượng:  ".$data['data']['acct'][0]['disklimit']."  <br/> Gói: ".$data['data']['acct'][0]['plan']."");
                }
                else
                {
                    msg_error2($data['metadata']['reason']);
                }
            }
            else
            {
                msg_error2("Hệ thống đang LAG, chưa thể kiểm tra thông tin");
            }
        }
        else if($chucnang == 2 || $chucnang == 3 || $chucnang == 4 || $chucnang == 7)
        {
            $data2 = json_decode(curl_get(BASE_URL('api/thaotac?token='.$row3['tokenapi'].'&username='.$username.'&type='.$chucnang.'&idget='.$id)), true);
            if($data2['status'] == 'success')
            {
                if($chucnang == 2)
                {
                    msg_success2($data2['message'].' Mật khẩu là: '.$data2['password']);
                }
                else
                {
                    if(isset($data2['loginspeed']))
                    {
                        msg_success($data2['message'], $data2['loginspeed'], 1000);
                    }
                    msg_success2($data2['message']);
                }
            }
            else
            {
                msg_error2($data2['message']);
            }
        }
        else if($chucnang == 8)
        {
            $note = 'Admin tạm khóa';
            if($row4['loai'] == 'reseller')
            {
                $JSC = json_decode(apiWHM($row2['taikhoanrsl'], $row2['matkhaursl'], $row2['linkrsl'].':2087/json-api/suspendreseller?api.version=1&user='.$username.'&reseller-only=0&reason='.urlencode($note)), true); // khóa rsl + tài khoản đã tạo
            }
            else
            {
                $JSC = json_decode(apiWHM($row2['taikhoanrsl'], $row2['matkhaursl'], $row2['linkrsl'].':2087/json-api/suspendacct?api.version=1&user='.$username.'&reason='.urlencode($note)), true); // khóa hosting
            }
            if($JSC['metadata']['result'] == 1)
            {
                $NHNTAK->update("historyhost", array(
                    'status'    => 'adminkhoa',
                    'note'      => $note
                ), " `id` = '$id' ");
                msg_success2('Khóa hosting thành công');
            }
            else
            {
                msg_error2("Khóa thất bại vì: ".$JSC['metadata']['reason']);
            }
        }
        else if($chucnang == 9)
        {
            $note = 'Admin tạm khóa';
            if($row4['loai'] == 'reseller')
            {
                $JSC = json_decode(apiWHM($row2['taikhoanrsl'], $row2['matkhaursl'], $row['linkrsl'].':2087/json-api/suspendreseller?api.version=1&user='.$username.'&reseller-only=0&reason='.urlencode($note)), true); // khóa rsl + tài khoản đã tạo
            }
            else
            {
                $JSC = json_decode(apiWHM($row2['taikhoanrsl'], $row2['matkhaursl'], $row['linkrsl'].':2087/json-api/suspendacct?api.version=1&user='.$username.'&reason='.urlencode($note)), true); // khóa hosting
            }
            if($JSC['metadata']['result'] == 1)
            {
                $NHNTAK->update("historyhost", array(
                    'status'    => 'adminkhoa',
                    'note'      => $note
                ), " `id` = '$id' ");
                msg_success2('Khóa hosting thành công');
            }
            else
            {
                msg_error2("Khóa thất bại vì: ".$JSC['metadata']['reason']);
            }
        }
        else if($chucnang == 10)
        {
            if($row4['loai'] == 'reseller')
            {
                $tuanmokhoa = json_decode(apiWHM($row2['taikhoanrsl'], $row2['matkhaursl'], $row['linklogin'].':2087/json-api/unsuspendreseller?api.version=1&user='.$username.'&reseller-only=0'), true);
            }
            else
            {
                $tuanmokhoa = json_decode(apiWHM($row2['taikhoanrsl'], $row2['matkhaursl'], $row['linklogin'].':2087/json-api/unsuspendacct?api.version=1&user='.$username), true);
            }
            if($tuanmokhoa['metadata']['result'] == 1)
            {
                $NHNTAK->update("historyhost", array(
                    'status'    => 'hoatdong',
                    'note'      => ''
                ), " `id` = '$id' ");
                msg_success2('Mở hosting thành công');
            }
            else
            {
                msg_error2("Mở khóa thất bại vì: ".$tuanmokhoa['metadata']['reason']);
            }
        }
        else
        {
            msg_error2('Thao tác không tồn tại');
        }
    }
}