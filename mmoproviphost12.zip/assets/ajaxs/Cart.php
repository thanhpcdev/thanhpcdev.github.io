<?php
require_once "../../config/config.php";
require_once "../../config/function.php";
require_once('../../class/class.smtp.php');
require_once('../../class/PHPMailerAutoload.php');
require_once('../../class/class.phpmailer.php');


if(isset($_POST['type']))
{
    if($_POST['type'] == 'MuaDomain')
        {
            $nam    = check_string($_POST['nam']);
            $domain = check_string($_POST['domain']);
            $duoi   = check_string($_POST['duoi']);
            $ns     = check_string($_POST['ns']);
            if(!$domain)
            {
                exit(json_encode(['status' => '1', 'msg' => 'Vui lòng nhập tên miền']));
            }
            if(!$duoi)
            {
                exit(json_encode(['status' => '1', 'msg' => 'Vui lòng chọn đuôi domain']));
            }
            if(!$nam)
            {
                exit(json_encode(['status' => '1', 'msg' => 'Vui lòng chọn thời hạn đăng kí']));
            }
            if(!$ns)
            {
                exit(json_encode(['status' => '1', 'msg' => 'Vui lòng nhập nameserver']));
            }
            if($nam < 1 || $nam > 10)
            {
                exit(json_encode(['status' => '1', 'msg' => 'Mua tối thiểu 1 năm và tối đa 10 năm']));
            }
            if(check_ktl($domain) != True)
            {
                exit(json_encode(['status' => '1', 'msg' => 'Tên miền của bạn không được chứa kí tự lạ']));
            }
            if(!$check = $NHNTAK->get_row(" SELECT * FROM `tongdomain` WHERE `id` = '$duoi' "))
            {
                exit(json_encode(['status' => '1', 'msg' => 'Đuôi tên miền không tồn tại hoặc đã bị ẩn']));
            }
            if(empty($_SESSION['username']))
            {
                exit(json_encode(['status' => '1', 'msg' => 'Đăng nhập đi mới cho mua']));
            }
            $sotien = $check['sotien']*$nam;
            if($getUser['money'] < $sotien)
            {
                exit(json_encode(['status' => '1', 'msg' => 'Bạn không đủ số dư']));
            }
            if (time() > $NHNTAK->site('check_time_cron_domain')) {
            if (time() - $NHNTAK->site('check_time_cron_domain') < 10) {
            exit(json_encode(['status' => '1', 'msg' => 'Thao tác quá nhanh, vui lòng đợi']));
            }
            }
            $NHNTAK->update("options", array(
            'value' => time()
            ), " `key` = 'check_time_cron_domain' ");
            }
            $mien = $domain.'.'.$check['duoimien'];
            $data = json_decode(curl_get("https://api.tuanori.vn/domain.php?domain=$mien"), true);
            if(isset($data['status']))
            {
                if($data['status'] == true)
                {
                    if($data['true'] == 1)
                    {
                        exit(json_encode(['status' => '1', 'msg' => 'Tên miền này đã được đăng ký']));
                    }
                }else{
                    exit(json_encode(['status' => '1', 'msg' => $data['msg']]));
                }
            }
            else
            {
                exit(json_encode(['status' => '1', 'msg' => 'Hệ thống không thể tra tên miền này']));
            }
            $create = $NHNTAK->insert("hisdomain", [
                'username'  => $getUser['username'],
                'domain'    => $mien,
                'nam'       => $nam,
                'tongtien'  => $sotien,
                'nameserver'=> $ns,
                'timemua'   => time(),
                'timedie'   => time() + ($onethang*12) * $nam,
                'status'    => 'xuly'
            ]);
            $isMoney = $NHNTAK->tru("users", "money", $sotien, " `username` = '".$getUser['username']."'");   
            if($create)
            {
                $NHNTAK->insert("dongtien", array(
                    'sotientruoc'   => $getUser['money'],
                    'sotienthaydoi' => $sotien,
                    'thoigian'      => gettime(),
                    'noidung'       => 'Bạn vừa thanh toán tên miền '.$mien.'',
                    'username'      => $getUser['username']
            ));
            $guitoi = $NHNTAK->site('email_admin');   
            $subject = 'THÔNG BÁO CÓ MUA MIỀN ĐANG XỬ LÝ';
            $bcc = $NHNTAK->site('tenweb');
            $hoten ='TSS';
            $noi_dung = '<h2>Thông tin mua domain</h2>
            <table >
            <tbody>
            <tr>
            <td>Thông tin domain:</td>
            <td><b>'.$mien.'</b></td>
            </tr>
            <tr>
            <td>Tên khách hàng:</td>
            <td><b style="color:blue;">'.$getUser['username'].'</b></td>
            </tr>
            <tr>
            <td>Nameserver:</td>
            <td><b>'.$ns.'</b></td>
            </tr>
            <tr>
            <td>Tổng tiền thanh toán</td>
            <td><b>'.format_cash($sotien).'đ</b></td>
            </tr>
            </tbody>
            </table>';
            sendCSM($guitoi, $hoten, $subject, $noi_dung, $bcc);

            exit(json_encode(['status' => '2', 'msg' => 'Mua tên miền thành công']));

        }
        else
        {
            exit(json_encode(['status' => '1', 'msg' => 'Vui lòng thao tác lại, cảm ơn']));
        }
    }