<?php
require_once "../../config/config.php";
require_once "../../config/function.php";
require_once('../../class/class.smtp.php');
require_once('../../class/PHPMailerAutoload.php');
require_once('../../class/class.phpmailer.php');

if(isset($_POST['type']))
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
              exit(json_encode(['status' => '1', 'msg' => 'KHÔNG THỂ THAO TÁC Ở WEB DEMO']));
    }
    if($_POST['type'] == 'Ntcao')
        {
        $seri           = check_string($_POST['seri']);
        $pin            = check_string($_POST['pin']);
        $type           = check_string($_POST['loaithe']);
        $amount         = check_string($_POST['menhgia']);
        $randid         = rand(111111111111,999999999);
    if (empty($_POST['loaithe'])) {
        exit(json_encode([ 'status' => '1', 'msg' => 'Vui lòng chọn nhà mạng']));
    }
    if (empty($_POST['menhgia'])) {
        exit(json_encode(['status' => '1', 'msg' => 'Vui lòng chọn mệnh giá']));
    }
    if (empty($_POST['pin'])) {
        exit(json_encode(['status' => '1', 'msg' => 'Vui lòng nhập mã thẻ']));
    }
    if (empty($_POST['seri'])) {
        exit(json_encode(['status' => '1', 'msg' => 'Vui lòng nhập serial thẻ']));
    }
    if (strlen($seri) < 7 || strlen($pin) < 7)
    {
        exit(json_encode(['status' => '1', 'msg' => 'Mã thẻ hoặc Seri không đúng định dạng']));
    }
    else{
    $data = curl_get('https://doithe1s.vn/chargingws/v2?sign='.md5($NHNTAK->site('partner_key').$pin.$seri).'&telco='.$type.'&code='.$pin.'&serial='.$seri.'&amount='.$amount.'&request_id='.$randid.'&partner_id='.$NHNTAK->site('partner_id').'&command=charging');
    $data = json_decode($data, true);
        if(isset($data['status']))
            {
                if($data['status'] == 99)
                {
                    $thucnhan = ckcar_ndkdark($amount, $NHNTAK->site('ckcard'));
                    $create = $NHNTAK->insert("cards", [
                        'username'          => $getUser['username'],
                        'loaithe'           => $type,
                        'menhgia'           => $amount,
                        'seri'              => $seri,
                        'pin'               => $pin,
                        'thucnhan'          => $thucnhan,
                        'requestid'         => $randid,
                        'status'            => 'xuly',
                        'thoigian'          => gettime()
                    ]);
                    exit(json_encode(['status' => '2','msg' => 'Gửi thẻ thành công, vui lòng đợi kết quả', BASE_URL('recharge/card'), 2000]));
                }else{
                    exit(json_encode(['status' => '1', 'msg' => $data['message']]));
                }
            }
        }
    }
}