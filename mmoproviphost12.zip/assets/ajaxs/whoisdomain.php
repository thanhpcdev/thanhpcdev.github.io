<?php
require_once "../../config/config.php";
require_once "../../config/function.php";
require_once('../../class/class.smtp.php');
require_once('../../class/PHPMailerAutoload.php');
require_once('../../class/class.phpmailer.php');

function write_log($message)
{
    $logFile = __DIR__ . '/log_kiemtra_domain.txt';
    $time = date("Y-m-d H:i:s");
    $logMessage = "[$time] $message" . PHP_EOL;
    file_put_contents($logFile, $logMessage, FILE_APPEND);
}

if (isset($_POST['type'])) {
    if ($_POST['type'] == 'Kiemtradomain') {
        $domain = check_string($_POST['domain']);
        write_log("Nhận yêu cầu kiểm tra domain: $domain");

        if (!$domain) {
            write_log("Lỗi: không có tên miền được gửi.");
            exit(json_encode(['status' => '1', 'msg' => 'Vui lòng nhập tên miền']));
        }

        $mien = explode('.', $domain);
        if (empty($mien[1])) {
            write_log("Lỗi: tên miền không hợp lệ: $domain");
            exit(json_encode(['status' => '1', 'msg' => 'Tên miền của bạn không hợp lệ']));
        }

        $apiUrl = "https://whois.inet.vn/api/whois/domainspecify/" . urlencode($domain);
        write_log("Gọi API iNET: $apiUrl");

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $apiUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_CUSTOMREQUEST => 'GET'
        ]);

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            $error = curl_error($ch);
            write_log("Lỗi CURL: $error");
            exit(json_encode(['status' => '500', 'msg' => "CURL Error: $error"]));
        }

        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            write_log("Lỗi HTTP code: $httpCode");
            exit(json_encode(['status' => '500', 'msg' => "HTTP Error Code: $httpCode"]));
        }

        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $jsonError = json_last_error_msg();
            write_log("Lỗi JSON: $jsonError");
            exit(json_encode(['status' => '500', 'msg' => "JSON Error: $jsonError"]));
        }

        write_log("Phản hồi từ API: " . json_encode($data));

        if (!is_array($data)) {
            write_log("Phản hồi không hợp lệ.");
            exit(json_encode(['status' => '1', 'msg' => 'Không thể phân tích phản hồi từ iNET']));
        }

        if (isset($data['code']) && $data['code'] == '0') {
            write_log("Tên miền đã được đăng ký: $domain");
            exit(json_encode(['status' => '1', 'msg' => 'Tên miền của bạn đã đăng ký']));
        } elseif (isset($data['code']) && $data['code'] == '1') {
            write_log("Tên miền chưa đăng ký: $domain");
            exit(json_encode(['status' => '2', 'msg' => 'Tên miền chưa được đăng ký']));
        } else {
            write_log("Không xác định được trạng thái tên miền: " . json_encode($data));
            exit(json_encode(['status' => '500', 'msg' => 'Không xác định được trạng thái tên miền']));
        }
    }
}
