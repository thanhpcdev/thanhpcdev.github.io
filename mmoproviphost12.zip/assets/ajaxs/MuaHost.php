<?php
require_once "../../config/config.php";
require_once "../../config/function.php";
require_once('../../class/class.smtp.php');
require_once('../../class/PHPMailerAutoload.php');
require_once('../../class/class.phpmailer.php');

// Add write_log function
function write_log($message, $level = 'INFO')
{
    $logFile = __DIR__ . '/log_kiemtra_host.txt';
    $time = date("Y-m-d H:i:s");
    $logMessage = "[$time][$level] $message" . PHP_EOL;
    file_put_contents($logFile, $logMessage, FILE_APPEND);
}

if(isset($_POST['type']))
{
    write_log("=== Bắt Đầu Xử Lý Yêu Cầu Mới ===");
    write_log("Loại Yêu Cầu: " . $_POST['type']);
    write_log("Dữ Liệu Yêu Cầu: " . json_encode($_POST));
    
    if($_POST['type'] == 'MuaHost')
    {
        write_log("=== Xử Lý Yêu Cầu Mua Host ===");
        $email  = check_string(strtolower($_POST['email']));
        $domain = check_string(strtolower($_POST['domain']));
        $goi    = check_string($_POST['goi']);
        $server = check_string($_POST['server']);
        $type   = check_string($_POST['theloai']);
        $loai   = check_string($_POST['loai']);
        
        write_log("Thông Tin Đầu Vào Đã Xử Lý:");
        write_log("- Email: $email");
        write_log("- Tên Miền: $domain");
        write_log("- Gói Hosting: $goi");
        write_log("- Máy Chủ: $server");
        write_log("- Loại: $type");
        write_log("- Phân Loại: $loai");
        
        if(!$email || !$domain)
        {
            write_log("Lỗi Xác Thực: Thiếu thông tin bắt buộc", "ERROR");
            write_log("- Email: " . ($email ? 'Có' : 'Không'));
            write_log("- Tên Miền: " . ($domain ? 'Có' : 'Không'));
            msg_error2("Vui lòng nhập đủ thông tin để tiếp tục");
        }
        // ... existing code ...
        
        $goi1 = $NHNTAK->get_row(" SELECT * FROM `goihost` WHERE `nameGoi` = '$goi' AND `serverhost` = '$server' AND `status` = 'SHOW' AND `type` = '$type'");
        write_log("Kiểm Tra Thông Tin Gói Hosting:");
        write_log("- Tên Gói: $goi");
        write_log("- Máy Chủ: $server");
        write_log("- Loại: $type");
        write_log("- Tìm Thấy Gói: " . ($goi1 ? 'Có' : 'Không'));
        
        if(!$goi1)
        {
            write_log("Cấu Hình Gói Hosting Không Hợp Lệ", "ERROR");
            write_log("- Gói: $goi");
            write_log("- Máy Chủ: $server");
            write_log("- Loại: $type");
            exit(json_encode(['status' => '1', 'msg' => 'Lưu trữ sản phẩm không hợp lệ']));
        }
        
        if(check_email($email) != True)
        {
            write_log("Email Không Hợp Lệ", "ERROR");
            write_log("- Email Không Đúng Định Dạng: $email");
            exit(json_encode(['status' => '1', 'msg' => 'Email của bạn không hợp lệ']));
        }
        
        $checkhost = $NHNTAK->get_row(" SELECT * FROM `historyhost` WHERE `domain` = '$domain' AND `status` = 'hoatdong' AND `type` = '$type'");
        write_log("Kiểm Tra Tên Miền Trong Lịch Sử:");
        write_log("- Tên Miền: $domain");
        write_log("- Loại: $type");
        write_log("- Tên Miền Đã Tồn Tại: " . ($checkhost ? 'Có' : 'Không'));
        
        if($checkhost)
        {
            write_log("Tên Miền Đã Tồn Tại Trong Hệ Thống", "ERROR");
            write_log("- Tên Miền: $domain");
            write_log("- Trạng Thái: hoatdong");
            exit(json_encode(['status' => '1', 'msg' => 'Tên miền đã tồn tại trên hệ thống']));
        }
        
        if (empty($_SESSION['username']))
        {
            write_log("Lỗi Xác Thực Người Dùng", "ERROR");
            write_log("- Tên Đăng Nhập: " . (isset($_SESSION['username']) ? $_SESSION['username'] : 'Chưa Đăng Nhập'));
            exit(json_encode(['status' => '1', 'msg' => 'Bạn chưa đăng nhập vào tài khoản của bạn trên trang web của chúng tôi']));
        }
        
        $sotien = $goi1['money'];
        write_log("Kiểm Tra Số Dư Người Dùng:");
        write_log("- Số Tiền Cần: $sotien");
        write_log("- Số Dư Hiện Tại: $my_money");
        write_log("- Người Dùng: {$getUser['username']}");
        
        if($my_money < $sotien)
        {
            write_log("Số Dư Không Đủ", "ERROR");
            write_log("- Số Tiền Cần: $sotien");
            write_log("- Số Dư Hiện Tại: $my_money");
            write_log("- Người Dùng: {$getUser['username']}");
            exit(json_encode(['status' => '1', 'msg' => 'Số dư không đủ để thực hiện giao dịch']));
        }
        
        $WHM = $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '".$goi1['serverhost']."' AND `status` = 'SHOW'");
        write_log("Cấu Hình Máy Chủ WHM:");
        write_log("- Tên Máy Chủ: {$WHM['nameGetServer']}");
        write_log("- URL Máy Chủ: {$WHM['linkrsl']}");
        write_log("- Loại Máy Chủ: {$WHM['loairsl']}");
        
        write_log("Kiểm Tra Tên Miền Trên Máy Chủ WHM: {$WHM['linkrsl']}");
        $data = json_decode(apiWHM($WHM['taikhoanrsl'], $WHM['matkhaursl'], $WHM['linkrsl'].':2087/json-api/get_domain_info?api.version=1'), true);
        write_log("Phản Hồi API WHM: " . json_encode($data));
        
        foreach($data['data']['domains'] as $demo)
        {
            if($demo['domain'] == $domain)
            {
                $checkdo = true;
                write_log("Đã Tìm Thấy Tên Miền Trên Máy Chủ WHM: $domain");
            }
        }
        
        if(isset($checkdo))
        {
            write_log("Tên Miền Đã Tồn Tại Trên Máy Chủ WHM", "ERROR");
            write_log("- Tên Miền: $domain");
            exit(json_encode(['status' => '1', 'msg' => 'Tên miền đã tồn tại trên hệ thống']));
        }
        else
        {
            write_log("Tạo Tài Khoản Hosting Mới");
            write_log("Chi Tiết Tài Khoản Hosting:");
            write_log("- Tên Đăng Nhập: {$getUser['username']}");
            write_log("- Tên Miền: $domain");
            write_log("- Email: $email");
            write_log("- Máy Chủ: {$goi1['serverhost']}");
            write_log("- Gói: $goi");
            write_log("- Số Tiền: $sotien");
            write_log("- Loại: $type");
            write_log("- Phân Loại: $loai");
            
            $create = $NHNTAK->insert("historyhost", [
                'username'      => $getUser['username'],
                'domain'        => $domain,
                'email'         => $email,
                'server'        => $goi1['serverhost'],
                'goi'           => $goi,
                'tongtien'      => $goi1['money'],
                'tienlandau'    => $sotien,
                'ngaymua'       => time(),
                'ngayhet'       => time() + $onethang,
                'thoigian'      => gettime(),
                'autogiahan'    => 'NO',
                'linklogin'     => $WHM['linkrsl'],
                'loairsl'       => $WHM['loairsl'],
                'nsNameServer'  => $WHM['nsNameServer'],
                'type'          => $type,
                'loai'          => $loai,
                'status'        => 'dangtao'
            ]);
            
            write_log("Chi Tiết Thêm Vào Cơ Sở Dữ Liệu:");
            write_log("- Bảng: historyhost");
            write_log("- Dữ Liệu: " . json_encode([
                'username'      => $getUser['username'],
                'domain'        => $domain,
                'email'         => $email,
                'server'        => $goi1['serverhost'],
                'goi'           => $goi,
                'tongtien'      => $goi1['money'],
                'tienlandau'    => $sotien,
                'ngaymua'       => time(),
                'ngayhet'       => time() + $onethang,
                'thoigian'      => gettime(),
                'autogiahan'    => 'NO',
                'linklogin'     => $WHM['linkrsl'],
                'loairsl'       => $WHM['loairsl'],
                'nsNameServer'  => $WHM['nsNameServer'],
                'type'          => $type,
                'loai'          => $loai,
                'status'        => 'dangtao'
            ]));

            // Thêm log kiểm tra kết nối database
            write_log("Kiểm Tra Kết Nối Database:");
            write_log("- Trạng Thái Kết Nối: " . ($NHNTAK->connect ? 'Đã Kết Nối' : 'Mất Kết Nối'));
            
            // Thêm log lỗi SQL nếu có
            if(isset($NHNTAK->error)) {
                write_log("Lỗi SQL:", "ERROR");
                write_log("- Mã Lỗi: " . $NHNTAK->error['code']);
                write_log("- Thông Báo: " . $NHNTAK->error['message']);
            }

            // Thêm log câu lệnh SQL
            write_log("Câu Lệnh SQL Thực Thi:");
            write_log("- INSERT INTO historyhost SET " . implode(', ', array_map(
                function($key, $value) {
                    return "$key = '$value'";
                },
                array_keys([
                    'username'      => $getUser['username'],
                    'domain'        => $domain,
                    'email'         => $email,
                    'server'        => $goi1['serverhost'],
                    'goi'           => $goi,
                    'tongtien'      => $goi1['money'],
                    'tienlandau'    => $sotien,
                    'ngaymua'       => time(),
                    'ngayhet'       => time() + $onethang,
                    'thoigian'      => gettime(),
                    'autogiahan'    => 'NO',
                    'linklogin'     => $WHM['linkrsl'],
                    'loairsl'       => $WHM['loairsl'],
                    'nsNameServer'  => $WHM['nsNameServer'],
                    'type'          => $type,
                    'loai'          => $loai,
                    'status'        => 'dangtao'
                ]),
                array_values([
                    'username'      => $getUser['username'],
                    'domain'        => $domain,
                    'email'         => $email,
                    'server'        => $goi1['serverhost'],
                    'goi'           => $goi,
                    'tongtien'      => $goi1['money'],
                    'tienlandau'    => $sotien,
                    'ngaymua'       => time(),
                    'ngayhet'       => time() + $onethang,
                    'thoigian'      => gettime(),
                    'autogiahan'    => 'NO',
                    'linklogin'     => $WHM['linkrsl'],
                    'loairsl'       => $WHM['loairsl'],
                    'nsNameServer'  => $WHM['nsNameServer'],
                    'type'          => $type,
                    'loai'          => $loai,
                    'status'        => 'dangtao'
                ])
            )));

            write_log("Kết Quả Thêm Vào Cơ Sở Dữ Liệu: " . ($create ? 'Thành Công' : 'Thất Bại'));
            
            if($create)
            {
                write_log("Đang Xử Lý Thanh Toán");
                $isMoney = $NHNTAK->tru("users", "money", $sotien, " `username` = '".$getUser['username']."'");
                write_log("Kết Quả Xử Lý Thanh Toán: " . ($isMoney ? 'Thành Công' : 'Thất Bại'));
                
                if($isMoney)
                {
                    write_log("Ghi Nhận Giao Dịch");
                    $NHNTAK->insert("dongtien", [
                         'sotientruoc'   => $getUser['money'],
                         'sotienthaydoi' => $price,
                         'thoigian'      => gettime(),
                         'noidung'       => 'You Buy Hosting my domain | '.$domain.'',
                         'username'      => $getUser['username']
                    ]);
                    
                    if($loai == 'reseller')
                    {
                        write_log("Đã Tạo Tài Khoản Reseller Thành Công");
                    }
                    
                    unset($_SESSION['host']);
                    write_log("=== Hoàn Thành Mua Hosting Thành Công ===");
                    exit(json_encode(['status' => '2','msg' => 'Thanh toán Hosting thành công, vui lòng đợi ít giây đến ít phút để khởi tạo', BASE_URL('linkhistoryhost'), 2000]));
                }
                else
                {
                    write_log("Khấu Trừ Tiền Thất Bại", "ERROR");
                    write_log("- Người Dùng: {$getUser['username']}");
                    write_log("- Số Tiền: $sotien");
                    exit(json_encode(['status' => '1', 'msg' => 'TIỀN KHÔNG THỂ KHẤU TRỪ']));
                }
            }
            else
            {
                write_log("Tạo Tài Khoản Hosting Thất Bại", "ERROR");
                write_log("- Tên Miền: $domain");
                write_log("- Người Dùng: {$getUser['username']}");
                exit(json_encode(['status' => '1', 'msg' => 'KIỂM TRA NGUỒN TỆP LẠI CỦA BẠN']));
            }
        }
    }
    write_log("=== Hoàn Thành Xử Lý Yêu Cầu ===");
}
