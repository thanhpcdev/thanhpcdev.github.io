<?php 
    require_once("../../config/config.php");
    require_once("../../config/function.php");

    $data = $NHNTAK->get_list("SELECT * FROM `history_shop` WHERE `status` = 'xuly' ");

    foreach($data as $row)
    {
        exit("<script type='text/javascript'>VanillaToasts.create({
            title: 'Có 1 đơn tạo shop đang chờ xử lý #".$row['domain']."',
            text: 'Developer by: Dichvuweb.Asia',
            type: 'warning',
            icon: 'https://cdn.pixabay.com/photo/2016/11/18/23/38/child-1837375_960_720.png',
            positionClass: 'bottomRight'
            });</script>");
    };