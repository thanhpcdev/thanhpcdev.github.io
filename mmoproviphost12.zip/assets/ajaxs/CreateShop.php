<?php
require_once "../../config/config.php";
require_once "../../config/function.php";
require_once('../../class/class.smtp.php');
require_once('../../class/PHPMailerAutoload.php');
require_once('../../class/class.phpmailer.php');

if(isset($_POST['type']))
{
    if($_POST['type'] == 'TaoShop')
        {
            $id            = check_string($_POST['id']);
            $timeCreate    = check_string($_POST['timeCreate']);
            $domain        = check_string($_POST['domain']);
            $tkadmin       = check_string($_POST['tkadmin']);
            $mkadmin       = check_string($_POST['mkadmin']);
            if(!$domain)
            {
                exit(json_encode(['status' => '1', 'msg' => 'Vui lòng nhập tên miền']));
            }
            if(!$tkadmin)
            {
                exit(json_encode(['status' => '1', 'msg' => 'Vui lòng nhập tài khoản Admin']));
            }
            if(!$mkadmin)
            {
                exit(json_encode(['status' => '1', 'msg' => 'Vui lòng nhập mật khẩu Admin']));
            }
            if(!$dichvuweb = $NHNTAK->get_row(" SELECT * FROM `shopcreate` WHERE `id` = '$id' "))
            {
                exit(json_encode(['status' => '1', 'msg' => 'Shop này không tồn tại hoặc đã bị xóa']));
            }
            if(empty($_SESSION['username']))
            {
                exit(json_encode(['status' => '1', 'msg' => 'Không thể thao tác khi chưa Login']));
            }
            $sotien = $dichvuweb['sotien'];
            if($getUser['money'] < $sotien)
            {
                exit(json_encode(['status' => '1', 'msg' => 'Bạn không đủ số dư để tạo shop']));
            }
            $create = $NHNTAK->insert("history_shop", [
                'username'         => $getUser['username'],
                'title'            => $dichvuweb['title'],
                'domain'           => $domain,
                'timeCreate'       => '3 tháng',
                'moneycreate'      => $sotien,
                'tkadmin'          => $tkadmin,
                'mkadmin'          => $mkadmin,
                'status'           => 'xuly',
                'create_date'      => gettime()
            ]);
            $isMoney = $NHNTAK->tru("users", "money", $sotien, " `username` = '".$getUser['username']."'");   
            if($create)
            {
                $NHNTAK->insert("dongtien", array(
                    'sotientruoc'   => $getUser['money'],
                    'sotienthaydoi' => $sotien,
                    'thoigian'      => gettime(),
                    'noidung'       => 'Tạo shop game với tên miền '.$domain.'',
                    'username'      => $getUser['username']
            ));
            $guitoi = $NHNTAK->site('email_admin');   
            $subject = 'THÔNG BÁO CÓ 1 SHOP ĐAMG CHỜ XỬ LÝ';
            $bcc = $NHNTAK->site('tenweb');
            $hoten ='TBS';
            $noi_dung = '<h2>Thông tin tạo shop</h2>
            <table >
            <tbody>
            <tr>
            <td>Tên khách hàng:</td>
            <td><b>'.$getUser['username'].'</b></td>
            </tr>
            <tr>
            <td>Thông tin domain shop:</td>
            <td><b>'.$domain.'</b></td>
            </tr>
            <tr>
            <td>Thông tin Admin:</td>
            <td><b style="color:blue;">Tài khoản: '.$tkadmin.' - Mật khẩu: '.$mkadmin.'</b></td>
            </tr>
            <tr>
            <td>Loại shop:</td>
            <td><b>'.$dichvuweb['title'].'</b></td>
            </tr>
            <tr>
            <td>Tổng tiền thanh toán</td>
            <td><b>'.format_cash($sotien).'đ</b></td>
            </tr>
            </tbody>
            </table>';
            sendCSM($guitoi, $hoten, $subject, $noi_dung, $bcc);

            exit(json_encode(['status' => '2', 'msg' => 'Tạo shop thành công']));

        }
        else
        {
            exit(json_encode(['status' => '1', 'msg' => 'Vui lòng thao tác lại, cảm ơn']));
        }
                }
            }