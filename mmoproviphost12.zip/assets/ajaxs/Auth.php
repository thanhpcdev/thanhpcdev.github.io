<?php
require_once "../../config/config.php";
require_once "../../config/function.php";
require_once('../../class/class.smtp.php');
require_once('../../class/PHPMailerAutoload.php');
require_once('../../class/class.phpmailer.php');

if(isset($_POST['type']) && $_POST['type'] == 'Login') {
    // Validate CSRF token if implemented
    // if (!validate_csrf_token($_POST['csrf_token'])) {
    //     exit(json_encode(['status' => '1', 'msg' => 'Invalid request']));
    // }

    $username = check_string($_POST['username']);
    $password = check_string($_POST['password']);

    // Input validation
    if (empty($username)) {
        exit(json_encode([
            'status' => '1',
            'msg' => 'Vui lòng nhập tên đăng nhập'
        ]));
    }

    if (empty($password)) {
        exit(json_encode([
            'status' => '1',
            'msg' => 'Vui lòng nhập mật khẩu'
        ]));
    }

    // Verify reCAPTCHA
    $secret = "6LfxhFYrAAAAAHdZRoRiNjVfFkeCvvGO589dQF7O";
    $ip = $_SERVER['REMOTE_ADDR'];
    $response = $_POST['captcha'];
    $url = "https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$response&remoteip=$ip";
    $fire = file_get_contents($url);
    $data = json_decode($fire);
    
    if ($data->success == false) {
        exit(json_encode(['status' => '1', 'msg' => 'Vui lòng xác nhận Captcha']));
    }

    // Check if user exists
    $user = $NHNTAK->get_row("SELECT * FROM `users` WHERE `username` = '$username'");
    if (!$user) {
        exit(json_encode([
            'status' => '1',
            'msg' => 'Sai tài khoản hoặc mật khẩu'
        ]));
    }

    // Verify password
    if ($user['password'] != md5($password)) {
        exit(json_encode([
            'status' => '1',
            'msg' => 'Sai tài khoản hoặc mật khẩu'
        ]));
    }

    // Check if user is banned
    if ($user['banned'] == '1') {
        exit(json_encode([
            'status' => '1',
            'msg' => 'Tài khoản này đã bị khóa bởi ADMIN'
        ]));
    }

    // Update last login IP
    $NHNTAK->update("users", [
        'ip' => myip(),
    ], " `username` = '$username' ");

    // Set session
    $_SESSION['username'] = $username;
    
    // Set session cookie parameters
    session_set_cookie_params([
        'lifetime' => 3600,
        'path' => '/',
        'secure' => true,
        'httponly' => true,
        'samesite' => 'Strict'
    ]);

    exit(json_encode([
        'status' => '2',
        'msg' => 'Đăng nhập thành công'
    ]));
} 
if($_POST['type'] == 'checked')
    {
        if(isset($_POST['status']) && isset($_POST['id']))
        {
            $id     = $_POST['id'];
            $check  = $_POST['status'];
            if($NHNTAK->get_row(" SELECT * FROM `historyhost` WHERE `id` = '$id' AND `username` = '".$getUser['username']."'"))
            {
                if($check == 'true')
                {
                    $NHNTAK->update("historyhost", array(
                        'autogiahan'    => 'YES'
                    ), " `id` = '$id' ");
                }
                else if($check == 'false')
                {
                    $NHNTAK->update("historyhost", array(
                        'autogiahan'    => 'NO'
                    ), " `id` = '$id' ");
                }
            }
        }
    }
    if($_POST['type'] == 'ChuyenHost')
    {
        $email = check_string($_POST['email']);
        $id    = check_string($_POST['id']);
        if(!$email || !$id)
        {
            msg_error2("Vui lòng nhập đầy đủ thông tin");
        }
        $check = $NHNTAK->get_row(" SELECT * FROM `historyhost` WHERE `id` = '$id' AND `username` = '".$getUser['username']."'");
        if(!$check)
        {
            msg_error2("Hosting không tồn tại hoặc không phải của bạn");
        }
        if($check['status'] != 'hoatdong')
        {
            msg_error2("Hosting phải hoạt động mới thao tác được");
        }
        if(check_email($email) != True)
        {

        }
        if($getUser['email'] == $email)
        {
            msg_error2("Không thể tự chuyển cho bản thân");
        }
        $checkUser = $NHNTAK->get_row(" SELECT * FROM `users` WHERE `email` = '$email'");
        if(!$checkUser)
        {
            msg_error2("Email người nhận không tồn tại");
        }
        if($getUser['money'] < 100)
        {
            msg_error2("Tài khoản bạn không đủ 100đ để chuyển nhượng");
        }
        else
        {
            $isMoney = $NHNTAK->tru("users", "money", 100, " `tokenlog` = '".$_COOKIE['token']."'");
            if($isMoney)
            {
                $NHNTAK->update("historyhost", array(
                    'username'      => $checkUser['username'],
                    'email'         => $email
                ), " `id` = '$id' ");
                $NHNTAK->insert("biendongsodu", [
                    'username'      => $getUser['username'],
                    'note'          => "Chuyển nhượng hosting ".$check['domain']." cho thành viên ".$checkUser['username'],
                    'tongtien'      => 100,
                    'thoigian'      => gettime()
                ]);
                msg_success("Đã chuyển hosting thành công", BASE_URL('HistoryHost'), 1000);
            }
        }
    }
if(isset($_POST['type']))
{
    if($_POST['type'] == 'Register')
    {
    $username   = check_string($_POST['username']);
    $email      = check_string($_POST['email']);
    $password   = check_string($_POST['password']);
    $repassword = check_string($_POST['repassword']);
    if (empty($username = check_string($_POST['username']))) {
        exit(json_encode([
            'status'    => '1',
            'msg'       => 'Vui lòng nhập tên tài khoản']));
    }
    if (check_username($username) != True) {
        exit(json_encode([
            'status'    => '1',
            'msg'       => 'Vui lòng nhập định dạng tài khoản hợp lệ']));
    }
    if (strlen($username) < 5 || strlen($username) > 64) {
        exit(json_encode([
            'status'    => '1',
            'msg'       => 'Tài khoản phải từ 5 đến 64 ký tự']));
    }
    if ($NHNTAK->num_rows("SELECT * FROM `users` WHERE `username` = '$username' ") > 0) {
        exit(json_encode([
            'status'    => '1',
            'msg'       => 'Tên tài khoản đã tồn tại']));
    }
    if (empty($_POST['password'])) {
        exit(json_encode([
            'status'    => '1',
            'msg'       => 'Vui lòng nhập mật khẩu']));
    }
    if (empty($_POST['repassword'])) {
        exit(json_encode(['status' => '1', 'msg' => 'Vui lòng nhập lại mật khẩu']));
    }
    if ($password != $repassword) {
        exit(json_encode(['status' => '1', 'msg' => 'Nhập lại mật khẩu không đúng']));
    }
    if (empty($_POST['email'])) {
        exit(json_encode(['status' => '1', 'msg' => 'Vui lòng nhập địa chỉ email']));
    }
    if (check_email($email) != true) {
        exit(json_encode(['status' => '1', 'msg' => 'Định dạng Email không đúng']));
    }
    if ($NHNTAK->num_rows("SELECT * FROM `users` WHERE `email` = '$email' ") > 0) {
        exit(json_encode(['status' => '1', 'msg' => 'Địa chỉ email đã tồn tại']));
    }
    if (strlen($password) < 3) {
        exit(json_encode(['status' => '1', 'msg' => 'Vui lòng đặt mật khẩu trên 3 ký tự']));
    }
    if ($NHNTAK->num_rows("SELECT * FROM `users` WHERE `ip` = '".myip()."' ") >= 3) {
        exit(json_encode(['status' => '1', 'msg' => 'Bạn đã đạt giới hạn tạo tài khoản']));
    }
    $secret = "6LfxhFYrAAAAAHdZRoRiNjVfFkeCvvGO589dQF7O";
    $ip = $_SERVER['REMOTE_ADDR'];
    $response = $_POST['captcha'];
    $url = "https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$response&remoteip=$ip";
    $fire = file_get_contents($url);
    $data = json_decode($fire);
    if ($data->success == false) {
        exit(json_encode(['status' => '1', 'msg' => 'Vui lòng xác nhận Captcha']));
    }else{
        $iscreate = $NHNTAK->insert("users", [
            'username'      => $username,
            'email'         => $email,
            'password'      => md5($password),
            'banned'        => 0,
            'money'         => 0,
            'level'         => 'thanhvien',
            'ip'            => myip(),
            'createdate'    => gettime(),
        ]);
    if ($iscreate) {
        $_SESSION['username'] = $username;
        exit(json_encode(['status' => '2', 'msg' => 'Tạo tài khoản thành công', BASE_URL('Auth/Login'), 2000]));
    } else {
        exit(json_encode(['status' => '1', 'msg' => 'VUI LÒNG LIÊN HỆ CHỦ SỞ HỮU: 0337816872']));
    }
            }
}
if(isset($_POST['type']))
{
    if($_POST['type'] == 'UpdatePass')
    {
    if($NHNTAK->site('status_demo') == 'ON')
    {
         nnl_error("KHÔNG THỂ THAO TÁC Ở WEB DEMO");
    }
    $password   = check_string($_POST['password']);
    $repassword = check_string($_POST['repassword']);
    if (empty($password)) {
        nnl_error("Vui lòng nhập mật khẩu mới");
    }
    if (empty($password)) {
        nnl_error("Vui lòng nhập lại mật khẩu mới");
    }
    if($password != $repassword)
    {
        nnl_error("Nhập lại mật khẩu không đúng");
    }
    $NHNTAK->update("users", [
        'password'      => md5($password),
    ], " `username` = '".$getUser['username']."' ");
    nnl_success_time('Thay đổi mật khẩu thành công ', BASE_URL('Auth/Logout'), 1000);
}
if(isset($_POST['type']))
{
    if($_POST['type'] == 'UpdateEmail')
    {
    if($NHNTAK->site('status_demo') == 'ON')
    {
        nnl_error("KHÔNG THỂ THAO TÁC Ở WEB DEMO");
    }
    $email = xss($_POST['email']);
    if (empty($email)) {
        nnl_error("Vui lòng nhập địa chỉ email");
    }
    if (check_email($email) != true) {
        nnl_error('Định dạng Email không đúng');
    }
    $row = $NHNTAK->get_row(" SELECT * FROM `users` WHERE `email` = '$email' AND `username` = '".$getUser['username']."'");
    if ($row) {
         nnl_error('Địa chỉ email đã tồn tại');
    }
    $NHNTAK->update("users", [
        'email'     => $email,
    ], " `username` = '".$getUser['username']."' ");
    nnl_success_time('Thay đổi email thành công', BASE_URL('user/profile'), 2000);
            }
        }
     }
   }