<?php
require_once "../../config/config.php";
require_once "../../config/function.php";
require_once "../../config/giohang.php";
require_once('../../class/class.smtp.php');
require_once('../../class/PHPMailerAutoload.php');
require_once('../../class/class.phpmailer.php');

 // FILE CART BY NGUYỄN KHÔI

$Cart = new Cart();
if ($_POST['type'] == 'add_products') {
    $id = check_string($_POST['id']);
    $row = $NHNTAK->get_row("SELECT * FROM `SourceCode` WHERE `id` = '$id' ");
    if (!$row) {
        $data = json_encode([
            'status'    => '1',
            'msg'       => 'Mã nguồn không tồn tại trong hệ thống'
        ]);
        die($data);
    }
    $CreateCart = $Cart->addToCart($id, $row['price'], $row['name'], $row['image']);
    if($CreateCart)
    {
        $data = json_encode([
            'status'    => '2',
            'msg'       => 'Đã thêm sản phẩm vào giỏ hàng'
        ]);
        die($data);
    }
    else
    {
        $data = json_encode([
            'status'    => '1',
            'msg'       => 'Sản phẩm đã tồn tại trong giỏ hàng'
        ]);
        die($data);
    }
}

if ($_POST['type'] == 'payments') {
    if (empty($_SESSION['username'])) {
        exit(json_encode(['status' => '1', 'msg' => 'Không thể thao tác khi chưa Login']));
    }
    if (empty($_SESSION['cart'])) {
        exit(json_encode(['status' => '1', 'msg' => 'Không có gì trong giỏ hàng']));
    }
    foreach ($_SESSION['cart'] as $id => $item) {
    $row = $NHNTAK->get_row("SELECT * FROM `SourceCode` WHERE `id` = '$id' ");
    if (!$row) {
        exit(json_encode(['status' => '1', 'msg' => 'Mã nguồn không tồn tại trong hệ thống']));
    }
    if ($getUser['money'] < $row['price']) {
        exit(json_encode(['status' => '1', 'msg' => 'Số dư không đủ để thực hiện giao dịch']));
    }
    $NHNTAK->insert("dongtien", [
            'sotientruoc'   => $getUser['money'],
            'sotienthaydoi' => $price,
            'thoigian'      => gettime(),
            'noidung'       => 'Thanh Toán Source code #'.$name.'',
            'username'      => $getUser['username']
        ]);
        $isBuy = $NHNTAK->tru("users", "money", $price, " `username` = '".$getUser['username']."'");  
        $NHNTAK->insert("HistorySource", [
            'username'      => $getUser['username'],
            'name'          => $row['name'],
            'link'          => $row['link'],
            'price'         => $row['price'],
            'time'          => gettime()
        ]);
        unset($_SESSION['cart'][$id]);
}
}
        $_SESSION['cart'] = array_values($_SESSION['cart']);
        exit(json_encode(['status' => '2', 'msg' => 'Thanh toán mã nguồn thành công']));