<?php
function getWhoisInfo($domain) {
    // Thay thế DOMAIN_API_URL nếu cần tuỳ chỉnh thêm
    $apiUrl = "https://whois.inet.vn/api/whois/domainspecify/" . urlencode($domain);

    $ch = curl_init();

    curl_setopt_array($ch, [
        CURLOPT_URL => $apiUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false, // nên bật lại nếu dùng SSL chuẩn
        CURLOPT_CUSTOMREQUEST => 'GET'
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        return [
            'success' => false,
            'error' => curl_error($ch)
        ];
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        return [
            'success' => false,
            'error' => "HTTP Error Code: $httpCode"
        ];
    }

    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return [
            'success' => false,
            'error' => "JSON decode error: " . json_last_error_msg()
        ];
    }

    return [
        'success' => true,
        'data' => $data
    ];
}

// Sử dụng ví dụ
$domain = isset($_GET['domain']) ? $_GET['domain'] : 'example.vn';
$result = getWhoisInfo($domain);

header('Content-Type: application/json');
echo json_encode($result);