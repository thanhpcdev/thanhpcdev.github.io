<?php
require_once("../config/config.php");
require_once("../config/function.php");
if(time() - $NHNTAK->site($luuCron) < 300)
{
    die("Chưa thể cron lúc này");
}
$luuCron = explode('.', basename($_SERVER['PHP_SELF']))[0];
$NHNTAK->update("options", array(
    'value'        => time()
), " `key` = '$luuCron' ");
foreach($NHNTAK->get_list(" SELECT * FROM `historyhost` WHERE  `status` = 'huy' AND `hoantien` = '1' ORDER BY id DESC") as $row)
{
    $NHNTAK->update("historyhost", array(
        'hoantien'  => '',
    ), " `id` = '".$row['id']."' ");
    $NHNTAK->insert("biendongsodu", [
        'username'      => $row['username'],
        'note'          => "Lỗi Dịch vụ gói ".strtoupper($row['goi'])."",
        'tongtien'      => $row['tienlandau'],
        'thoigian'      => gettime()
    ]);
    
}