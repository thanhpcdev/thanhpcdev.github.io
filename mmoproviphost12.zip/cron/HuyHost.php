<?php
require_once("../config/config.php");
require_once("../config/function.php");
require_once('../class/class.smtp.php');
require_once('../class/PHPMailerAutoload.php');
require_once('../class/class.phpmailer.php');
$luuCron = explode('.', basename($_SERVER['PHP_SELF']))[0];
$NHNTAK->update("options", array(
    'value'        => time()
), " `key` = '$luuCron' ");
foreach($NHNTAK->get_list(" SELECT * FROM `historyhost` WHERE `status` = 'tamkhoa' AND `loairsl` = 'WHM' ORDER BY id DESC LIMIT 20") as $data)
{
    if(($data['ngayhet'] + 259200) < time())
    {
        $row =  $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '".$data['server']."' AND `status` = 'SHOW' AND `loairsl` = 'WHM' AND `theloai` = '".$data['type']."' AND `loai` = '".$data['loai']."' ");
        if($data['loai'] == 'reseller')
        {
            $JCS = json_decode(apiWHM($row['taikhoanrsl'], $row['matkhaursl'], $row['linkrsl'].':2087/json-api/terminatereseller?api.version=1&user='.$data['taikhoan'].'&terminatereseller=1'), true); 
        }
        else
        {
            $JCS = json_decode(apiWHM($row['taikhoanrsl'], $row['matkhaursl'], $row['linkrsl'].':2087/json-api/removeacct?api.version=1&username='.$data['taikhoan']), true); 
        }
        if(isset($JCS['metadata']['result']))
        {
            if($JCS['metadata']['result'] == 1)
            {
                $NHNTAK->update("historyhost", array(
                    'status'  => 'hethan'
                ), " `id` = '".$data['id']."' ");
            }
        }
    }
}