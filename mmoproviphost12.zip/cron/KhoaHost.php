<?php
require_once("../config/config.php");
require_once("../config/function.php");
require_once('../class/class.smtp.php');
require_once('../class/PHPMailerAutoload.php');
require_once('../class/class.phpmailer.php');
$luuCron = explode('.', basename($_SERVER['PHP_SELF']))[0];
$NHNTAK->update("options", array(
    'value'        => time()
), " `key` = '$luuCron' ");
foreach($NHNTAK->get_list(" SELECT * FROM `historyhost` WHERE `status` = 'hoatdong' AND `loairsl` = 'WHM' LIMIT 20") as $data)
{
    
    if($data['ngayhet'] < time())
    {
        $row =  $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '".$data['server']."' AND `status` = 'SHOW' AND `loairsl` = 'WHM' AND `theloai` = '".$data['type']."'");
        if($data['loai'] == 'reseller')
        {
            $JSC = json_decode(apiWHM($row['taikhoanrsl'], $row['matkhaursl'], $row['linkrsl'].':2087/json-api/suspendreseller?api.version=1&user='.$data['taikhoan'].'&reseller-only=0&reason='.urlencode('Hết hạn dịch vụ')), true); 
        }
        else
        {
            $JSC = json_decode(apiWHM($row['taikhoanrsl'], $row['matkhaursl'], $row['linkrsl'].':2087/json-api/suspendacct?api.version=1&user='.$data['taikhoan'].'&reason='.urlencode('Hết hạn dịch vụ')), true); 
        }
        if(isset(['metadata']['result']))
        {
            if($JSC['metadata']['result'] == 1)
            {
                $NHNTAK->update("historyhost", array(
                    'status'    => 'tamkhoa'
                    ), " `id` = '".$data['id']."' ");
            }
        }
    }
}