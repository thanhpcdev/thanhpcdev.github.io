<?php
/* TUANORI.COM - PHÁT TRIỂN MÃ NGUỒN 2022 - 2023 */
require_once("../config/config.php");
require_once("../config/function.php");
$options = array( 'encrypted' => true);
$luuCron = explode('.', basename($_SERVER['PHP_SELF']))[0];
$NHNTAK->update("options", array(
    'value'        => time()
), " `key` = '$luuCron' ");
foreach($NHNTAK->get_list(" SELECT * FROM `historyhost` WHERE `status` = 'reset' AND `loairsl` = 'WHM' ORDER BY id DESC LIMIT 3") as $data)
{
    $check  = $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '".$data['server']."' AND `status` = 'SHOW'");
    if($check)
    {
        $data2 = json_decode(apiWHM($check['taikhoanrsl'], $check['matkhaursl'], $check['linkrsl'].':2087/json-api/removeacct?api.version=1&username='.$data['taikhoan']), true);
        if(isset($data2['metadata']['result']))
        {
            if($data2['metadata']['result'] == 1)
            {
                $NHNTAK->update("historyhost", array(
                    'status'    => 'dangtao'
                ), " `id` = '".$data['id']."' ");
                
            }
            else
            {
                $data_msg['type'] = 'error';
                $data_msg['title'] = 'Thông Báo';
                $data_msg['message'] = "Hosting có tên miền <b>".$data['domain']."</b> reset thất bại. <b>Bạn vui lòng kiểm tra thông tin lại. Hoặc liên hệ với ADMIN để được hỗ trợ</b>";
                $pusher->trigger($data['username'], 'realtime', $data_msg);
                $NHNTAK->update("historyhost", array(
                        'status'    => 'hoatdong'
                    ), " `id` = '".$data['id']."' ");
            }
        }
    }
    else
    {
        $data_msg['type'] = 'error';
        $data_msg['title'] = 'Thông Báo';
        $data_msg['message'] = "Hosting có tên miền <b>".$data['domain']."</b> reset thất bại. <b>Bạn vui lòng kiểm tra thông tin lại. Hoặc liên hệ với ADMIN để được hỗ trợ</b>";
        $pusher->trigger($data['username'], 'realtime', $data_msg);
        $NHNTAK->update("historyhost", array(
                'status'    => 'hoatdong'
            ), " `id` = '".$data['id']."' ");
    }
}