<?php
require_once("../config/config.php");
require_once("../config/function.php");
$options = array( 'encrypted' => true);
$luuCron = explode('.', basename($_SERVER['PHP_SELF']))[0];
$NHNTAK->update("options", array(
    'value'        => time()
), " `key` = '$luuCron' ");
foreach($NHNTAK->get_list(" SELECT * FROM `serverhost` WHERE `status` = 'SHOW' AND `loairsl` = 'WHM' ORDER BY id DESC") as $data)
{
    $data2 = json_decode(apiWHM($data['taikhoanrsl'], $data['matkhaursl'], $data['linkrsl'].':2087/json-api/listaccts?api.version=1'), true);
    $update = $NHNTAK->update("serverhost", array(
        'number_account'    => count($data2['data']['acct'])
    ), " `id` = '".$data['id']."' ");
    if(isset($data2['cpanelresult']))
    {
        echo 'Tài khoản '.$data['taikhoanrsl'].' kiểm tra thất bại <br/>';
    }
    else
    {
        echo 'Tài khoản '.$data['taikhoanrsl'].' kiểm tra thành công <br/>';
    }
}