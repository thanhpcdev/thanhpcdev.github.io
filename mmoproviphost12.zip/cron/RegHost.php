<?php
require_once("../config/config.php");
require_once("../config/function.php");
$options = array( 'encrypted' => true);
$luuCron = explode('.', basename($_SERVER['PHP_SELF']))[0];
$NHNTAK->update("options", array(
    'value'        => time()
), " `key` = '$luuCron' ");
foreach($NHNTAK->get_list(" SELECT * FROM `historyhost` WHERE `status` = 'dangtao' AND `loairsl` = 'WHM' AND `hoantien` IS NULL ORDER BY id DESC LIMIT 3") as $data)
{
    $check = $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '".$data['server']."' AND `theloai` = '".$data['type']."' AND `loai` = '".$data['loai']."' AND `loairsl` = '".$data['loairsl']."'");
    if($check)
    {
        $whmusername = $check['taikhoanrsl'];
        $whmpassword = $check['matkhaursl'];
        $linklogin = $check['linkrsl'];
        $tam = $data['domain'];
        $tam1 = str_split($tam);
        for($i = 1; $i <= strlen($tam); $i++)
        {
            if($tam1[$i] == '.')
            {
                $tam = substr($tam, 0, $i).substr($tam, $i + 1, strlen($tam) );                                    
            }
        }
        if(isset($data['taikhoan']) && isset($data['matkhau']))
        {
            $taikhoan   = $data['taikhoan'];
            $matkhau    = $data['matkhau'];
        }
        else
        {
            $tktam      = substr($tam,0,15);
            $taikhoan   = 't'.$tktam;
            $matkhau    = 'Mk'.rand(1,9).rand(22,88).time();
        }
        if($check['ownership'] == 'owner')
        {
            $goiChuan = $data['goi'];
        }
        else
        {
            $goiChuan = $whmusername.'_'.$data['goi'];
        }
        if($data['loai'] == 'reseller')
        {
            $a = 'Hosting';
            $reseller = '';
        }
        $query      = $linklogin.':2087/json-api/createacct?api.version=1&username='.$taikhoan.'&domain='.$data['domain'].'&plan='.$goiChuan.'&featurelist=default&password='.$matkhau.'&ip=n&cgi=1&hasshell=1&contactemail='.$data['email'].'&cpmod=paper_lantern'.$reseller.'&language=vi'; 
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
        curl_setopt($curl, CURLOPT_HEADER,0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER,1); 
        $header[0] = "Authorization: Basic " . base64_encode($whmusername.":".$whmpassword) . "\n\r";
        curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
        curl_setopt($curl, CURLOPT_URL, $query);
        $result = curl_exec($curl); 
        curl_close($curl);
        $datajson = json_decode($result, true);
        if($data['loai'] == 'reseller')
        {
            apiWHM($whmusername, $whmpassword, $data['linklogin'].':2087/json-api/setacls?api.version=1&reseller='.$taikhoan.'&acllist=tuanreseller');
            if($object = $TUANORI->get_row(" SELECT * FROM `goihost` WHERE `nameGoi` = '".$data['goi']."' "))
            {
                if($object['bangthong'] == 'unlimited')
                {
                    $bangthong2 = '18446744073709551615';
                }
                else
                {
                    $bangthong2 = $object['bangthong'];
                }
                apiWHM($whmusername, $whmpassword, $data['linklogin'].':2087/json-api/setresellerlimits?api.version=1&user='.$taikhoan.'&diskspace_limit='.$object['dungluong'].'&enable_overselling_bandwidth=0&enable_overselling_diskspace=0&bandwidth_limit='.$bangthong2.'&enable_resource_limits=1');
            }
        }
    }
}