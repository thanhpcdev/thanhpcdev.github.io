<?php
require_once("../config/config.php");
require_once("../config/function.php");
$luuCron = explode('.', basename($_SERVER['PHP_SELF']))[0];
$NHNTAK->update("options", array(
    'value'        => time()
), " `key` = '$luuCron' ");

foreach($NHNTAK->get_list(" SELECT * FROM `historyhost` WHERE `status` = 'hoatdong' AND `loairsl` = 'WHM' AND `autogiahan` = 'YES'") as $data)
{
    if($data['ngayhet'] < (time() + 93600))
    {
        if($NHNTAK->getUser($data['username'])['money'] >= $data['tongtien'])
        {
            $tuan = curl_get(BASE_URL('api/thaotac?token='.$NHNTAK->getUser($data['username'])['tokenapi'].'&type=1&username='.$data['taikhoan'].'&month=1'));
            /*TUANORIIT*/
        }
    }
}