<?php
require_once("../config/config.php");
require_once("../config/function.php");
require_once('../class/class.smtp.php');
require_once('../class/PHPMailerAutoload.php');
require_once('../class/class.phpmailer.php');
$luuCron = explode('.', basename($_SERVER['PHP_SELF']))[0];
$NHNTAK->update("options", array(
    'value'        => time()
), " `key` = '$luuCron' ");
$i = 1;
foreach($NHNTAK->get_list(" SELECT * FROM `users` WHERE `banned` = 'OFF' AND `online` = 'ONLINE'") as $data2)
{
    $tt1 = gettime2(time() - 300);
    if($tt1 > $data2['operatingtime'])
    {
        $NHNTAK->update("users", array(
            'online' => 'OFFLINE'
        ), "username = '".$data2['username']."' ");
    }
}
foreach($NHNTAK->get_list(" SELECT * FROM `serverhost` WHERE `status` = 'SHOW' AND `loairsl` = 'WHM' ORDER BY id DESC") as $data)
{
    $curldta = json_decode(apiWHM($data['taikhoanrsl'], $data['matkhaursl'], $data['linkrsl'].":2087/json-api/listaccts?api.version=1"), true);
    if(isset($curldta['data']['acct']))
    {
        foreach($curldta['data']['acct'] as $tt)
        {
            $row = $NHNTAK->get_row(" SELECT * FROM `historyhost` WHERE `server` = '".$data['nameGetServer']."' AND `taikhoan` = '".$tt['user']."' AND `status` = 'hoatdong'");
            if($row)
            {
                if($tt['suspended'] == 1)
                {
                    $NHNTAK->update("historyhost", array(
                        'status'    => 'tamkhoa',
                        'note'      => $tt['suspendreason']
                    ), " `id` = '".$row['id']."' ");
                }
            }
        }
    }
}