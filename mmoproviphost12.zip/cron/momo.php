<?php
require_once("../config/config.php");
require_once("../config/function.php");
$NHNTAK->update("options", array(
    'value'        => time()
), " `key`         = '$luuCron' ");
if(!$NHNTAK->site('token_momo'))
{
    die('Dữ liệu chưa có để api');
}
$data = json_decode(curl_get("https://api.web2m.com/historyapimomo/".$NHNTAK->site('token_momo')), true);
foreach($data['momoMsg']['tranList'] as $mm)
{
    $sotien = $mm['amount'];
    $cmt    = $mm['comment'];
    $io     = $mm['io'];
    $magd   = $mm['tranId'];
    $id     = get_id_bank($cmt);
    if($io == 1)
    {
        if(is_numeric($id))
        {
            $check = $NHNTAK->get_row(" SELECT * FROM `users` WHERE `id` = '$id'");
            if($check)
            {
                $check2 = $NHNTAK->get_row(" SELECT * FROM `napatm` WHERE `hinhthuc` = 'MOMO' AND `magd` = '$magd'");
                if(!$check2)
                {
                    $isMoney = $NHNTAK->cong("users", "money", $sotien, " `username` = '".$check['username']."'");
                    $isMoney2 = $NHNTAK->cong("users", "total_money", $sotien, " `username` = '".$check['username']."'");
                    if($isMoney && $isMoney2)
                    {
                        $dulieuv2['type'] = 'success';
                        $dulieuv2['title'] = 'Thông Báo';
                        $dulieuv2['message'] = "Bạn đã nạp thành công ".number_format($sotien)."đ vào tài khoản qua MOMO";
                        $pusher->trigger($check['username'], 'realtime', $dulieuv2);
                        $create = $NHNTAK->insert("napatm", [
                            'username'       => $check['username'],
                            'hinhthuc'       => 'MOMO',
                            'magd'           => $magd,
                            'sotien'         => $sotien,
                            'thoigian'       => gettime(),
                            'ndnaptien'      => $cmt
                        ]);
                        thongbao("Thành viên ".$check['username']." vừa nạp ".format_cash($sotien)." vào tài khoản lúc ".format_date(time()).". Hình thức qua MOMO");
                    }
                }
            }
        }
    }
}