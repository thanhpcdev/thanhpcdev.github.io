<?php
require_once("../config/config.php");
require_once("../config/function.php");

$luuCron = explode('.', basename($_SERVER['PHP_SELF']))[0];
$NHNTAK->update("options", array(
    'value'        => time()
), " `key` = '$luuCron' ");
if(!$NHNTAK->site('tk_tsr'))
{
    die('Chưa Có API');
}
$data = json_decode(curl_get(BASE_URL('/api/thesieure/')), true);
foreach($data as $tsr)
{
    if (strlen(strstr($tsr['money_cost'], '-')) > 0)
    {
        continue;
    }
    else
    {
        $amount = intval(preg_replace("/đ|,|\-|\+/i", '', $tsr['money_cost']));
        $magd   = $tsr['trading_code'];
        $cmt    = $tsr['content_send'];
        $id     = get_id_bank($cmt);
        if($id)
        {
            $check = $NHNTAK->get_row(" SELECT * FROM `users` WHERE `id` = '$id'");
            if($check)
            {
                $check2 = $NHNTAK->get_row(" SELECT * FROM `napatm` WHERE `hinhthuc` = 'THESIEURE' AND `magd` = '$magd'");
                if(!$check2)
                {
                    $isMoney = $NHNTAK->cong("users", "money", $amount, " `username` = '".$check['username']."'");
                    $isMoney2 = $NHNTAK->cong("users", "total_money", $amount, " `username` = '".$check['username']."'");
                    if($isMoney && $isMoney2)
                    {
                        $dulieuv2['type'] = 'success';
                        $dulieuv2['title'] = 'Thông Báo';
                        $dulieuv2['message'] = "Bạn đã nạp thành công <b>".number_format($amount)."đ</b> vào tài khoản qua THESIEURE";
                        $pusher->trigger($check['username'], 'realtime', $dulieuv2);
                        $create = $NHNTAK->insert("napatm", [
                            'username'       => $check['username'],
                            'hinhthuc'       => 'THESIEURE',
                            'magd'           => $magd,
                            'sotien'         => $amount,
                            'thoigian'       => gettime(),
                            'ndnaptien'      => $cmt
                        ]);
                        thongbao("Khách hàng ".$check['username']." vừa nạp thành công ".format_cash($amount)."đ vào tài khoản qua THESIEURE");
                    }
                }
            }
        }
    }
}