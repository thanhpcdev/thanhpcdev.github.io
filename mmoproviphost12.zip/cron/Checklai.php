<?php
require_once("../config/config.php");
require_once("../config/function.php");
$luuCron = explode('.', basename($_SERVER['PHP_SELF']))[0];
$NHNTAK->update("options", array(
    'value'        => time()
), " `key` = '$luuCron' ");
foreach($NHNTAK->get_list(" SELECT * FROM `historyhost` WHERE  `status` = 'huy' AND `hoantien` = '1' ORDER BY id DESC") as $row)
{
    $rsl = $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '".$row['server']."' AND `status` = 'SHOW' AND `loai` = '".$row['loai']."' AND `loairsl` = 'WHM'");
    if($rsl)
    {
        $api = json_decode(apiWHM($rsl['taikhoanrsl'], $rsl['matkhaursl'], $rsl['linkrsl'].":2087/json-api/get_domain_info?api.version=1"), true);
        if(isset($api['data']['domains']))
        {
            foreach($api['data']['domains'] as $tuan)
            {
                $mien = $tuan['domain'];
                if($mien == $row['domain'])
                {
                    $NHNTAK->update("historyhost", array(
                        'status'    => 'hoatdong',
                        'hoantien'  => NULL,
                        'note'      => ''
                    ), " `id` = '".$row['id']."' ");
                }
            }
        }
    }
}