<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'QUẢN LÝ NGÂN HÀNG | '.$NHNTAK->site('tenweb');
    require_once(__DIR__."/Header.php");
    require_once(__DIR__."/Sidebar.php");
?>
<?php
if(isset($_GET['delete']) && $getUser['level'] == 'admin')
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_error("KHÔNG THỂ THAO TÁC Ở WEB DEMO", "Bank", 2000);
    }
    $delete = check_string($_GET['delete']);
    $NHNTAK->remove("bank", " `id` = '$delete' ");
    admin_msg_success("Xóa thành công", BASE_URL("Bank"), 300);
}

if(isset($_POST['btnThemNganHang']) && $getUser['level'] == 'admin') 
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_warning("Chức năng này không khả dụng trên trang web DEMO!", "", 2000);
    }
    $isInsert = $NHNTAK->insert("bank", array(
        'name' => check_string($_POST['name']),
        'stk' => check_string($_POST['stk']),
        'logo' => check_string($_POST['logo']),
        'bank_name' => check_string($_POST['bank_name']),
        'ghichu' => check_string($_POST['ghichu'])
    ));
    if($isInsert)
    {
        admin_msg_success("Thêm thành công", '', 1000);
    }
}

if(isset($_POST['btnSave']) && $getUser['level'] == 'admin') 
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_warning("Chức năng này không khả dụng trên trang web DEMO!", "", 2000);
    }
    $NHNTAK->update("bank", array(
        'name' => check_string($_POST['name']),
        'stk' => check_string($_POST['stk']),
        'logo' => check_string($_POST['logo']),
        'bank_name' => check_string($_POST['bank_name']),
        'ghichu' => check_string($_POST['ghichu'])
    ), " `id` = '".check_string($_POST['id'])."' ");
    admin_msg_success("Lưu thành công", '', 1000);
}

if(isset($_POST['btnSaveOption']) && $getUser['level'] == 'admin')
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_error("KHÔNG THỂ THAO TÁC Ở WEB DEMO", "", 2000);
    }
    foreach ($_POST as $key => $value)
    {
        $NHNTAK->update("options", array(
            'value' => $value
        ), " `key` = '$key' ");
    }
    admin_msg_success('Lưu thành công', '', 500);
}
?>
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Bank</h1>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-outline card-primary">
                    <div class="card-header">
                        <h3 class="card-title">LIST OF PAYMENT INFORMATION</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="datatable" class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>NGÂN HÀNG</th>
                                        <th>LOGO</th>
                                        <th>CHỦ TÀI KHOẢN</th>
                                        <th>STK</th>
                                        <th width="20%">THAO TÁC</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $i = 0 ; foreach($NHNTAK->get_list(" SELECT * FROM `bank` ORDER BY id DESC ") as $row){ ?>
                                 <tr>
                                     <td><?=$row['name'];?></td>
                                     <td><img src="<?=list_img_bank($row['logo']);?>" height="50px;" /></td>
                                     <td><?=$row['bank_name'];?></td>
                                     <td><?=$row['stk'];?></td>
                                     <td>
                                        <a type="button" href="#" data-toggle="modal"
                                            data-target="#Edit<?=$row['id'];?>" class="btn btn-primary"><i
                                                class="fas fa-edit"></i>
                                            <span>EDIT</span></a>
                                        <a type="button"
                                            href="<?=BASE_URL('Admin/Bank?delete='.$row['id']);?>"
                                            class="btn btn-danger"><i class="fas fa-trash"></i>
                                            <span>DELETE</span></a>
                                     </td>
                                 </tr>
                                 <div class="modal fade" id="Edit<?=$row['id'];?>" tabindex="-1" role="dialog">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title" id="defaultModalLabel">EDIT NGÂN HÀNG
                                                    </h4>
                                                </div>
                                                <form action="" method="POST">
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <select class="custom-select" name="logo">
                                                                    <option value="MBBANK">MBBANK</option>
                                                                    <option value="ACB">ACB</option>
                                                                    <option value="Techcombank">Techcombank</option>
                                                                    <option value="TPBank">TPBank</option>
                                                                    <option value="THESIEURE">THESIEURE</option>
                                                                    <option value="MOMO">MOMO</option>
                                                                    <option value="VIETCOMBANK">VIETCOMBANK</option>
                                                                    <option value="ZaloPay">ZaloPay</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="name"
                                                                    placeholder="Nhập số tài khoản"
                                                                    value="<?=$row['name'];?>" class="form-control"
                                                                    required>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="stk"
                                                                    placeholder="Nhập số tài khoản"
                                                                    value="<?=$row['stk'];?>" class="form-control"
                                                                    required>
                                                                <input type="hidden" name="id" value="<?=$row['id'];?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="bank_name"
                                                                    placeholder="Nhập tên chủ tài khoản"
                                                                    class="form-control" value="<?=$row['bank_name'];?>"
                                                                    required>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="ghichu"
                                                                    placeholder="Ghi chú nạp tiền"
                                                                    value="<?=$row['ghichu'];?>" class="form-control"
                                                                    required>                                                    </div>
                                                        </div>
                                                    </div>
                                               
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger waves-effect"
                                                            data-dismiss="modal"><span>ĐÓNG</span></button>
                                                        <button type="submit" name="btnSave"
                                                            class="btn btn-primary waves-effect"><span>LƯU
                                                                LẠI</span></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                 <?php } ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        <a type="button" href="#" data-toggle="modal" data-target="#AddBank"
                            class="btn btn-info btn-block"><i class="fas fa-plus-circle"></i> <span>THÊM NGÂN HÀNG</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="card card-outline card-primary">
                    <div class="card-header">
                        <h3 class="card-title">LỊCH SỬ NẠP AUTO</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="datatable1" class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>NGÂN HÀNG</th>
                                        <th>USERNAME</th>
                                        <th>MÃ GD</th>
                                        <th>SỐ TIỀN</th>
                                        <th>NỘI DUNG</th>
                                        <th>THỜI GIAN</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 0 ; foreach($NHNTAK->get_list(" SELECT * FROM `napatm` ORDER BY id DESC ") as $row2){ ?>
                                    <tr>
                                        <td><?=$i++;?></td>
                                        <td><?=$row2['hinhthuc'];?></td>
                                        <td><a href="<?=BASE_URL('Admin/User/Edit/'.$NHNTAK->getUser($row2['username'])['id']);?>" target="_blank"><?=$row2['username'];?></a></td>
                                        <td><?=$row2['magd'];?></td>
                                        <td><?=format_cash($row2['sotien']).'đ';?></td>
                                        <td><?=$row2['ndnaptien'];?></td>
                                        <td><?=$row2['thoigian'];?></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>



<div class="modal fade" id="AddBank" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">THÊM NGÂN HÀNG</h4>
            </div>
            <form action="" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <div class="form-line">
                            <select class="custom-select" name="logo">
                                <option value="MBBANK">MBBANK</option>
                                <option value="ACB">ACB</option>
                                <option value="Techcombank">Techcombank</option>
                                <option value="TPBank">TPBank</option>
                                <option value="THESIEURE">THESIEURE</option>
                                <option value="MOMO">MOMO</option>
                                <option value="VIETCOMBANK">VIETCOMBANK</option>
                                <option value="ZaloPay">ZaloPay</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" name="name" placeholder="Nhập ngân hàng" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" name="stk" placeholder="Nhập số tài khoản" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" name="bank_name" placeholder="Nhập tên chủ tài khoản"
                                class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" name="ghichu" placeholder="Ghi chú nạp tiền"
                                class="form-control" required>
                        </div>
                    </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger waves-effect"
                        data-dismiss="modal"><span>ĐÓNG</span></button>
                    <button type="submit" name="btnThemNganHang" class="btn btn-primary waves-effect"><span>THÊM
                            NGAY</span></button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
</div>
</div>

<script>
$(function() {
    $("#datatable").DataTable({
        "responsive": true,
        "autoWidth": false,
    });
    $("#datatable1").DataTable({
        "responsive": true,
        "autoWidth": false,
    });
});
</script>

<?php 
    require_once(__DIR__."/Footer.php");
?>