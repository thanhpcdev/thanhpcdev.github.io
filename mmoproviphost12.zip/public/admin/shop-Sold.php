<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'QUẢN LÝ SHOP ĐÃ TẠO | '.$NHNTAK->site('tenweb');
    require_once(__DIR__."/Header.php");
    require_once(__DIR__."/Sidebar.php");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Đơn hàng tạo shop</h1>
          </div>
          <div class="col-sm-6">
           
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card card-outline card-red">
              <div class="card-header">
                <h3 class="card-title">Lịch sử tạo shop</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th width="5%">#</th>
                    <th>Username</th>
                    <th>Loại shop</th>
                    <th>Tên miền</th>
                    <th>Thời hạn</th>
                    <th>Tổng tiền</th>
                    <th>Tài khoản (ADMIN)</th>
                    <th>Mật khẩu (ADMIN)</th>
                    <th>Trạng thái</th>
                    <th>Thời gian tạo</th>
                    <th>Thao tác</th>
                  </tr>
                  </thead>
                 <tbody>
                    <?php
                    $i = 0;
                    foreach($NHNTAK->get_list(" SELECT * FROM `history_shop` ORDER BY id DESC ") as $row){
                    ?>
                   <tr>
                        <td><?=$i++;?></td>
                        <td><a href="<?=BASE_URL('Admin/User/Edit/'.$NHNTAK->getUser($row['username'])['id']);?>" target="_blank"><?=$row['username'];?></a></td>
                        <td><b><?=$row['title'];?></b></td>
                        <td><b><?=$row['domain'];?></b></td>
                        <td><b><?=$row['timeCreate'];?></b></td>
                        <td><b><?=format_cash($row['moneycreate']);?>đ</b></td>
                        <td><b><?=$row['tkadmin'];?></b></td>
                        <td><b><?=$row['mkadmin'];?></b></td>
                        <td><?=status($row['status']);?></td>
                        <td><?=$row['create_date'];?></td>
                        <td>
                            <a href="<?=BASE_URL('Admin/Shop/Edit/'.$row['id']);?>"
                                style="color:white;"
                                class="btn btn-info btn-sm btn-icon-left m-b-10" type="button">
                                <i class="fas fa-edit mr-1"></i><span class="">Edit</span>
                            </a>
                            
                        </td>
                    </tr>
                    <?php }?>
                </tbody>
                  <tfoot>
                  <tr>
                    <th width="5%">#</th>
                    <th>Username</th>
                    <th>Loại shop</th>
                    <th>Tên miền</th>
                    <th>Thời hạn</th>
                    <th>Tổng tiền</th>
                    <th>Tài khoản (ADMIN)</th>
                    <th>Mật khẩu (ADMIN)</th>
                    <th>Trạng thái</th>
                    <th>Thời gian tạo</th>
                    <th>Thao tác</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php 
    require_once(__DIR__."/Footer.php");
?>