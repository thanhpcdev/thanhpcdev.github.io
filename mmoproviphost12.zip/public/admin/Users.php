<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'QUẢN LÝ THÀNH VIÊN | '.$NHNTAK->site('tenweb');
    require_once("../../public/admin/Header.php");
    require_once("../../public/admin/Sidebar.php");
?><?php
if(isset($_GET['dele']) && $getUser['level'] == 'admin')
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_error("KHÔNG THỂ THAO TÁC VÌ ĐÂY LÀ WEBSITE DEMO", "Users", 2000);
    }
  $id = check_string($_GET['dele']);
  $row2 = $NHNTAK->get_row(" SELECT * FROM `users` WHERE `id` = '$id' ");
  if(!$row2)
  {
      admin_msg_error("Thành viên không tồn tại", BASE_URL('Admin/Users'),  1000);
  }
  else
  {
      $delete = $NHNTAK->remove("users", " `id` = '$id' ");
      if($delete)
      {
          admin_msg_success("Xóa thành viên thành công", BASE_URL('Admin/Users'),  1000);
      }
      else
      {
          admin_msg_error("Xóa thất bại", BASE_URL('Admin/Users'),  1000);
      }
  }
}
?> 
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Quản lý thành viên</h1>
          </div>
          <div class="col-sm-6">
           
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card card-outline card-red">
              <div class="card-header">
                <h3 class="card-title">Danh sách thành viên</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th width="1%">STT</th>
                    <th>THÔNG TIN</th>
                    <th>VÍ</th>
                    <th>BẢO MẬT</th>
                    <th>CẤP BẬC</th>
                    <th>THAO TÁC</th>
                  </tr>
                  </thead>
                 <tbody>
                    <?php $i = 0; foreach($NHNTAK->get_list(" SELECT * FROM `users` WHERE `username` IS NOT NULL ORDER BY id DESC ") as $row){ ?>
                     <tr>
                        <td><b><?=$i++;?></b></td>
                        <td>
                            <ul>
                                <li>Tên đăng nhập: <b><?=$row['username'];?></b>[<b><?=$row['id'];?></b>]</li>
                                <li>Địa chỉ Email: <b style="color:green"><?=$row['email'];?></b></li>
                                <li>Tình trạng: <?=display_banned($row['banned']);?></li>
                            </ul>
                        </td>
                        <td>
                            <ul>
                                <li>Số dư khả dụng: <b
                                        style="color:blue"><?=format_cash($row['money']);?><sup>đ</sup></b>
                                </li>
                                <li>Tổng số tiền nạp: <b
                                        style="color:red"><?=format_cash($row['total_money']);?><sup>đ</sup></b>
                                </li>
                                <li>Số DOMAIN đã mua: <b><?=format_cash($NHNTAK->num_rows(" SELECT * FROM `hisdomain` WHERE `username` = '".$row['username']."' "));?></b></li>
                                </li>
                                <li>Số SHOP đã tạo: <b><?=format_cash($NHNTAK->num_rows(" SELECT * FROM `history_shop` WHERE `username` = '".$row['username']."' "));?></b></li>
                            </ul>
                        </td>
                        <td>
                            <ul>
                                <li>IP: <b><?=$row['ip'];?></b></li>
                                <li>Status: <?=display_trangthai($row['online']);?></b>
                                </li>
                                <li>Ngày đăng ký: <b><?=$row['createdate'];?></b></li>
                            </ul>
                        </td>
                        <td><?=display_level($row['level']);?></td>
                        <td>
                            <a aria-label=""
                                href="<?=BASE_URL('Admin/User/Edit/');?><?=$row['id'];?>"
                                style="color:white;"
                                class="btn btn-info btn-sm btn-icon-left m-b-10" type="button">
                                <i class="fas fa-edit mr-1"></i><span class="">Edit</span>
                            </a>
                            <a style="color:white;" href="<?=BASE_URL('Admin/Users?dele='.$row['id']);?>"
                                class="btn btn-danger btn-sm btn-icon-left m-b-10">
                                <i class="fas fa-trash mr-1"></i><span class="">Delete</span>
                            </a>
                        </td>
                    </tr>
                    <?php }?>
                </tbody>
                  <tfoot>
                  <tr>
                   <th width="1%">STT</th>
                    <th>THÔNG TIN</th>
                    <th>VÍ</th>
                    <th>BẢO MẬT</th>
                    <th>CẤP BẬC</th>
                    <th>THAO TÁC</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php 
    require_once("../../public/admin/Footer.php");
?>