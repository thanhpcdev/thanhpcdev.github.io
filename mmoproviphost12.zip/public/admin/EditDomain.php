<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'EDIT TÊN MIỀN | '.$NHNTAK->site('tenweb');
    require_once("../../public/admin/Header.php");
    require_once("../../public/admin/Sidebar.php");
?>
<?php
if(isset($_GET['id']) && $getUser['level'] == 'admin')
{
    $id     = check_string($_GET['id']);
    $row    = $NHNTAK->get_row(" SELECT * FROM `hisdomain` WHERE `id` = '$id' ");
    if(!$row)
    {
        admin_msg_error("Tên miền này không tồn tại", BASE_URL('Admin/Domain-Sold'), 2000);
    }
}
else
{
    admin_msg_error("Liên kết không hợp lệ", BASE_URL('Admin/Domain-Sold'), 1000);
}
if(isset($_POST['SaveAll']) && isset($row['username']) && $getUser['level'] == 'admin')
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
         admin_msg_error("KHÔNG THỂ THAO TÁC Ở WEB DEMO", "", 2000);
    }
    $status         = check_string($_POST['status']);
    if(!$status)
    {
        admin_msg_error("Vui lòng nhập đầy đủ thông tin", "", 1000);
    }
    if($money < 0)
    {
        admin_msg_error("Số tiền bạn nhập không hợp lệ", "", 1000);
    }
    if($row['status'] == 'huynohoan')
    {
        admin_msg_error("Tên miền này đã bị hủy, nên không thể thao tác tiếp được", "", 1000);
    }
    $update = $NHNTAK->update("hisdomain", array(
            'status'    => $status,
        ), " `id` = '".$row['id']."' ");
    if($update)
    {
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_error("KHÔNG THỂ THAO TÁC Ở WEB DEMO", "", 2000);
    }
        if($status == 'huynohoan')
        {
            $NHNTAK->insert("dongtien", [
                'sotientruoc'   => $getUser['money'],
                'sotienthaydoi' => $row['money'],
                'sotiensau'     => $getUser['money'],
                'thoigian'      => gettime(),
                'noidung'       => "Mua tên miền thất bại",
                'username'      => $getUser['username']
            ]);
        }
        admin_msg_success("Cập nhật thành công dữ liệu", "", 1000);
    }
    else
    {
        admin_msg_error("Cập nhật dữ liệu thất bại", "", 1000);
    }
}
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit domain name</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit domain name</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- Edit tên miền elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Domain Management <b><?=$row['domain'];?></b> <a href="<?=BASE_URL('Admin/Domain-Sold');?>" style="color:white;" class="btn btn-danger btn-sm btn-icon-left m-b-10" type="button"> <i class="fas fa-backward mr-1"></i><span class="">Quay lại</span></a></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Người mua</label>
                    <input type="text" class="form-control" placeholder="Người mua" name="username" value="<?=$row['username'];?>" disabled>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Tên miền</label>
                    <input type="text" class="form-control" name="domain" placeholder="Tên miền" value="<?=$row['domain'];?>" disabled>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Tổng tiền</label>
                    <input type="text" class="form-control" name="tongtien" placeholder="Tổng tiền" value="<?=$row['tongtien'];?>" disabled>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Năm mua</label>
                    <input type="text" class="form-control" name="nam" placeholder="Năm mua" value="<?=$row['nam'];?>" disabled>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Ngày mua</label>
                    <input type="text" class="form-control" placeholder="Ngày mua" value="<?=format_date($row['timemua']);?>" disabled>
                  </div>
                   <div class="form-group">
                    <label for="exampleInputPassword1">Ngày hết</label>
                    <input type="text" class="form-control" placeholder="Ngày hết" value="<?=format_date($row['timedie']);?>" disabled>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Nameserver</label>
                    <textarea name="nameserver" class="form-control" rows="3" placeholder="nameserver của khách hàng để trỏ miền" disabled><?=$row['nameserver'];?></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Status</label>
                    <select class="form-control select2" name="status">
                        <option value="xuly" <?php if($row['status'] == 'xuly') { echo 'selected'; };?>>Chờ xử lý</option>
                        <option value="thanhcong" <?php if($row['status'] == 'thanhcong') { echo 'selected'; };?>>Thành công</option>
                        <option value="huynohoan" <?php if($row['status'] == 'huy') { echo 'selected'; };?>>Hủy</option>
                    </select>
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="SaveAll" class="btn btn-primary">Save Now</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php 
    require_once("./Footer.php");
?>