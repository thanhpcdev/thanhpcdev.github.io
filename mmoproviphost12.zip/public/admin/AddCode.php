<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'THÊM MẪU SHOP | '.$NHNTAK->site('tenweb');
    require_once("../../public/admin/Header.php");
    require_once("../../public/admin/Sidebar.php");
?>
<?php
if(isset($_GET['delete']) && $getUser['level'] == 'admin')
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_error("KHÔNG THỂ THAO TÁC Ở WEB DEMO", "", 2000);
    }
    $delete = check_string($_GET['delete']);
    $NHNTAK->remove("SourceCode", " `id` = '$delete' ");
    admin_msg_success("Xóa thành công", BASE_URL("Admin/AddCode"), 300);
}

if(isset($_POST['btnThemMien']) && $getUser['level'] == 'admin') 
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_error("KHÔNG THỂ THAO TÁC Ở WEB DEMO", "", 2000);
    }
    $NHNTAK->insert("SourceCode", array(
        'name'         => check_string($_POST['name']),
        'price'        => check_string($_POST['price']),
        'image'       => check_string($_POST['image']),
        'link'    => check_string($_POST['link'])
    ));
    admin_msg_success("Thêm thành công", '', 1000);
}

if(isset($_POST['btnSave']) && $getUser['level'] == 'admin') 
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_error("KHÔNG THỂ THAO TÁC Ở WEB DEMO", "", 2000);
    }
    $NHNTAK->update("SourceCode", array(
        'name'         => check_string($_POST['name']),
        'price'        => check_string($_POST['price']),
        'image'       => check_string($_POST['image']),
        'link'    => check_string($_POST['link'])
    ), " `id` = '".check_string($_POST['id'])."' ");
    admin_msg_success("Lưu thành công", '', 1000);
}
?>
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Add Code</h1>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-outline card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Code For Sale</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="datatable" class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>NAME</th>
                                        <th>GIÁ TIỀN</th>
                                        <th>ẢNH</th>
                                        <th>LINK</th>
                                        <th width="20%">THAO TÁC</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $i = 0 ; foreach($NHNTAK->get_list(" SELECT * FROM `SourceCode` ORDER BY id DESC ") as $row){ ?>
                                 <tr>
                                     <td><?=$i++;?></td>
                                     <td><b><?=$row['name'];?></b></td>
                                     <td><?=format_cash($row['price']);?>đ</td>
                                     <td><?=$row['image'];?></td>
                                     <td><?=$row['link'];?></td>
                                     <td>
                                        <a type="button" href="#" data-toggle="modal"
                                            data-target="#Edit<?=$row['id'];?>" class="btn btn-primary"><i
                                                class="fas fa-edit"></i>
                                            <span>EDIT</span></a>
                                        <a type="button"
                                            href="<?=BASE_URL('Admin/AddCode?delete='.$row['id']);?>"
                                            class="btn btn-danger"><i class="fas fa-trash"></i>
                                            <span>DELETE</span></a>
                                     </td>
                                 </tr>
                                 <div class="modal fade" id="Edit<?=$row['id'];?>" tabindex="-1" role="dialog">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title" id="defaultModalLabel">EDIT CODE
                                                    </h4>
                                                </div>
                                                <form action="" method="POST">
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="name"
                                                                    placeholder="Tên Code"
                                                                    value="<?=$row['name'];?>" class="form-control"
                                                                    required>
                                                                <input type="hidden" name="id" value="<?=$row['id'];?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="price"
                                                                    placeholder="Số tiền"
                                                                    class="form-control" value="<?=$row['price'];?>"
                                                                    required>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="image"
                                                                    placeholder="Ảnh"
                                                                    class="form-control" value="<?=$row['image'];?>"
                                                                    required>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="link"
                                                                    placeholder="Link Code"
                                                                    class="form-control" value="<?=$row['link'];?>"
                                                                    required>
                                                            </div>
                                                        </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger waves-effect"
                                                            data-dismiss="modal"><span>ĐÓNG</span></button>
                                                        <button type="submit" name="btnSave"
                                                            class="btn btn-primary waves-effect"><span>LƯU
                                                                LẠI</span></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                 <?php } ?>
                                 </tbody>
                                <tfoot>
                                    <tr>

                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        <a type="button" href="#" data-toggle="modal" data-target="#AddBank"
                            class="btn btn-info btn-block"><i class="fas fa-plus-circle"></i> <span>THÊM CODE MỚI</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>



<div class="modal fade" id="AddBank" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">THÊM MẪU CODE MUỐN BÁN</h4>
            </div>
            <form action="" method="POST">
                <div class="modal-body">
                   <div class="form-group">
                        <div class="form-line">
                            <input type="text" name="name" placeholder="Tên Code" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <input type="number" name="price" placeholder="Số tiền" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" name="image" placeholder="Ảnh" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" name="link" placeholder="Link Code" class="form-control" required>
                        </div>
                    </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger waves-effect"
                        data-dismiss="modal"><span>ĐÓNG</span></button>
                    <button type="submit" name="btnThemMien" class="btn btn-primary waves-effect"><span>THÊM
                            NGAY</span></button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
</div>
<script>
$(function() {
    $("#datatable").DataTable({
        "responsive": true,
        "autoWidth": false,
    });
    $("#datatable1").DataTable({
        "responsive": true,
        "autoWidth": false,
    });
});
</script>
<?php 
    require_once("./Footer.php");
?>