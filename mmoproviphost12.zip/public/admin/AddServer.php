<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'ADD SERVER | '.$NHNTAK->site('tenweb');
    require_once("../../public/admin/Header.php");
    require_once("../../public/admin/Sidebar.php");
?>
<?php
if(isset($_GET['dele']) && $getUser['level'] == 'admin')
{
  $id = check_string($_GET['dele']);
  $row = $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `id` = '$id' ");
  if(!$row)
  {
      msg_error("Máy chủ không tồn tại", BASE_URL('Admin/Server'),  1000);
  }
  else
  {
      $delete = $NHNTAK->remove("serverhost", " `id` = '$id' ");
      if($delete)
      {
          msg_success("Xóa máy chủ thành công", BASE_URL('Admin/Server'),  1000);
      }
      else
      {
          msg_error("Xóa thất bại", BASE_URL('Admin/Server'),  1000);
      }
  }
}
if(isset($_POST['AddSubmit']) && $getUser['level'] == 'admin')
{
   $name   = check_string($_POST['nameServer']);
    $tk     = check_string($_POST['taikhoanrsl']);
    $mk     = check_string($_POST['matkhaursl']);
    $link   = check_string($_POST['linkrsl']);
    $ns     = check_string($_POST['nsNameServer']);
    $status = check_string($_POST['status']);
    $backup = check_string($_POST['backup']);
    if(!$name || !$tk || !$mk || !$link || !$ns || !$status || !$backup)
    {
        msg_error("Vui lòng nhập đầy đủ thông tin", "",  1000);
    }
    $nameGet = nameGetServer($name);
    if($NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '$nameGet' ") || $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `taikhoanrsl` = '$tk' AND `linkrsl` = '$link' "))
    {
        msg_error("Thông tin máy chủ đã tồn tại trong hệ thống", "",  1000);
    }
    $data = json_decode(apiWHM($tk, $mk, $link.':2087/json-api/listaccts?api.version=1'), true);
    apiWHM($tk, $mk, $link.':2087/json-api/save_style?api.version=1&company_name='.strtoupper($_SERVER['SERVER_NAME']));
    if(isset($data['cpanelresult']))
    {
        msg_error("Thông tin đăng nhập WHM không chính xác", "",  1000);
    }
    else if(isset($data['metadata']))
    {
        if($ownership == 'owner')
        {
            $theloai = 'ADMINWHM';
            $nc = 'ON';
        }
        else
        {
            $theloai = 'CPANELWHM';
            $nc = 'OFF';
        }
        $create = $NHNTAK->insert("serverhost", [
            'nameServer'        => $name,
            'nameGetServer'     => $nameGet,
            'taikhoanrsl'       => $tk,
            'matkhaursl'        => $mk,
            'linkrsl'           => $link,
            'loairsl'           => 'WHM',
            'nsNameServer'      => $ns,
            'nangcap'           => $nc,
            'backup'            => $backup,
            'number_account'    => count($data['data']['acct']),
            'status'            => $status,
            'ownership'         => check_string($_POST['ownership']),
            'theloai'           => $theloai,
            'loai'              => 'hosting'
        ]);
        if($create)
        {
            msg_success("Đã thêm dữ liệu thành công", "",  1000);
        }
        else
        {
            msg_error("Không thể ADD dữ liệu vào DATABASE", "",  1000);
        }
    }
    else
    {
        msg_error("Không thể load được dữ liệu từ RSL WHM này", "",  1000);
    }
}
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
      <div class="alert alert-info">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <h5>Thông báo</h5>
            <ul>
                <li>Hệ thống tự động kiểm tra được tài khoản, mật khẩu Reseller Hosting của quý khách đúng hay sai khi thêm vào.</li>
                <li>Sau khi thêm Reseller vào, quý khách cần cân nhắc khi xóa đi hoặc thay đổi sang 1 tài khoản Reseller khác. Vì nó sẽ làm ảnh hưởng tới tất cả dịch vụ hosting của khách hàng khi đã mua từ trước (Chỉ tính những hosting đã hoạt động)</li>
                <li>Khi bạn <b>khóa tài khoản</b> khách hàng trong CPANEL WHM, thì website sẽ cập nhật dữ liệu <b>tự động</b> theo CPANEL WHM.</li>
            </ul>
        </div>
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Thêm Server Hosting</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Thêm Server Hosting</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Thêm Server Hosting</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Tên Máy Chủ Hosting</label>
                    <input type="text" class="form-control" name="nameServer" placeholder="Việt Nam">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Tài Khoản RSL</label>
                    <input type="text" class="form-control" name="taikhoanrsl" placeholder="Tài Khoản RSL">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Mật Khẩu RSL</label>
                    <input type="text" class="form-control" name="matkhaursl" placeholder="Mật Khẩu RSL">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Link Login RSL (Chỉ Hỗ TRỢ WHM, Cổng 2087)</label>
                    <input type="text" class="form-control" name="linkrsl" placeholder="NULLED">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Name Server Máy Chủ (Mỗi nameserver 1 dòng)</label>
                    <textarea name="nsNameServer" class="form-control" rows="3" placeholder=""></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Backup</label>
                    <select class="custom-select rounded-0" name="backup">
                        <option value="YES">CÓ</option>
                        <option value="NO">KHÔNG</option>
                      </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Status</label>
                    <select class="custom-select rounded-0" name="status">
                        <option value="SHOW">ON</option>
                        <option value="OFF">OFF</option>
                      </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Quyền Sở Hữu</label>
                    <select class="custom-select rounded-0" name="ownership">
                        <option value="owner">Chủ sở hữu (Đã mua bản quyền cpanel)</option>
                        <option value="reseller">Người bán lại (Chỉ mua reseller)</option>
                    </select>
                    <i>Lưu ý: Khai báo sai sẽ dẫn đến dịch vụ bị lỗi</i>
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="AddSubmit" class="btn btn-primary">Add Dữ Liệu</button>
                </div>
              </form>
            </div>
            <!-- /.card -->

           
                    
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Danh sách máy chủ <b>Server Hosting</b></h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>STT</th>
                    <th>THÔNG TIN</th>
                    <th>TÀI KHOẢN</th>
                    <th>NAMESERVER</th>
                    <th>THAO TÁC</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                    $i = 0;
                    foreach($NHNTAK->get_list(" SELECT * FROM `serverhost` WHERE `loai` = 'hosting' ORDER BY id DESC ") as $row){
                    ?>
                  <tr>
                    <td><?=$i++;?></td>
                    <td>
                        <ul>
                            <li>Tên Máy Chủ: <b style="color:blue"><?=$row['nameServer'];?></b></li>
                            <li>Trạng Thái: <b style="color:red"><?=status_show($row['status']);?></b></li>
                            <li>Backup: <b style="color:red"><?=reView($row['backup']);?></b></li>
                            <li>Số tài khoản có trong RSL: <b style="color:red"><?=format_cash($row['number_account']);?></b></li>
                        </ul>
                    </td>
                    <td>
                        <ul>
                            <li>Tài Khoản RSL: <b style="color:blue"><?=$row['taikhoanrsl'];?></b></li>
                            <li>Mật Khẩu RSL: <b style="color:red"><?=$row['matkhaursl'];?></b></li>
                            <li>Link Login: <b style="color:red"><?=$row['linkrsl'];?></b></li>
                            <li>Quyền sỡ hữu: <?=reseller($row['ownership']);?></li>
                        </ul>
                    </td>
                     <td>
                        <ul>
                            <?php $acc = explode(PHP_EOL, $row['nsNameServer']); foreach($acc as $b) { ?>
                            <li><b style="color:blue"><?=$b;?></b></li>
                            <?php } ?>
                        </ul>
                    </td>
                    <td>
                        <a href="<?=BASE_URL('Admin/Server/Edit/'.$row['id']);?>" style="color:white;" class="btn btn-info btn-sm btn-icon-left m-b-10" type="button">
                            <i class="fas fa-edit mr-1"></i><span class="">Edit</span>
                        </a>
                        <a href="<?=BASE_URL('Admin/Goi/Add/'.$row['id']);?>" style="color:white;" class="btn btn-info btn-sm btn-icon-left m-b-10" type="button">
                            <i class="fas fa-plus mr-1"></i><span class="">Add Gói</span>
                        </a>
                        <a style="color:white;" href="<?=BASE_URL('Admin/Server/Delete/'.$row['id']);?>"
                            class="btn btn-danger btn-sm btn-icon-left m-b-10">
                            <i class="fas fa-trash mr-1"></i><span class="">Delete</span>
                        </a>
                    </td>
                  </tr>
                   <?php }?>
                  </tbody>
                  
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php 
    require_once("./Footer.php");
?>