<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <!-- Left navbar links -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="<?=BASE_URL('');?>" class="nav-link">HOME</a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="https://zalo.me/0589247964" target="_blank" class="nav-link">LIÊN HỆ ZALO</a>
                </li>
            </ul>
        </nav>
        <!-- /.navbar -->
        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Brand Logo -->
            <a href="<?=BASE_URL('Admin/Home');?>" class="brand-link">
                <center><img src="<?=$NHNTAK->site('logo');?>" width="100%"></center>
            </a>
            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="false">
                        <li class="nav-item has-treeview menu-open">
                            <a href="<?=BASE_URL('Admin/Home');?>" class="nav-link active">
                                <i class="nav-icon fas fa-tachometer-alt"></i>
                                <p>
                                    Dashboard
                                </p>
                            </a>
                        </li>
                        <li class="nav-header">QUẢN LÝ</li>
                        <li class="nav-item">
                            <a href="<?=BASE_URL('Admin/Users');?>" class="nav-link">
                                <i class="nav-icon fas fa-users"></i>
                                <p>
                                    Thành viên
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=BASE_URL('Admin/AddDomain');?>" class="nav-link">
                                <i class="nav-icon fas fa-globe"></i>
                                <p>
                                    thêm tên miền
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=BASE_URL('Admin/AddShop');?>" class="nav-link">
                                <i class="nav-icon fas fa-bars"></i> 
                                <p>
                                     thêm mẫu shop
                                </p>
                            </a>
                        </li>
                         </li>
                        <li class="nav-item">
                            <a href="<?=BASE_URL('Admin/Server');?>" class="nav-link">
                                <i class="nav-icon fas fa-bars"></i> 
                                <p>
                                     thêm WHM
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?=BASE_URL('Admin/AddCode');?>" class="nav-link">
                                <i class="nav-icon fas fa-bars"></i> 
                                <p>
                                     thêm mẫu code
                                </p>
                            </a>
                        </li>
                        <li class="nav-header">NẠP TIỀN</li>
                        <li class="nav-item">
                            <a href="<?=BASE_URL('Admin/Bank');?>" class="nav-link">
                                <i class="nav-icon fas fa-university"></i>
                                <p>
                                    Ngân hàng
                                </p>
                            </a>
                        </li>
                        <?php
          $mien = $NHNTAK->num_rows("SELECT * FROM `hisdomain` WHERE `status` = 'xuly' ");
          $shop = $NHNTAK->num_rows("SELECT * FROM `history_shop` WHERE `status` = 'xuly' ");
          $cards = $NHNTAK->num_rows("SELECT * FROM `cards` WHERE `status` = 'xuly' ");
          $bank = $NHNTAK->num_rows("SELECT * FROM `napatm` ");
          function check_soluong($data)
          {
              if($data >= 1)
              {
                  echo '<span class="badge badge-info right">'.format_cash($data).'</span>';
              }
          }
          ?>
          <li class="nav-item ">
            <a href="#" class="nav-link">
                <i class="nav-icon fas fa-history"></i>
                <p>
                    Lịch Sử
                    <i class="fas fa-angle-left right"></i>
                    <?=check_soluong($mien + $shop);?>
                </p>
            </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?=BASE_URL('Admin/Domain-Sold');?>"
                            class="nav-link ">
                            <i class="far fa-circle nav-icon"></i>
                            <?=check_soluong($mien);?>
                            <p>Lịch sử Mua Miền</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?=BASE_URL('Admin/Shop-Sold');?>"
                            class="nav-link ">
                            <i class="far fa-circle nav-icon"></i>
                            <?=check_soluong($shop);?>
                            <p>Lịch sử Tạo Shop</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?=BASE_URL('Admin/Cards');?>"
                            class="nav-link ">
                            <i class="far fa-circle nav-icon"></i>
                            <?=check_soluong($cards);?>
                            <p>Lịch sử Nạp Thẻ Cào</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?=BASE_URL('Admin/Bank');?>"
                            class="nav-link ">
                            <i class="far fa-circle nav-icon"></i>
                            <?=check_soluong($bank);?>
                            <p>Lịch sử Nạp ATM/MOMO</p>
                        </a>
                    </li>
                    </ul>
                    </li>
                        <li class="nav-header">CÀI ĐẶT</li>
                        <li class="nav-item">
                            <a href="<?=BASE_URL('Admin/Setting');?>" class="nav-link">
                                <i class="nav-icon fas fa-cog"></i>
                                <p>
                                    Cấu hình
                                </p>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>