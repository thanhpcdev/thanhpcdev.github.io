<?php
/* TUANORI.COM - PHÁT TRIỂN MÃ NGUỒN 2022 - 2023 */
    require_once("../../core/config.php");
    require_once("../../core/function.php");
    $title = 'EDIT SERVER | '.$TUANORI->site('tenweb');
    require_once("../../pages/admin/Head.php");
    require_once("../../pages/admin/Header.php");
    CheckLogin();
?>
<?php
if(isset($_GET['id']) && $getUser['level'] == 'admin')
{
    $id     = check_string($_GET['id']);
    $row    = $TUANORI->get_row(" SELECT * FROM `serverhost` WHERE `id` = '$id' ");
    if(!$row)
    {
        msg_error("Hosting này không tồn tại", BASE_URL('Admin/HistoryHost'), 2000);
    }
}
else
{
    msg_error("Liên kết không hợp lệ", BASE_URL('Admin/HistoryHost'), 1000);
}
if(isset($_POST['SaveData']) && isset($row['taikhoanrsl']) && $getUser['level'] == 'admin')
{
    $name   = check_string($_POST['nameServer']);
    $tk     = check_string($_POST['taikhoanrsl']);
    $mk     = check_string($_POST['matkhaursl']);
    $link   = check_string($_POST['linkrsl']);
    $ns     = check_string($_POST['nsNameServer']);
    $status = check_string($_POST['status']);
    if(!$name || !$tk || !$mk || !$link || !$ns || !$status)
    {
        msg_error("Vui lòng nhập đầy đủ thông tin", "",  1000);
    }
    $nameGet = nameGetServer($name);
    if(!$TUANORI->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '$nameGet' ") || !$TUANORI->get_row(" SELECT * FROM `serverhost` WHERE `taikhoanrsl` = '$tk' AND `linkrsl` = '$link' "))
    {
        msg_error("Thông tin máy chủ CHƯA tồn tại trong hệ thống. Nên không thể Edit", "",  1000);
    }
    if($status == 'SHOW')
    {
        $data = json_decode(apiWHM($tk, $mk, $link.':2087/json-api/listaccts?api.version=1'), true);
        if(isset($data['cpanelresult']))
        {
            msg_error("Thông tin đăng nhập WHM không chính xác", "",  1000);
        }
    }
    $update = $TUANORI->update("serverhost", array(
        'nameServer'    => $name,
        'nameGetServer' => $nameGet,
        'taikhoanrsl'   => $tk,
        'matkhaursl'    => $mk,
        'linkrsl'       => $link,
        'loairsl'       => 'WHM',
        'nsNameServer'  => $ns,
        'status'        => $status
    ), " `id` = '".$row['id']."' ");
    if($update)
    {
        msg_success("Đã lưu dữ liệu vào DATABASE thành công", "",  1000);
    }
    else
    {
        msg_error("Không thể lưu dữ liệu vào DATABASE. Liên hệ zalo: 0812665001 để được hỗ trợ", "",  1000);
    }
}
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit Server</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit Server</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- Edit lịch sử mua hosting elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Edit server <b><?=$row['nameServer'];?></b> <?=status_show($row['status']);?></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
               <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Tên Máy Chủ Hosting</label>
                    <input type="text" class="form-control" name="nameServer" value="<?=$row['nameServer'];?>" placeholder="Việt Nam">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Tài Khoản RSL</label>
                    <input type="text" class="form-control" name="taikhoanrsl" value="<?=$row['taikhoanrsl'];?>" placeholder="Tài Khoản RSL">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Mật Khẩu RSL</label>
                    <input type="text" class="form-control" name="matkhaursl" value="<?=$row['matkhaursl'];?>" placeholder="Mật Khẩu RSL">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Link Login RSL (Chỉ Hỗ TRỢ WHM, Cổng 2087)</label>
                    <input type="text" class="form-control" name="linkrsl" value="<?=$row['linkrsl'];?>" placeholder="Link Login RSL">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Name Server Máy Chủ (Mỗi nameserver 1 dòng)</label>
                    <textarea name="nsNameServer" class="form-control" rows="3" placeholder="NameServer (Mỗi nameserver 1 dòng)"><?=$row['nsNameServer'];?></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Status</label>
                    <select class="custom-select rounded-0" name="status">
                        <?php
                        if($row['status'] == 'SHOW')
                        {
                            echo '<option value="SHOW">ON</option>';
                        }
                        else
                        {
                            echo '<option value="OFF">OFF</option>';
                        }
                        ?>
                        <option value="SHOW">ON</option>'
                        <option value="OFF">OFF</option>
                      </select>
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="SaveData" class="btn btn-primary">Lưu Dữ Liệu</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
          </div>
         
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    
    <!-- /.content -->
  </div>
  
 <?php
    require_once("../../pages/admin/Footer.php");
?>