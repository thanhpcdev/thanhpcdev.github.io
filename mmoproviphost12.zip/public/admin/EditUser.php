<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'CHỈNH SỬA THÀNH VIÊN | '.$NHNTAK->site('tenweb');
    require_once("../../public/admin/Header.php");
    require_once("../../public/admin/Sidebar.php");
?>
<?php
if(isset($_GET['id']) && $getUser['level'] == 'admin')
{

    $row = $NHNTAK->get_row(" SELECT * FROM `users` WHERE `id` = '".check_string($_GET['id'])."'  ");
    if(!$row)
    {
        admin_msg_error("Người dùng này không tồn tại", BASE_URL(''), 500);
    }
}
else
{
    admin_msg_error("Liên kết không tồn tại", BASE_URL(''), 0);
}

if(isset($_POST['btnCongTien']) && isset($_POST['value']) && isset($row['username']) && $getUser['level'] == 'admin')
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_error("KHÔNG THỂ THAO TÁC VÌ ĐÂY LÀ WEBSITE DEMO", "", 2000);
    }
    $value = check_string($_POST['value']);
    $ghichu = check_string($_POST['ghichu']);
    if($value <= 0)
    {
        admin_msg_error("Vui lòng nhập số tiền hợp lệ", "", 2000);
    }
    $create = $NHNTAK->insert("dongtien", [
        'sotientruoc' => $row['money'],
        'sotienthaydoi' => $value,
        'sotiensau' => $row['money'] + $value,
        'thoigian' => gettime(),
        'noidung' => 'Admin cộng tiền ('.$ghichu.')',
        'username' => $row['username']
    ]);
    if($create)
    {
        $NHNTAK->cong("users", "money", $value, " `username` = '".$row['username']."' ");
        admin_msg_success("Cộng tiền thành công!", "", 2000);
    }
    else
    {
        admin_msg_error("Vui lòng liên hệ kỹ thuật Zalo 0947838128", "", 12000);
    }
    
}

if(isset($_POST['btnTruTien']) && isset($_POST['value']) && isset($row['username']) && $getUser['level'] == 'admin')
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_error("KHÔNG THỂ THAO TÁC VÌ ĐÂY LÀ WEBSITE DEMO", "", 2000);
    }
    $value = check_string($_POST['value']);
    $ghichu = check_string($_POST['ghichu']);
    if($value <= 0)
    {
        admin_msg_error("Vui lòng nhập số tiền hợp lệ", "", 2000);
    }
    $create = $NHNTAK->insert("dongtien", [
        'sotientruoc' => $row['money'],
        'sotienthaydoi' => $value,
        'sotiensau' => $row['money'] - $value,
        'thoigian' => gettime(),
        'noidung' => 'Admin trừ tiền ('.$ghichu.')',
        'username' => $row['username']
    ]);
    if($create)
    {
        $NHNTAK->tru("users", "money", $value, " `username` = '".$row['username']."' ");
        admin_msg_success("Trừ tiền thành công!", "", 2000);
    }
    else
    {
        admin_msg_error("Vui lòng liên hệ kỹ thuật Zalo 0947838128", "", 12000);
    }
    
}
if(isset($_POST['btnSaveUser']) && isset($_GET['id']) && $getUser['level'] == 'admin')
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_error("KHÔNG THỂ THAO TÁC VÌ ĐÂY LÀ WEBSITE DEMO", "", 2000);
    }
    $money = check_string($_POST['money']);
    $level = check_string($_POST['level']);
    $banned = check_string($_POST['banned']);
    $password = check_string($_POST['password']);
    if($row['money'] != $money)
    {
        $NHNTAK->insert("dongtien", array(
            'sotientruoc'   => $row['money'],
            'sotienthaydoi' => $money - $row['money'],
            'sotiensau'     => $money,
            'thoigian'      => gettime(),
            'noidung'       => 'Admin thay đổi số dư ',
            'username'      => $row['username']
        ));
    }
    $NHNTAK->update("users", array(
        'password'      => TypePassword($password),
        'money'         => $money,
        'level'         => $level,
        'banned'        => $banned
    ), " `id` = '".$row['id']."' ");
    admin_msg_success("Thay đổi user thành công", "", 1000);
}
?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit member</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit member</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- Edit thành viên elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Manage member <b><?=$row['username'];?></b> <a href="<?=BASE_URL('Admin/Users');?>" style="color:white;" class="btn btn-danger btn-sm btn-icon-left m-b-10" type="button"> <i class="fas fa-backward mr-1"></i><span class="">Quay lại</span></a></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Username</label>
                    <input type="text" class="form-control" placeholder="Username" value="<?=$row['username'];?>" disabled>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Email</label>
                    <input type="text" class="form-control" name="email" placeholder="Email" value="<?=$row['email'];?>" disabled>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Trạng thái</label>
                    <select class="form-control" name="banned">
                    <option value="<?=$row['banned'];?>">
                    <?php
                        if($row['banned'] == "0"){ echo 'Active';}
                        if($row['banned'] == "1"){ echo 'Inactive';}
                    ?>
                    </option>
                    <option value="0">Active</option>
                    <option value="1">Inactive</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Số tiền đang có</label>
                    <input type="number" class="form-control" name="money" placeholder="Số tiền đang có" value="<?=$row['money'];?>" disabled>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Cấp bậc</label>
                    <input type="text" class="form-control" name="level" placeholder="Cấp bậc" value="<?=$row['level'];?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">IP đăng nhập</label>
                    <input type="text" class="form-control" placeholder="IP đăng nhập" value="<?=$row['ip'];?>" disabled>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Ngày đăng ký</label>
                    <input type="text" class="form-control" placeholder="Ngày đăng ký" value="<?=$row['createdate'];?>" disabled>
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="btnSaveUser" class="btn btn-primary btn-block waves-effect"> <span>Xác nhận</span> </button>
                </div>
              </form>
            </div>
            <!-- /.card -->
          </div>
          <div class="col-md-6">
                <div class="card card-outline card-success">
                    <div class="card-header">
                        <h3 class="card-title">CỘNG TIỀN</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 col-form-label">Số tiền cộng</label>
                                <div class="col-sm-8">
                                    <div class="form-line">
                                        <input type="number" class="form-control" name="value" required>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 col-form-label">Ghi chú</label>
                                <div class="col-sm-8">
                                    <div class="form-line">
                                        <textarea class="form-control" name="ghichu" rows="3" placeholder="Nhập ghi chú cộng tiền nếu có"></textarea>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" name="btnCongTien" class="btn btn-primary btn-block waves-effect">
                                <span>XÁC NHẬN</span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card card-outline card-danger">
                    <div class="card-header">
                        <h3 class="card-title">TRỪ TIỀN</h3>
                        <div class="card-tools">
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 col-form-label">Số tiền trừ</label>
                                <div class="col-sm-8">
                                    <div class="form-line">
                                        <input type="number" class="form-control" name="value" required>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 col-form-label">Ghi chú</label>
                                <div class="col-sm-8">
                                    <div class="form-line">
                                        <textarea class="form-control" name="ghichu" rows="3" placeholder="Nhập ghi chú trừ tiền nếu có"></textarea>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" name="btnTruTien" class="btn btn-primary btn-block waves-effect"> <span>XÁC NHẬN</span> </button>
                        </form>
                    </div>
                </div>
            </div>
          <!--/.col (left) -->
          <!-- right column -->
         
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Dòng tiền thành viên <b><?=$row['username'];?></b></h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>STT</th>
                    <th>SỐ TIỀN TRƯỚC</th>
                    <th>SỐ TIỀN THAY ĐỔI</th>
                    <th>SỐ TIỀN HIỆN TẠI</th>
                    <th>NỘI DUNG</th>
                    <th>THỜI GIAN</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                    $i = 0;
                    foreach($NHNTAK->get_list(" SELECT * FROM `dongtien` WHERE `username` = '".$row['username']."' ORDER BY id DESC ") as $row){
                    ?>
                  <tr>
                      <td><?=$i++;?></td>
                      <td><?=format_cash($row['sotientruoc']);?>đ</td>
                      <td><?=format_cash($row['sotienthaydoi']);?>đ</td>
                      <td><?=format_cash($row['sotiensau']);?>đ</td>
                      <td><?=$row['noidung'];?></td>
                      <td><?=$row['thoigian'];?></td>
                  </tr>
                   <?php }?>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php 
    require_once("../../public/admin/Footer.php");
?>