<?php
/* TUANORI.COM - PHÁT TRIỂN MÃ NGUỒN 2022 - 2023 */
    require_once("../../core/config.php");
    require_once("../../core/function.php");
    $title = 'EDIT HOSTING | '.$TUANORI->site('tenweb');
    require_once("../../pages/admin/Head.php");
    require_once("../../pages/admin/Header.php");
    CheckLogin();
?>
<?php
if(isset($_GET['id']) && $getUser['level'] == 'admin')
{
    $id     = check_string($_GET['id']);
    $row    = $TUANORI->get_row(" SELECT * FROM `historyhost` WHERE `id` = '$id' ");
    if(!$row)
    {
        msg_error("Hosting này không tồn tại", BASE_URL('Admin/HistoryHost'), 2000);
    }
}
else
{
    msg_error("Liên kết không hợp lệ", BASE_URL('Admin/HistoryHost'), 1000);
}
$rsl    = $TUANORI->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '".$row['server']."' AND `status` = 'SHOW' AND `loai` = '".$row['loai']."'");
if(isset($_POST['SaveAll']) && isset($row['username']) && $getUser['level'] == 'admin')
{
    $user           = check_string($_POST['username']);
    $goi            = check_string($_POST['goi']);
    $tongtien       = check_string($_POST['tongtien']);
    $server         = check_string($_POST['server']);
    $linklogin      = $_POST['linklogin'];
    $status         = check_string($_POST['status']);
    $note           = check_string($_POST['note']);
    if(!$user || !$goi || !$server || !$linklogin || !$status)
    {
        msg_error("Vui lòng nhập đầy đủ thông tin", "", 1000);
    }
    if($tongtien < 0)
    {
        msg_error("Số tiền bạn nhập không hợp lệ", "", 1000);
    }
    if(!$TUANORI->get_row(" SELECT * FROM `goihost` WHERE `nameGoi` = '$goi' "))
    {
        msg_error("Gói $goi không tồn tại trong hệ thống", "", 1000);
    }
    if($status == 'huy2')
    {
        $TUANORI->cong("users", "money", $row['tongtien'], " `username` = '".$row['username']."' ");
        $TUANORI->insert("biendongsodu", [
            'username'  => $row['username'],
            'tongtien'  => $row['tongtien'],
            'note'      => 'Hoàn tiền mua hosting '.$row['domain'].' giá '.format_cash($row['tongtien']).'đ',
            'thoigian'  => gettime()
        ]);
        $status = 'huy';
    }
    if($status == 'hoatdong')
    {
        if($row['status'] == 'tamkhoa' || $row['status'] == 'hethan' || $row['status'] == 'bikhoa')
        {
            $unsub  = apiWHM($rsl['taikhoanrsl'], $rsl['matkhaursl'], $row['linklogin'].':2087/json-api/unsuspendacct?api.version=1&user='.$row['taikhoan']);
        }
    }
    $update = $TUANORI->update("historyhost", array(
            'username'  => $user,
            'goi'       => $goi,
            'tongtien'  => $tongtien,
            'server'    => $server,
            'linklogin' => $linklogin,
            'status'    => $status,
            'note'      => $note,
        ), " `id` = '".$row['id']."' ");
    if($update)
    {
        msg_success("Cập nhật thành công dữ liệu", "", 1000);
    }
    else
    {
        msg_error("Cập nhật dữ liệu thất bại", "", 1000);
    }
}
if(isset($_POST['btnCong']) && isset($_POST['value']) && $getUser['level'] == 'admin')
{
    $day = check_string($_POST['value']);
    if(!$day)
    {
        msg_error("Vui lòng nhập số tháng muốn cộng", "", 1000);
    }
    if($day < 1)
    {
        msg_error2("Số tháng cộng không hợp lệ");
    }
    else
    {
        if($row['status'] == 'tamkhoa')
        {
            $unsub  = json_decode(apiWHM($rsl['taikhoanrsl'], $rsl['matkhaursl'], $row['linklogin'].':2087/json-api/unsuspendacct?api.version=1&user='.$row['taikhoan']), true);
            if(isset($unsub['metadata']['result']))
            {
                if($unsub['metadata']['result'] == 1)
                {
                    $TUANORI->update("historyhost", array(
                        'status'    => 'hoatdong'
                    ), " `id` = '$id' ");
                    $TUANORI->cong("historyhost", "ngayhet", $day*2592000, " `id` = '".$row['id']."' ");
                    msg_success("Đã cộng thêm $day tháng", "", 1000);
                }
                else
                {
                    msg_error("Đã xảy ra lỗi trong quá trình xử lý. Hãy thử lại" , "", 1000);
                }
            }
            else
            {
                msg_error("Không nhận được dữ liệu từ Server" , "", 1000);
            }
        }
        else
        {
            $TUANORI->cong("historyhost", "ngayhet", $day*2592000, " `id` = '".$row['id']."' ");
            msg_success("Đã cộng thêm $day tháng", "", 1000);
        }
    }
}
if(isset($_POST['btnTru']) && isset($_POST['value']) && $getUser['level'] == 'admin')
{
    $day = check_string($_POST['value']);
    if(!$day)
    {
        msg_error("Vui lòng nhập số tháng muốn trừ", "", 1000);
    }
    if($day < 1)
    {
        msg_error2("Số tháng trừ không hợp lệ");
    }
    else
    {
        if($row['ngaymua'] > ($row['ngayhet'] - $day*2592000))
        {
            msg_error("Thời gian hết hạn vui lòng lớn hơn Thời gian mua", "", 1000);
        }
        $TUANORI->tru("historyhost", "ngayhet", $day*2592000, " `id` = '".$row['id']."' ");
        msg_success("Đã trừ thêm $day tháng", "", 1000);
    }
}
if(isset($_POST['DoiDomain']) && isset($_POST['mienchinh']) && $getUser['level'] == 'admin')
{
    $domain = check_string($_POST['mienchinh']);
    if(!$domain)
    {
        msg_error2("Vui lòng nhập tên miền để tiếp tục");
    }
    else
    {
        $row2 = $TUANORI->get_row(" SELECT * FROM `users` WHERE `username` = '".$row['username']."'");
        $data = json_decode(curl_get(BASE_URL('api/thaotac?token='.$row2['tokenapi'].'&domain='.$domain.'&type=6&username='.$row['taikhoan'])), true);
        if(isset($data['status']))
        {
            if($data['status'] == 'success')
            {
                msg_success2($data['message'], "", 1000);
            }
            else
            {
                msg_error($data['message'], "", 5000);
            }
        }
        else
        {
            msg_error2("Không nhận được dữ liệu từ Server", "", 1000);
        }
    }
}
if(isset($_POST['UpdateGoi']) && isset($_POST['goiupdate']) && $getUser['level'] == 'admin')
{
    $goi = check_string($_POST['goiupdate']);
    if(!$goi)
    {
        msg_error2("Vui lòng chọn gói để nâng cấp");
    }
    else
    {
        $row2 = $TUANORI->get_row(" SELECT * FROM `users` WHERE `username` = '".$row['username']."'");
        $data = json_decode(curl_get(BASE_URL('api/thaotac?token='.$row2['tokenapi'].'&goi='.$goi.'&type=5&username='.$row['taikhoan'])), true);
        if(isset($data['status']))
        {
            if($data['status'] == 'success')
            {
                msg_success2($data['message'], "", 1000);
            }
            else
            {
                msg_error($data['message'], "", 5000);
            }
        }
        else
        {
            msg_error2("Không nhận được dữ liệu từ Server", "", 1000);
        }
    }
}
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Hosting Name <b><?=$row['domain'];?></b></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit lịch sử mua hosting </li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- Edit lịch sử mua hosting elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Edit hosting tên miền <b><?=$row['domain'];?></b> <?=statusHost($row['status']);?></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Người mua</label>
                    <input type="text" class="form-control" name="username" placeholder="Người mua" value="<?=$row['username'];?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Email</label>
                    <input type="text" class="form-control" name="email" placeholder="Email" value="<?=$row['email'];?>" disabled>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Tên miền</label>
                    <input type="text" class="form-control" name="domain" placeholder="Tên miền" value="<?=$row['domain'];?>" disabled>
                    <i>Muốn đổi tên miền thì kéo xuống dưới có phần đổi tên miền chính</i>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Gói</label>
                    <input type="text" class="form-control" name="goi" placeholder="Gói" value="<?=$row['goi'];?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Tổng tiền</label>
                    <input type="number" class="form-control" name="tongtien" placeholder="Tổng tiền" value="<?=$row['tongtien'];?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Server</label>
                    <input type="text" class="form-control" name="server" placeholder="server" name="server" value="<?=$row['server'];?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Tài khoản hosting</label>
                    <input type="text" class="form-control" name="taikhoan" placeholder="Tài khoản hosting" name="taikhoan" value="<?=$row['taikhoan'];?>" disabled>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Mật khẩu hosting</label>
                    <input type="text" class="form-control" placeholder="Mật khẩu hosting" name="matkhau" value="<?=$row['matkhau'];?>" disabled>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Link đăng nhập (Không ghi :2083)</label>
                    <input type="text" class="form-control" placeholder="VD: https://103-9-158-66.cprapid.com" name="linklogin" value="<?=$row['linklogin'];?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Ngày mua</label>
                    <input type="text" class="form-control" placeholder="Ngày mua" value="<?=format_date($row['ngaymua']);?>" disabled>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Ngày hết hạn</label>
                    <input type="text" class="form-control" placeholder="Ngày hết hạn" value="<?=format_date($row['ngayhet']);?>" disabled>
                  </div>
                  <?php if($row['gioithieu']) { ?>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Người giới thiệu</label>
                    <input type="text" class="form-control" placeholder="Ngày hết hạn" value="<?=$row['gioithieu'];?>" disabled>
                  </div>
                  <?php } ?>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Trạng thái</label>
                    <select class="form-control select2" name="status" style="width: 100%;">
                        <?php
                        if($row['status'] == 'hoatdong')
                        {
                            echo '<option value="hoatdong">Hoạt động</option>';
                        }
                        else if($row['status'] == 'tamkhoa')
                        {
                            echo '<option value="tamkhoa">Tạm khóa</option>';
                        }
                        else if($row['status'] == 'adminkhoa')
                        {
                            echo '<option value="adminkhoa">Admin tạm khóa</option>';
                        }
                        else if($row['status'] == 'bikhoa')
                        {
                            echo '<option value="bikhoa">Bị khóa</option>';
                        }
                        else if($row['status'] == 'hethan')
                        {
                            echo '<option value="hethan">Hết hạn</option>';
                        }
                        else if($row['status'] == 'reset')
                        {
                            echo '<option value="reset">Reset hosting</option>';
                        }
                        else if($row['status'] == 'huy')
                        {
                            echo '<option value="huy">Hủy</option>';
                        }
                        ?>
                        <option value="reset">Reset hosting</option>
                        <option value="dangtao">Đang tạo</option>
                        <option value="tamkhoa">Tạm khóa</option>
                        <option value="adminkhoa">Admin tạm khóa</option>
                        <option value="hoatdong">Hoạt động <?php if($row['status'] != 'hoatdong') { echo '(Hệ thống tự mở lại nếu như hosting này đang bị khóa)'; } ?></option>
                        <option value="hethan">Hết hạn</option>
                        <option value="huy">Hủy (Không hoàn tiền)</option>
                        <option value="huy2">Hủy (Hoàn tiền)</option>
                      </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Lý do</label>
                    <input type="text" class="form-control" name="note" placeholder="Lý do" value="<?=$row['note'];?>">
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="SaveAll" class="btn btn-primary">Lưu dữ liệu</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
          </div>
          <div class="col-md-6">
                <div class="card card-outline card-success">
                    <div class="card-header">
                        <h3 class="card-title">CỘNG THÊM THỜI GIAN</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 col-form-label">Số tháng cộng (Ngày hết hạn)</label>
                                <div class="col-sm-8">
                                    <div class="form-line">
                                        <input type="number" placeholder="Số tháng muốn cộng" class="form-control" name="value" required>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" name="btnCong" class="btn btn-primary btn-block waves-effect">
                                <span>XÁC NHẬN</span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card card-outline card-danger">
                    <div class="card-header">
                        <h3 class="card-title">TRỪ THỜI GIAN</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 col-form-label">Số tháng trừ (Ngày hết hạn)</label>
                                <div class="col-sm-8">
                                    <div class="form-line">
                                        <input type="number" class="form-control" placeholder="Số tháng muốn trừ" name="value" required>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" name="btnTru" class="btn btn-primary btn-block waves-effect">
                                <span>XÁC NHẬN</span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card card-outline card-danger">
                    <div class="card-header">
                        <h3 class="card-title">THAO TÁC</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <form>
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 col-form-label">Thao tác quản lý</label>
                                <div class="col-sm-8">
                                    <div class="form-line">
                                        <select class="form-control select2" id="chucnang" style="width: 100%;">
                                            <option value="">-- CHỌN THAO TÁC --</option>
                                            <option value="1">Xem thông tin</option>
                                            <option value="2">Reset mật khẩu</option>
                                            <option value="3">Xóa Hosting</option>
                                            <option value="4">Reset Hosting</option>
                                            <option value="7">Login Nhanh</option>
                                            <option value="8">Khóa hosting</option>
                                            <option value="10">Mở khóa hosting (Áp dụng cho hosting bị khóa)</option>
                                      </select>
                                    </div>
                                </div>
                            </div>
                            <button type="button" id="Thaotac" class="btn btn-primary btn-block waves-effect">
                                <span>XÁC NHẬN</span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card card-outline card-danger">
                    <div class="card-header">
                        <h3 class="card-title">ĐỔI TÊN MIỀN CHÍNH</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 col-form-label">Tên miền chính</label>
                                <div class="col-sm-8">
                                    <div class="form-line">
                                        <input type="text" class="form-control" placeholder="Tên miền chính" name="mienchinh" value="<?=$row['domain'];?>" required>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" name="DoiDomain" class="btn btn-primary btn-block waves-effect">
                                <span>ĐỔI NGAY</span>
                            </button>
                            <i>Chức năng này có 1 số reseller không hỗ trợ. Nên khi thay đổi không được thì phải liên hệ bên nhà cung cấp Reseller.</i>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="card card-outline card-danger">
                    <div class="card-header">
                        <h3 class="card-title">THAY ĐỔI GÓI NGƯỜI DÙNG</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 col-form-label">Chọn gói</label>
                                <div class="col-sm-8">
                                    <div class="form-line">
                                        <select class="form-control select2" name="goiupdate" style="width: 100%;" required>
                                            <option value="">-- CHỌN GÓI --</option>
                                            <?php foreach($TUANORI->get_list(" SELECT * FROM `goihost` WHERE `serverhost` = '".$row['server']."' AND `status` = 'SHOW' AND `loai` = '".$row['loai']."' ORDER BY money ASC") as $data3) { 
                                            if($data3['money'] > $row['tongtien']) { ?>
                                            <option value="<?=$data3['nameGoi'];?>">Gói <?=strtoupper($data3['nameGoi']);?> - (<?=format_cash(($data3['money'] - $row['tongtien']) * check_month($row['ngayhet']));?>đ)</option>
                                            <?php } } ?>
                                      </select>
                                      <i>Hệ thống sẽ trừ tiền thành viên nếu nâng cấp lên gói mới. Sẽ báo lỗi nếu thành viên không đủ tiền.</i>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" name="UpdateGoi" class="btn btn-primary btn-block waves-effect">
                                <span>ĐỔI NGAY</span>
                            </button>
                            <i>Chức năng này có 1 số reseller không hỗ trợ. Nên khi thay đổi không được thì phải liên hệ bên nhà cung cấp Reseller.</i>
                        </form>
                    </div>
                </div>
            </div>
          <!--/.col (left) -->
          <!-- right column -->
         
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    
    <!-- /.content -->
  </div>
  
<script>
    $("#Thaotac").on("click", function() {

    $('#Thaotac').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Đang xử lý...').prop('disabled',
        true);
    $.ajax({
        url: "<?=BASE_URL('assets/ajaxs/Xulyadmin.php');?>",
        method: "POST",
        data: {
            type: 'Thongtin',
            user: '<?=$row['taikhoan'];?>',
            chucnang: $("#chucnang").val(),
            id: '<?=$row['id'];?>'
        },
        success: function(response) {
            $("#thongbao").html(response);
            $('#Thaotac').html(
                    'XÁC NHẬN')
                .prop('disabled', false);
        }
    });
});
</script>
 <?php
    require_once("../../pages/admin/Footer.php");
?>