<?php
require_once('../../class/class.phpmailer.php');
require_once("../../config/config.php");
require_once("../../config/function.php");

// Add write_log function
function write_log($message)
{
    $logFile = __DIR__ . '/log_kiemtra_addg.txt';
    $time = date("Y-m-d H:i:s");
    $logMessage = "[$time] $message" . PHP_EOL;
    file_put_contents($logFile, $logMessage, FILE_APPEND);
}

$title = 'ADD PAKAGES | '.$NHNTAK->site('tenweb');
require_once("../../public/admin/Header.php");
require_once("../../public/admin/Sidebar.php");

if(isset($_GET['id']) && $getUser['level'] == 'admin')
{
    write_log("Processing package addition request for server ID: " . $_GET['id']);
    $id     = check_string($_GET['id']);
    $_SESSION['id'] = $id;
    $row    = $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `id` = '$id' ");
    if(!$row)
    {
        write_log("Server not found with ID: $id", "ERROR");
        admin_msg_error("Server này không tồn tại", BASE_URL('Admin/Server'), 2000);
    }
    else
    {
        write_log("Found server: " . $row['nameServer']);
    }
}
else
{
    write_log("Invalid link access attempt", "ERROR");
    admin_msg_error("Liên kết không hợp lệ", BASE_URL('Admin/Server'), 1000);
}

if(isset($_POST['AddGoi']) && $getUser['level'] == 'admin' && $row['taikhoanrsl'])
{
    write_log("Processing new package addition for server: " . $row['nameServer']);
    
    $name       = check_string($_POST['name']);
    $quota      = check_string($_POST['quota']);
    $bwlimit    = check_string($_POST['bwlimit']);
    $maxsub     = check_string($_POST['maxsub']);
    $maxpark    = check_string($_POST['maxpark']);
    $maxaddon   = check_string($_POST['maxaddon']);
    $language   = check_string($_POST['language']);
    $cpmod      = check_string($_POST['cpmod']);
    $money      = check_string($_POST['money']);
    
    write_log("Package details - Name: $name, Quota: $quota, Bandwidth: $bwlimit");
    
    if(!$name || !$quota || !$bwlimit || !$language || !$cpmod)
    {
        write_log("Package addition failed: Missing required fields", "ERROR");
        admin_msg_error("Vui lòng nhập đầy đủ thông tin", "", 1000);
    }
    
    if($NHNTAK->get_row(" SELECT * FROM `goihost` WHERE `nameGoi` = '$name' AND `serverhost` = '".$row['nameGetServer']."' "))
    {
        write_log("Package addition failed: Package already exists - Name: $name on server: " . $row['nameGetServer'], "ERROR");
        admin_msg_error("Gói này đã tồn tại trong hệ thống", "", 1000);
    }
    
    if($bwlimit == 'unlimited')
    {
        $bangthong = '1048576';
        write_log("Setting unlimited bandwidth to: $bangthong");
    }
    
    write_log("Attempting to create package on WHM server: " . $row['linkrsl']);
    $data = json_decode(apiWHM($row['taikhoanrsl'], $row['matkhaursl'],$row['linkrsl'].":2087/json-api/addpkg?api.version=1&name=$name&quota=$quota&bwlimit=$bangthong&maxsub=$maxsub&maxpark=$maxpark&maxaddon=$maxaddon&language=$language&cpmod=$cpmod&cgi=1"), true);
    
    if(isset($data['metadata']['result']))
    {
        if($data['metadata']['result'] == 1)
        {
            write_log("Package created successfully on WHM server");
            $create = $NHNTAK->insert("goihost", [
                'serverhost'    => $row['nameGetServer'],
                'nameGoi'       => $name,
                'money'         => $money,
                'dungluong'     => $quota,
                'bangthong'     => $bwlimit,
                'miencon'       => $maxsub,
                'mienkhac'      => $maxaddon,
                'mienbidanh'    => $maxpark,
                'backup'        => $row['backup'],
                'loairsl'       => 'WHM',
                'status'        => 'SHOW',
                'type'          => $row['theloai'],
                'loai'          => $row['loai'],
            ]);
            
            if($create)
            {
                write_log("Package added successfully to database: $name");
                admin_msg_success("Đã thêm gói thành công", "", 1000);
            }
            else
            {
                write_log("Failed to save package to database: $name", "ERROR");
                admin_msg_error("Không thể lưu dữ liệu vào DATABASE", "", 1000);
            }
        }
        else
        {
            write_log("WHM package creation failed: " . $data['metadata']['reason'], "ERROR");
            admin_msg_error($data['metadata']['reason'], "", 1000);
        }
    }
    else
    {
        write_log("No response received from WHM server: " . $row['linkrsl'], "ERROR");
        admin_msg_error("Không nhận được dữ liệu từ RSL", "", 1000);
    }
}

if(isset($_GET['dele']) && $getUser['level'] == 'admin')
{
    write_log("Attempting to delete server with ID: " . $_GET['dele']);
    $id = check_string($_GET['dele']);
    $row = $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `id` = '$id' ");
    if(!$row)
    {
        write_log("Server deletion failed: Server not found with ID: $id", "ERROR");
        msg_error("Máy chủ không tồn tại", BASE_URL('Admin/Server'),  1000);
    }
    else
    {
        write_log("Found server to delete: " . $row['nameServer']);
        $delete = $NHNTAK->remove("serverhost", " `id` = '$id' ");
        if($delete)
        {
            write_log("Server deleted successfully: " . $row['nameServer']);
            msg_success("Xóa máy chủ thành công", BASE_URL('Admin/Server'),  1000);
        }
        else
        {
            write_log("Server deletion failed: Database error", "ERROR");
            msg_error("Xóa thất bại", BASE_URL('Admin/Server'),  1000);
        }
    }
}

if(isset($_POST['AddSubmit']) && $getUser['level'] == 'admin')
{
    write_log("Processing new server addition request");
    $name   = check_string($_POST['nameServer']);
    $tk     = check_string($_POST['taikhoanrsl']);
    $mk     = check_string($_POST['matkhaursl']);
    $link   = check_string($_POST['linkrsl']);
    $ns     = check_string($_POST['nsNameServer']);
    $status = check_string($_POST['status']);
    $backup = check_string($_POST['backup']);
    
    write_log("Validating server details - Name: $name, Link: $link");
    
    if(!$name || !$tk || !$mk || !$link || !$ns || !$status || !$backup)
    {
        write_log("Server addition failed: Missing required fields", "ERROR");
        msg_error("Vui lòng nhập đầy đủ thông tin", "",  1000);
    }
    
    $nameGet = nameGetServer($name);
    if($NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '$nameGet' ") || $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `taikhoanrsl` = '$tk' AND `linkrsl` = '$link' "))
    {
        write_log("Server addition failed: Server already exists - Name: $name, Link: $link", "ERROR");
        msg_error("Thông tin máy chủ đã tồn tại trong hệ thống", "",  1000);
    }
    
    write_log("Attempting to connect to WHM server: $link");
    $data = json_decode(apiWHM($tk, $mk, $link.':2087/json-api/listaccts?api.version=1'), true);
    apiWHM($tk, $mk, $link.':2087/json-api/save_style?api.version=1&company_name='.strtoupper($_SERVER['SERVER_NAME']));
    
    if(isset($data['cpanelresult']))
    {
        write_log("WHM authentication failed for server: $link", "ERROR");
        msg_error("Thông tin đăng nhập WHM không chính xác", "",  1000);
    }
    else if(isset($data['metadata']))
    {
        write_log("WHM connection successful, processing server details");
        if($ownership == 'owner')
        {
            $theloai = 'ADMINWHM';
            $nc = 'ON';
            write_log("Server type set as ADMINWHM");
        }
        else
        {
            $theloai = 'CPANELWHM';
            $nc = 'OFF';
            write_log("Server type set as CPANELWHM");
        }
        
        $create = $NHNTAK->insert("serverhost", [
            'nameServer'        => $name,
            'nameGetServer'     => $nameGet,
            'taikhoanrsl'       => $tk,
            'matkhaursl'        => $mk,
            'linkrsl'           => $link,
            'loairsl'           => 'WHM',
            'nsNameServer'      => $ns,
            'nangcap'           => $nc,
            'backup'            => $backup,
            'number_account'    => count($data['data']['acct']),
            'status'            => $status,
            'ownership'         => check_string($_POST['ownership']),
            'theloai'           => $theloai,
            'loai'              => 'hosting'
        ]);
        
        if($create)
        {
            write_log("Server added successfully: $name with $theloai type");
            msg_success("Đã thêm dữ liệu thành công", "",  1000);
        }
        else
        {
            write_log("Failed to add server to database: $name", "ERROR");
            msg_error("Không thể ADD dữ liệu vào DATABASE", "",  1000);
        }
    }
    else
    {
        write_log("Failed to load data from WHM server: $link", "ERROR");
        msg_error("Không thể load được dữ liệu từ RSL WHM này", "",  1000);
    }
}

if(isset($_POST['type']))
{
    write_log("Received request type: " . $_POST['type']);
    
    if($_POST['type'] == 'MuaHost')
    {
        $email  = check_string(strtolower($_POST['email']));
        $domain = check_string(strtolower($_POST['domain']));
        $goi    = check_string($_POST['goi']);
        $server = check_string($_POST['server']);
        $type   = check_string($_POST['theloai']);
        $loai   = check_string($_POST['loai']);
        
        write_log("Processing MuaHost request - Email: $email, Domain: $domain, Goi: $goi, Server: $server, Type: $type, Loai: $loai");
        
        if(!$email || !$domain)
        {
            write_log("Validation failed: Missing email or domain", "ERROR");
            msg_error2("Vui lòng nhập đủ thông tin để tiếp tục");
        }
        if(!$goi)
        {
            write_log("Validation failed: Invalid goi", "ERROR");
            msg_error2("Sản phẩm không hợp lệ, yêu cầu không thể được xử lý");
        }
        if(!$server)
        {
            write_log("Validation failed: Invalid server", "ERROR");
            msg_error2("Sản phẩm không hợp lệ, yêu cầu không thể được xử lý");
        }
        if(!$loai)
        {
            write_log("Validation failed: Invalid loai", "ERROR");
            msg_error2("Sản phẩm không hợp lệ, yêu cầu không thể được xử lý");
        }
        if(!$type)
        {
            write_log("Validation failed: Invalid type", "ERROR");
            msg_error2("Sản phẩm không hợp lệ, yêu cầu không thể được xử lý");
        }
        
        $goi1 = $NHNTAK->get_row(" SELECT * FROM `goihost` WHERE `nameGoi` = '$goi' AND `serverhost` = '$server' AND `status` = 'SHOW' AND `type` = '$type'");
        if(!$goi1)
        {
            write_log("Invalid hosting package: $goi on server $server", "ERROR");
            exit(json_encode(['status' => '1', 'msg' => 'Lưu trữ sản phẩm không hợp lệ']));
        }
        
        if(check_email($email) != True)
        {
            write_log("Invalid email format: $email", "ERROR");
            exit(json_encode(['status' => '1', 'msg' => 'Email của bạn không hợp lệ']));
        }
        
        $checkhost = $NHNTAK->get_row(" SELECT * FROM `historyhost` WHERE `domain` = '$domain' AND `status` = 'hoatdong' AND `type` = '$type'");
        if($checkhost)
        {
            write_log("Domain already exists: $domain", "ERROR");
            exit(json_encode(['status' => '1', 'msg' => 'Tên miền đã tồn tại trên hệ thống']));
        }
        
        if (empty($_SESSION['username']))
        {
            write_log("User not logged in", "ERROR");
            exit(json_encode(['status' => '1', 'msg' => 'Bạn chưa đăng nhập vào tài khoản của bạn trên trang web của chúng tôi']));
        }
        
        $sotien = $goi1['money'];
        if($my_money < $sotien)
        {
            write_log("Insufficient balance for user {$getUser['username']}: Required $sotien, Available $my_money", "ERROR");
            exit(json_encode(['status' => '1', 'msg' => 'Số dư không đủ để thực hiện giao dịch']));
        }
        
        $WHM = $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '".$goi1['serverhost']."' AND `status` = 'SHOW'");
        write_log("Checking domain availability on WHM server: {$WHM['linkrsl']}");
        
        $data = json_decode(apiWHM($WHM['taikhoanrsl'], $WHM['matkhaursl'], $WHM['linkrsl'].':2087/json-api/get_domain_info?api.version=1'), true);
        foreach($data['data']['domains'] as $demo)
        {
            if($demo['domain'] == $domain)
            {
                $checkdo = true;
            }
        }
        
        if(isset($checkdo))
        {
            write_log("Domain exists on WHM server: $domain", "ERROR");
            exit(json_encode(['status' => '1', 'msg' => 'Tên miền đã tồn tại trên hệ thống']));
        }
        else
        {
            write_log("Creating new hosting account for domain: $domain");
            $create = $NHNTAK->insert("historyhost", [
                'username'      => $getUser['username'],
                'domain'        => $domain,
                'email'         => $email,
                'server'        => $goi1['serverhost'],
                'goi'           => $goi,
                'tongtien'      => $goi1['money'],
                'tienlandau'    => $sotien,
                'ngaymua'       => time(),
                'ngayhet'       => time() + $onethang,
                'thoigian'      => gettime(),
                'autogiahan'    => 'NO',
                'linklogin'     => $WHM['linkrsl'],
                'loairsl'       => $WHM['loairsl'],
                'nsNameServer'  => $WHM['nsNameServer'],
                'type'          => $type,
                'loai'          => $loai,
                'status'        => 'dangtao'
            ]);
            
            if($create)
            {
                write_log("Hosting account created successfully for domain: $domain");
                $isMoney = $NHNTAK->tru("users", "money", $sotien, " `username` = '".$getUser['username']."'");
                if($isMoney)
                {
                    write_log("Deducted $sotien from user {$getUser['username']}");
                    $NHNTAK->insert("dongtien", [
                         'sotientruoc'   => $getUser['money'],
                         'sotienthaydoi' => $price,
                         'thoigian'      => gettime(),
                         'noidung'       => 'You Buy Hosting my domain | '.$domain.'',
                         'username'      => $getUser['username']
                    ]);
                    
                    if($loai == 'reseller')
                    {
                        write_log("Reseller account created for domain: $domain");
                    }
                    
                    unset($_SESSION['host']);
                    write_log("Hosting purchase completed successfully for domain: $domain");
                    exit(json_encode(['status' => '2','msg' => 'Thanh toán Hosting thành công, vui lòng đợi ít giây đến ít phút để khởi tạo', BASE_URL('linkhistoryhost'), 2000]));
                }
                else
                {
                    write_log("Failed to deduct money for user {$getUser['username']}", "ERROR");
                    exit(json_encode(['status' => '1', 'msg' => 'TIỀN KHÔNG THỂ KHẤU TRỪ']));
                }
            }
            else
            {
                write_log("Failed to create hosting account for domain: $domain", "ERROR");
                exit(json_encode(['status' => '1', 'msg' => 'KIỂM TRA NGUỒN TỆP LẠI CỦA BẠN']));
            }
        }
    }
} 
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Gói</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Add Gói</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- Add Gói elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add gói vào server <b><?=$row['nameServer'];?></b></h3><br/>
                <b>Lưu ý: Quá trình thêm gói, hệ thống sẽ API ADD thẳng vào WHM của các bạn.</b>
              </div>
              <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Tên Gói</label>
                    <input type="text" class="form-control" name="name" placeholder="Tên Gói">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Giá tiền gói</label>
                    <input type="number" class="form-control" name="money" placeholder="Giá tiền gói">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Hạn Mức Dung Lượng Đĩa (MB)</label>
                    <input type="text" class="form-control" name="quota" value="10240" placeholder="Hạn Mức Dung Lượng Đĩa (MB)">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Giới Hạn Băng Thông Hàng Tháng (MB) (Không giới hạn, vui lòng ghi: <a style="color:red">unlimited</a>)</label>
                    <input type="text" class="form-control" name="bwlimit" value="1048576" placeholder="Giới Hạn Băng Thông Hàng Tháng (MB)">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Số Miền Con Tối Đa (Không giới hạn, vui lòng ghi: <a style="color:red">unlimited</a>)</label>
                    <input type="text" class="form-control" name="maxsub" placeholder="Số Miền Con Tối Đa">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Số Miền Phụ Tối Đa (Không giới hạn, vui lòng ghi: <a style="color:red">unlimited</a>)</label>
                    <input type="text" class="form-control" name="maxpark" placeholder="Số Miền Phụ Tối Đa">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Số Miền Khác Tối Đa (Không giới hạn, vui lòng ghi: <a style="color:red">unlimited</a>)</label>
                    <input type="text" class="form-control" name="maxaddon" placeholder="Số Miền Khác Tối Đa">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Ngôn ngữ</label>
                    <select class="form-control select2" name="language">
                        <option value="vi" selected="selected">Tiếng Việt</option>
                        <option value="ar">Tiếng A-rập (العربية)</option>
                        <option value="bg">Tiếng Bun-ga-ri (български)</option>
                        <option value="cs">Tiếng Séc (čeština)</option>
                        <option value="da">Tiếng Đan Mạch (dansk)</option>
                        <option value="de">Tiếng Đức (Deutsch)</option>
                        <option value="el">Tiếng Hy Lạp (Ελληνικά)</option>
                        <option value="en">Tiếng Anh (English)</option>
                        <option value="es">Tiếng Tây Ban Nha (español)</option>
                        <option value="es_419">Tiếng Tây Ban Nha (Mỹ La tinh) (español latinoamericano)</option>
                        <option value="es_es">Tiếng Tây Ban Nha (I-bê-ri) (español de España)</option>
                        <option value="fi">Tiếng Phần Lan (suomi)</option>
                        <option value="fil">Tiếng Philipin (Filipino)</option>
                        <option value="fr">Tiếng Pháp (français)</option>
                        <option value="he">Tiếng Hê-brơ (עברית)</option>
                        <option value="hu">Tiếng Hung-ga-ri (magyar)</option>
                        <option value="i_cpanel_snowmen">☃ cPanel Snowmen ☃ - i_cpanel_snowmen</option>
                        <option value="i_en">i_en</option>
                        <option value="id">Tiếng In-đô-nê-xia (Bahasa Indonesia)</option>
                        <option value="it">Tiếng Ý (italiano)</option>
                        <option value="ja">Tiếng Nhật (日本語)</option>
                        <option value="ko">Tiếng Hàn Quốc (한국어)</option>
                        <option value="ms">Tiếng Ma-lay-xi-a (Bahasa Melayu)</option>
                        <option value="nb">Tiếng Na Uy (Bokmål) (norsk bokmål)</option>
                        <option value="nl">Tiếng Hà Lan (Nederlands)</option>
                        <option value="no">Tiếng Na Uy (Norwegian)</option>
                        <option value="pl">Tiếng Ba Lan (polski)</option>
                        <option value="pt">Tiếng Bồ Đào Nha (português)</option>
                        <option value="pt_br">Tiếng Bồ Đào Nha (Braxin) (português do Brasil)</option>
                        <option value="ro">Tiếng Ru-ma-ni (română)</option>
                        <option value="ru">Tiếng Nga (русский)</option>
                        <option value="sl">Tiếng Xlô-ven (slovenščina)</option>
                        <option value="sv">Tiếng Thụy Điển (svenska)</option>
                        <option value="th">Tiếng Thái (ไทย)</option>
                        <option value="tr">Tiếng Thổ Nhĩ Kỳ (Türkçe)</option>
                        <option value="uk">Tiếng U-crai-na (українська)</option>
                        <option value="zh">Tiếng Trung Quốc (中文)</option>
                        <option value="zh_cn">Tiếng Trung Quốc (Trung Quốc) (中文（中国）)</option>
                        <option value="zh_tw">Tiếng Trung Quốc (Đài Loan) (中文（台湾）)</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Giao diện Cpanel</label>
                    <select class="form-control select2" name="cpmod">
                        <option value="jupiter">jupiter</option>
                        <option value="paper_lantern" selected="selected">paper_lantern (deprecated)</option>
                    </select>
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="AddGoi" class="btn btn-primary">Thêm Gói</button>
                </div>
              </form>
            </div>
            <!-- /.card -->

          
          </div>
        
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Danh sách các gói Hosting</b></h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>STT</th>
                    <th>THÔNG TIN CHUNG</th>
                    <th>THÔNG TIN GÓI</th>
                    <th>THAO TÁC</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                    $i = 0;
                    foreach($NHNTAK->get_list(" SELECT * FROM `goihost` WHERE `serverhost` = '".$row['nameGetServer']."' AND `type` = '".$row['theloai']."' AND `loai` = '".$row['loai']."' ORDER BY id DESC ") as $data20){
                    ?>
                  <tr>
                    <td><?=$i++;?></td>
                    <td>
                        <ul>
                            <li>Tên Gói: <b style="color:blue"><?=$data20['nameGoi'];?></b></li>
                            <li>Tên Máy Chủ: <b style="color:blue"><?=$data20['serverhost'];?></b></li>
                            <li>Trạng Thái: <b style="color:red"><?=status_show($data20['status']);?></b></li>
                            <li>Số tiền bán: <b style="color:red"><?=format_cash($data20['money']);?><sup>đ</sup></b></li>
                        </ul>
                    </td>
                    <td>
                        <ul>
                            <li>Dung lượng: <b style="color:blue"><?=reView($data20['dungluong']);?> MB</b></li>
                            <li>Băng thông: <b style="color:red"><?=reView($data20['bangthong']);?> MB</b></li>
                            <li>Miền con: <b style="color:red"><?=reView($data20['miencon'], 1);?></b></li>
                            <li>Bí danh: <b style="color:red"><?=reView($data20['mienbidanh'], 1);?></b></li>
                            <li>Miền khác: <b style="color:red"><?=reView($data20['mienkhac'], 1);?></b></li>
               
                        </ul>
                    </td>
                    
                    <td>
                        <a href="<?=BASE_URL('Admin/Goi/Edit/'.$data20['id']);?>" style="color:white;" class="btn btn-info btn-sm btn-icon-left m-b-10" type="button">
                            <i class="fas fa-edit mr-1"></i><span class="">Edit</span>
                        </a>
                        <a style="color:white;" href="<?=BASE_URL('Admin/Goi/Delete/'.$data20['id']);?>"
                            class="btn btn-danger btn-sm btn-icon-left m-b-10">
                            <i class="fas fa-trash mr-1"></i><span class="">Delete</span>
                        </a>
                    </td>
                  </tr>
                   <?php }?>
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>STT</th>
                    <th>THÔNG TIN</th>
                    <th>TÀI KHOẢN</th>
                    <th>THAO TÁC</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php 
    require_once("./Footer.php");
?>