<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'CẤU HÌNH | '.$NHNTAK->site('tenweb');
    require_once("../../public/admin/Header.php");
    require_once("../../public/admin/Sidebar.php");
?>
<?php
if(isset($_POST['SaveSettings']) && $getUser['level'] == 'admin')
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_error("Chức năng này không khả dụng trên trang web DEMO!", "", 2000);
    }
    foreach ($_POST as $key => $value)
    {
        $NHNTAK->update("options", array(
            'value' => $value
        ), " `key` = '$key' ");
    }
    admin_msg_success('Lưu thành công', '', 500);
}
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Settings</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?=BASE_URL('Admin/Home');?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Settings</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
        <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <section class="col-lg-12">
                    <div class="card card-dark card-tabs">
                        <div class="card-header p-0 pt-1 border-bottom-0">
                            <ul class="nav nav-tabs" id="custom-tabs-three-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="custom-tabs-three-home-tab" data-toggle="pill"
                                        href="#custom-tabs-three-home" role="tab" aria-controls="custom-tabs-three-home"
                                        aria-selected="true">GENERAL INFORMATION</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="lienhe-tab" data-toggle="pill" href="#lienhe"
                                        role="tab" aria-controls="lienhe" aria-selected="false">CONTACT</a>
                                </li>
                                 <li class="nav-item">
                                    <a class="nav-link" id="thongbaov1-tab" data-toggle="pill" href="#thongbaov1"
                                        role="tab" aria-controls="thongbaov1" aria-selected="false">NOTIFICATION</a>
                                </li>
                                 <li class="nav-item">
                                    <a class="nav-link" id="timespam-tab" data-toggle="pill" href="#timespam"
                                        role="tab" aria-controls="timespam" aria-selected="false">TRASH TIME</a>
                                </li>
                            </ul>
                        </div>
                        <div class="card-body">
                            <div class="tab-content" id="custom-tabs-three-tabContent">
                                <div class="tab-pane fade show active" id="custom-tabs-three-home" role="tabpanel"
                                    aria-labelledby="custom-tabs-three-home-tab">
                                    <form action="" method="POST">
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">TITLE</label>
                                                    <input type="text" name="tenweb" value="<?=$NHNTAK->site('tenweb');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">DESCRIBE</label>
                                                    <input type="text" name="mota" value="<?=$NHNTAK->site('mota');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label>WEBSITE LOGO</label>
                                                    <input type="text" name="logo" value="<?=$NHNTAK->site('logo');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">FAVICON</label>
                                                    <input type="text" name="favicon" value="<?=$NHNTAK->site('favicon');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label>COVER IMAGE</label>
                                                    <input type="text" name="anhbia" value="<?=$NHNTAK->site('anhbia');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">KEY WORD</label>
                                                    <input type="text" name="tukhoa" value="<?=$NHNTAK->site('tukhoa');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">PARTNER ID</label>
                                                    <input type="text" name="partner_id" value="<?=$NHNTAK->site('partner_id');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">PARTNER KEY</label>
                                                    <input type="text" name="partner_key" value="<?=$NHNTAK->site('partner_key');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">CARD DISCOUNTS</label>
                                                    <input type="text" name="ckcard" value="<?=$NHNTAK->site('ckcard');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">TOKEN MOMO</label>
                                                    <input type="text" name="token_momo" value="<?=$NHNTAK->site('token_momo');?>" class="form-control">
                                                </div>
                                            </div>
                                            
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">TOKEN BANK</label>
                                                    <input type="text" name="token_bank" value="<?=$NHNTAK->site('token_bank');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">PASSWORD BANK ACCOUNTS</label>
                                                    <input type="password" name="mk_bank" value="<?=$NHNTAK->site('mk_bank');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">BANK NUMBER FINANCIAL ACCOUNTS</label>
                                                    <input type="text" name="stk_bank" value="<?=$NHNTAK->site('stk_bank');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">DEPOSIT CONTENT</label>
                                                    <input type="text" name="noidung_naptien" value="<?=$NHNTAK->site('noidung_naptien');?>" class="form-control">
                                                </div>
                                            </div>
                                             <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">EMAIL ( SMTP )</label>
                                                    <input type="text" name="email" placeholder="" value="<?=$NHNTAK->site('email');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">PASSWORD EMAIL ( SMTP )</label>
                                                    <input type="password" name="pass_email" placeholder="" value="<?=$NHNTAK->site('pass_email');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">TOKEN API TELE</label>
                                                    <input type="text" name="bot_tele" placeholder="" value="<?=$NHNTAK->site('bot_tele');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">ID CHAT TELE</label>
                                                    <input type="text" name="id_chat_tele" placeholder="" value="<?=$NHNTAK->site('id_chat_tele');?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">MAINTENANCE</label>
                                                    <select class="form-control show-tick" name="baotri" required>
                                                     <option value="<?=$NHNTAK->site('baotri');?>"><?=$NHNTAK->site('baotri');?></option>
                                                     <option value="ON">ON</option>
                                                     <option value="OFF">OFF</option>
                                    </select>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        <button name="SaveSettings" class="btn btn-info btn-block btn-icon-left m-b-10"
                                            type="submit"><i class="fas fa-save mr-1"></i>Save Now</button>
                                    </form>
                                </div>
                                <div class="tab-pane fade" id="lienhe" role="tabpanel"
                                    aria-labelledby="lienhe-tab">
                                    <form action="" method="POST">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">CONTACT METHOD</label>
                                            <input type="url" name="zalo" value="<?=$NHNTAK->site('zalo');?>" class="form-control">
                                            </div>
                                        <button name="SaveSettings" class="btn btn-info btn-icon-left btn-block m-b-10"
                                            type="submit"><i class="fas fa-save mr-1"></i>Save Now</button>
                                    </form>
                                </div>
                                <div class="tab-pane fade" id="thongbaov1" role="tabpanel"
                                    aria-labelledby="thongbaov1-tab">
                                    <form action="" method="POST">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">NOTIFICATION</label>
                                            <div class="col-sm-9">
                                            <textarea class="textarea" name="thongbao" rows="6"><?=$NHNTAK->site('thongbao');?></textarea>
                                            </div>
                                        <button name="SaveSettings" class="btn btn-info btn-icon-left btn-block m-b-10"
                                            type="submit"><i class="fas fa-save mr-1"></i>Save Now</button>
                                    </form>
                                </div>
                                </div>
                                <div class="tab-pane fade" id="timespam" role="tabpanel"
                                    aria-labelledby="timespam-tab">
                                    <form action="" method="POST">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">TIME BUY DOMAIN</label>
                                            <input type="number" class="form-control" name="check_time_cron_domain" value="<?=$NHNTAK->site('check_time_cron_domain');?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">TIME CHECK BANK</label>
                                            <input type="number" class="form-control" name="check_time_cron_bank" value="<?=$NHNTAK->site('check_time_cron_bank');?>">
                                        </div>
                                        <button name="SaveSettings" class="btn btn-info btn-icon-left btn-block m-b-10"
                                            type="submit"><i class="fas fa-save mr-1"></i>Save Now</button>
                                    </form>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </section>


    
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<script>
$(function() {
    // Summernote
    $('.textarea').summernote()

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    $('.my-colorpicker2').on('colorpickerChange', function(event) {
        $('.my-colorpicker2 .fa-square').css('color', event.color.toString());
    });
})
</script>

<?php 
    require_once("../../public/admin/Footer.php");
?>