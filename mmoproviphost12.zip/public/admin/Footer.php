<div id="thongbao"></div>

<script type="text/javascript">
function load_tinnhan()
{
    $.ajax({
        url: "<?=BASE_URL('assets/ajaxs/modaladmin-cart.php');?>",
        type: "GET",
        dateType: "text",
        data: {},
        success: function(result) {
            $('#thongbao').html(result);
        }
    });
}
setInterval(function() { $('#thongbao').load(load_tinnhan()); }, 2000);
</script>

<script type="text/javascript">
function load_tinnhan()
{
    $.ajax({
        url: "<?=BASE_URL('assets/ajaxs/modaladmin-shop.php');?>",
        type: "GET",
        dateType: "text",
        data: {},
        success: function(result) {
            $('#thongbao').html(result);
        }
    });
}
setInterval(function() { $('#thongbao').load(load_tinnhan()); }, 2000);
</script>

<footer class="main-footer">
    
    <b>Version</b> <b style="color:red;">1.2.7</b> - <strong>Powered By <a
            href="https://dichvuweb.asia/" target="_blank">DICHVUWEB.ASIA</a></strong>
  </footer>
<!-- jQuery -->
<script src="<?=BASE_URL('template-admin/');?>plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?=BASE_URL('template-admin/');?>plugins/jquery-ui/jquery-ui.min.js"></script>
<script>
$.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?=BASE_URL('template-admin/');?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?=BASE_URL('template-admin/');?>plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="<?=BASE_URL('template-admin/');?>plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="<?=BASE_URL('template-admin/');?>plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?=BASE_URL('template-admin/');?>plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?=BASE_URL('template-admin/');?>plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?=BASE_URL('template-admin/');?>plugins/moment/moment.min.js"></script>
<script src="<?=BASE_URL('template-admin/');?>plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?=BASE_URL('template-admin/');?>plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js">
</script>
<!-- Summernote -->
<script src="<?=BASE_URL('template-admin/');?>plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?=BASE_URL('template-admin/');?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?=BASE_URL('template-admin/');?>dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?=BASE_URL('template-admin/');?>dist/js/pages/dashboard.js"></script>
<!-- bootstrap color picker -->
<script src="<?=BASE_URL('template-admin/');?>plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<!-- Ekko Lightbox -->
<script src="<?=BASE_URL('template-admin/');?>plugins/ekko-lightbox/ekko-lightbox.min.js"></script>
<!-- DataTables -->
<script src="<?=BASE_URL('template-admin/');?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?=BASE_URL('template-admin/');?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?=BASE_URL('template-admin/');?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?=BASE_URL('template-admin/');?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.6/clipboard.min.js"></script>
<script>
new ClipboardJS('.copy');
</script>
</body>

</html>