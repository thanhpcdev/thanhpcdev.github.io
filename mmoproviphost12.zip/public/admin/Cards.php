<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'QUẢN LÝ NẠP THẺ | '.$NHNTAK->site('tenweb');
    require_once("../../public/admin/Header.php");
    require_once("../../public/admin/Sidebar.php");
?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Lịch sử nạp thẻ</h1>
          </div>
          <div class="col-sm-6">
           
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card card-outline card-red">
              <div class="card-header">
                <h3 class="card-title">Lịch sử nạp thẻ cào</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th width="5%">#</th>
                    <th>Username</th>
                    <th>Nhà mạng</th>
                    <th>Mã thẻ</th>
                    <th>Số seri</th>
                    <th>Mệnh giá</th>
                    <th>Thực nhận</th>
                    <th>Trạng thái</th>
                    <th>Nạp lúc</th>
                  </tr>
                  </thead>
                 <tbody>
                    <?php
                    $i = 0;
                    foreach($NHNTAK->get_list(" SELECT * FROM `cards` ORDER BY id DESC ") as $row){
                    ?>
                   <tr>
                        <td><?=$i++;?></td>
                        <td><a href="<?=BASE_URL('Admin/User/Edit/'.$NHNTAK->getUser($row['username'])['id']);?>" target="_blank"><?=$row['username'];?></a></td>
                        <td><center><?=loaithe($row['loaithe']);?></center></td>
                        <td><b><?=$row['pin'];?></b></td>
                        <td><b><?=$row['seri'];?></b></td>
                        <td><b style="color: red;"><?=format_cash($row['menhgia']);?>đ</b></td>
                        <td><b style="color: green;"><?=format_cash($row['thucnhan']);?>đ</b></td>
                        <td><?=status($row['status']);?></td>
                        <td><?=$row['thoigian'];?></td>
                    </tr>
                    <?php }?>
                </tbody>
                  <tfoot>
                  <tr>
                    <th width="5%">#</th>
                    <th>Username</th>
                    <th>Nhà mạng</th>
                    <th>Mã thẻ</th>
                    <th>Số seri</th>
                    <th>Mệnh giá</th>
                    <th>Thực nhận</th>
                    <th>Trạng thái</th>
                    <th>Nạp lúc</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  
<?php 
    require_once("./Footer.php");
?>