<?php
/* TUANORI.COM - PHÁT TRIỂN MÃ NGUỒN 2022 - 2023 */
    require_once("../../core/config.php");
    require_once("../../core/function.php");
    $title = 'EDIT GÓI WHM | '.$TUANORI->site('tenweb');
    require_once("../../pages/admin/Head.php");
    require_once("../../pages/admin/Header.php");
    CheckLogin();
?>
<?php
if(isset($_GET['delete']) && $getUser['level'] == 'admin')
{
    $TUAN   = $TUANORI->get_row(" SELECT * FROM `goihost` WHERE `id` = '".$_GET['delete']."' AND `type` = 'ADMINWHM'");
    $TUAN2  = $TUANORI->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '".$TUAN['serverhost']."'  AND `theloai` = 'ADMINWHM' ");
    $remove = json_decode(apiWHM($TUAN2['taikhoanrsl'], $TUAN2['matkhaursl'],$TUAN2['linkrsl'].":2087/json-api/killpkg?api.version=1&pkgname=".$TUAN2['taikhoanrsl']."_".$TUAN['nameGoi']), true);
    if(isset($remove['metadata']))
    {
        if($remove['metadata']['version'] == 1)
        {
            $delete = $TUANORI->remove("goihost", " `id` = '".$_GET['delete']."' ");
            if($delete)
            {
                msg_success("Xóa gói thành công",BASE_URL('Admin/Goi/WHM/Add/'.$_SESSION['id']),  1000);
            }
            else
            {
                msg_error("Xóa thất bại",BASE_URL('Admin/AddAddWhm'),  1000);
            }
        }
        else
        {
            msg_error("Đã xảy ra lỗi khi xóa Gói. Vui lòng kiểm tra lại RSL",BASE_URL('Admin/AddAddWhm'),  1000);
        }
    }
    else
    {
        msg_error("Không nhận được dữ liệu từ API",BASE_URL('Admin/Goi/Add/'.$_SESSION['id']),  1000);
    }
}
if(isset($_GET['id']) && $getUser['level'] == 'admin')
{
    $id     = check_string($_GET['id']);
    $row    = $TUANORI->get_row(" SELECT * FROM `goihost` WHERE `id` = '$id' AND `type` = 'ADMINWHM' ");
    if(!$row)
    {
        msg_error("Server này không tồn tại", BASE_URL('Admin/AddAddWhm'), 2000);
    }
    $data2    = $TUANORI->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '".$row['serverhost']."' AND `theloai` = 'ADMINWHM' ");
}
else
{
    msg_error("Liên kết không hợp lệ", BASE_URL('Admin/AddAddWhm'), 1000);
}
?>
<?php
if(isset($_POST['EditGoi']) && $getUser['level'] == 'admin' && $row['serverhost'])
{
    $name       = check_string($row['nameGoi']);
    $quota      = check_string($_POST['quota']);
    $bwlimit    = check_string($_POST['bwlimit']);
    $maxsub     = check_string($_POST['maxsub']);
    $maxpark    = check_string($_POST['maxpark']);
    $maxaddon   = check_string($_POST['maxaddon']);
    $money      = check_string($_POST['money']);
    $status     = check_string($_POST['status']);
    if(!$name || !$quota || !$bwlimit || !$maxsub || !$maxpark || !$maxaddon || !$status)
    {
        msg_error("Vui lòng nhập đầy đủ thông tin", "", 1000);
    }
    if(!$TUANORI->get_row(" SELECT * FROM `goihost` WHERE `nameGoi` = '$name' "))
    {
        msg_error("Gói này chưa tồn tại trong hệ thống", "", 1000);
    }
    if($data2['status'] !== 'SHOW')
    {
        msg_error("Máy chủ phải hoạt động mới có thể gia hạn", "", 1000);
    }
    if($bwlimit == 'bwlimit')
    {
        $bangthong = '1048576';
    }
    if($status == 'SHOW')
    {
        $data = json_decode(apiWHM($data2['taikhoanrsl'], $data2['matkhaursl'],$data2['linkrsl'].":2087/json-api/editpkg?api.version=1&name=$name&quota=$quota&bwlimit=$bangthong&maxsub=$maxsub&maxpark=$maxpark&maxaddon=$maxaddon&cgi=1&reseller=1"), true);
        if(isset($data['metadata']['result']))
        {
            if($data['metadata']['result'] == 1)
            {
                $update = $TUANORI->update("goihost", array(
                    'serverhost'    => $data2['nameGetServer'],
                    'nameGoi'       => $name,
                    'money'         => $money,
                    'dungluong'     => $quota,
                    'bangthong'     => $bwlimit,
                    'miencon'       => $maxsub,
                    'mienkhac'      => $maxaddon,
                    'mienbidanh'    => $maxpark,
                    'backup'        => $data2['backup'],
                    'status'        => $status
                ), " `id` = '".$row['id']."' ");
                if($update)
                {
                    msg_success("Đã lưu dữ liệu gói thành công", "", 1000);
                }
                else
                {
                    msg_error("Không thể lưu dữ liệu vào DATABASE", "", 1000);
                }
            }
            else
            {
                msg_error($data['metadata']['reason'], "", 1000);
            }
        }
        else
        {
            msg_error("Không nhận được dữ liệu từ RSL", "", 1000);
        }
    }
    else
    {
        $TUANORI->update("goihost", array(
            'status'  => $status
        ), " `id` = '".$row['id']."' ");
        msg_success("Đã lưu dữ liệu gói thành công", "", 1000);
    }
}
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Gói</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Add Gói</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- Add Gói elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add gói vào server <b><?=$row['nameServer'];?></b></h3><br/>
                <b>Lưu ý: Quá trình sửa gói, hệ thống sẽ API sửa thẳng vào RSL của khách hàng.</b>
              </div>
              <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Tên Gói</label>
                    <input type="text" class="form-control" name="name" placeholder="Tên Gói" value="<?=$row['nameGoi'];?>" disabled>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Giá tiền gói</label>
                    <input type="number" class="form-control" name="money" placeholder="Giá tiền gói" value="<?=$row['money'];?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Hạn Mức Dung Lượng Đĩa (MB)</label>
                    <input type="text" class="form-control" name="quota" placeholder="Hạn Mức Dung Lượng Đĩa (MB)" value="<?=$row['dungluong'];?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Giới Hạn Băng Thông Hàng Tháng (MB) (Không giới hạn, vui lòng ghi: <a style="color:red">unlimited</a>)</label>
                    <input type="text" class="form-control" name="bwlimit"  placeholder="Giới Hạn Băng Thông Hàng Tháng (MB)" value="<?=$row['bangthong'];?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Số Miền Con Tối Đa (Không giới hạn, vui lòng ghi: <a style="color:red">unlimited</a>)</label>
                    <input type="text" class="form-control" name="maxsub" placeholder="Số Miền Con Tối Đa" value="<?=$row['miencon'];?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Số Miền Phụ Tối Đa (Không giới hạn, vui lòng ghi: <a style="color:red">unlimited</a>)</label>
                    <input type="text" class="form-control" name="maxpark" placeholder="Số Miền Phụ Tối Đa" value="<?=$row['mienbidanh'];?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Số Miền Khác Tối Đa (Không giới hạn, vui lòng ghi: <a style="color:red">unlimited</a>)</label>
                    <input type="text" class="form-control" name="maxaddon" placeholder="Số Miền Khác Tối Đa" value="<?=$row['mienkhac'];?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Ngôn ngữ</label>
                    <select class="form-control select2" name="language" disabled>
                        <option value="vi" selected="selected">Tiếng Việt</option>
                        <option value="ar">Tiếng A-rập (العربية)</option>
                        <option value="bg">Tiếng Bun-ga-ri (български)</option>
                        <option value="cs">Tiếng Séc (čeština)</option>
                        <option value="da">Tiếng Đan Mạch (dansk)</option>
                        <option value="de">Tiếng Đức (Deutsch)</option>
                        <option value="el">Tiếng Hy Lạp (Ελληνικά)</option>
                        <option value="en">Tiếng Anh (English)</option>
                        <option value="es">Tiếng Tây Ban Nha (español)</option>
                        <option value="es_419">Tiếng Tây Ban Nha (Mỹ La tinh) (español latinoamericano)</option>
                        <option value="es_es">Tiếng Tây Ban Nha (I-bê-ri) (español de España)</option>
                        <option value="fi">Tiếng Phần Lan (suomi)</option>
                        <option value="fil">Tiếng Philipin (Filipino)</option>
                        <option value="fr">Tiếng Pháp (français)</option>
                        <option value="he">Tiếng Hê-brơ (עברית)</option>
                        <option value="hu">Tiếng Hung-ga-ri (magyar)</option>
                        <option value="i_cpanel_snowmen">☃ cPanel Snowmen ☃ - i_cpanel_snowmen</option>
                        <option value="i_en">i_en</option>
                        <option value="id">Tiếng In-đô-nê-xia (Bahasa Indonesia)</option>
                        <option value="it">Tiếng Ý (italiano)</option>
                        <option value="ja">Tiếng Nhật (日本語)</option>
                        <option value="ko">Tiếng Hàn Quốc (한국어)</option>
                        <option value="ms">Tiếng Ma-lay-xi-a (Bahasa Melayu)</option>
                        <option value="nb">Tiếng Na Uy (Bokmål) (norsk bokmål)</option>
                        <option value="nl">Tiếng Hà Lan (Nederlands)</option>
                        <option value="no">Tiếng Na Uy (Norwegian)</option>
                        <option value="pl">Tiếng Ba Lan (polski)</option>
                        <option value="pt">Tiếng Bồ Đào Nha (português)</option>
                        <option value="pt_br">Tiếng Bồ Đào Nha (Braxin) (português do Brasil)</option>
                        <option value="ro">Tiếng Ru-ma-ni (română)</option>
                        <option value="ru">Tiếng Nga (русский)</option>
                        <option value="sl">Tiếng Xlô-ven (slovenščina)</option>
                        <option value="sv">Tiếng Thụy Điển (svenska)</option>
                        <option value="th">Tiếng Thái (ไทย)</option>
                        <option value="tr">Tiếng Thổ Nhĩ Kỳ (Türkçe)</option>
                        <option value="uk">Tiếng U-crai-na (українська)</option>
                        <option value="zh">Tiếng Trung Quốc (中文)</option>
                        <option value="zh_cn">Tiếng Trung Quốc (Trung Quốc) (中文（中国）)</option>
                        <option value="zh_tw">Tiếng Trung Quốc (Đài Loan) (中文（台湾）)</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Giao diện Cpanel</label>
                    <select class="form-control select2" name="cpmod" disabled>
                        <option value="jupiter">jupiter</option>
                        <option value="paper_lantern" selected="selected">paper_lantern (deprecated)</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Status <?=status_show($row['status']);?></label>
                    <select class="form-control select2" name="status">
                        <?php
                        if($row['status'] == 'SHOW')
                        {
                            echo '<option value="SHOW">Hoạt động</option>';
                        }
                        else
                        {
                            echo '<option value="OFF">Ngưng chạy</option>';
                        }
                        ?>
                        <option value="SHOW">Hoạt động</option>
                        <option value="OFF">Ngưng chạy</option>
                    </select>
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="EditGoi" class="btn btn-primary">Lưu Dữ Liệu Gói</button>
                </div>
              </form>
            </div>
            <!-- /.card -->

          
          </div>
        
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php
    require_once("../../pages/admin/Footer.php");
?>