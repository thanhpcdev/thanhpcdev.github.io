<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'THÊM MẪU SHOP | '.$NHNTAK->site('tenweb');
    require_once("../../public/admin/Header.php");
    require_once("../../public/admin/Sidebar.php");
?>
<?php
if(isset($_GET['delete']) && $getUser['level'] == 'admin')
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_error("KHÔNG THỂ THAO TÁC Ở WEB DEMO", "", 2000);
    }
    $delete = check_string($_GET['delete']);
    $NHNTAK->remove("shopcreate", " `id` = '$delete' ");
    admin_msg_success("Xóa thành công", BASE_URL("Admin/AddShop"), 300);
}

if(isset($_POST['btnThemMien']) && $getUser['level'] == 'admin') 
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_error("KHÔNG THỂ THAO TÁC Ở WEB DEMO", "", 2000);
    }
    $NHNTAK->insert("shopcreate", array(
        'title'         => check_string($_POST['title']),
        'sotien'        => check_string($_POST['sotien']),
        'anhdemo'       => check_string($_POST['anhdemo']),
        'demoonline'    => check_string($_POST['demoonline'])
    ));
    admin_msg_success("Thêm thành công", '', 1000);
}

if(isset($_POST['btnSave']) && $getUser['level'] == 'admin') 
{
    if($NHNTAK->site('status_demo') == 'ON')
    {
        admin_msg_error("KHÔNG THỂ THAO TÁC Ở WEB DEMO", "", 2000);
    }
    $NHNTAK->update("shopcreate", array(
        'title'         => check_string($_POST['title']),
        'sotien'        => check_string($_POST['sotien']),
        'anhdemo'       => check_string($_POST['anhdemo']),
        'demoonline'    => check_string($_POST['demoonline'])
    ), " `id` = '".check_string($_POST['id'])."' ");
    admin_msg_success("Lưu thành công", '', 1000);
}
?>
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Add shop name</h1>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-outline card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Shop FOR SALE</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="datatable" class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>LOẠI SHOP</th>
                                        <th>GIÁ TIỀN</th>
                                        <th>ẢNH DEMO</th>
                                        <th>DEMO TRỰC TIẾP</th>
                                        <th width="20%">THAO TÁC</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $i = 0 ; foreach($NHNTAK->get_list(" SELECT * FROM `shopcreate` ORDER BY id DESC ") as $row){ ?>
                                 <tr>
                                     <td><?=$i++;?></td>
                                     <td><b><?=$row['title'];?></b></td>
                                     <td><?=format_cash($row['sotien']);?>đ</td>
                                     <td><?=$row['anhdemo'];?></td>
                                     <td><?=$row['demoonline'];?></td>
                                     <td>
                                        <a type="button" href="#" data-toggle="modal"
                                            data-target="#Edit<?=$row['id'];?>" class="btn btn-primary"><i
                                                class="fas fa-edit"></i>
                                            <span>EDIT</span></a>
                                        <a type="button"
                                            href="<?=BASE_URL('Admin/AddShop?delete='.$row['id']);?>"
                                            class="btn btn-danger"><i class="fas fa-trash"></i>
                                            <span>DELETE</span></a>
                                     </td>
                                 </tr>
                                 <div class="modal fade" id="Edit<?=$row['id'];?>" tabindex="-1" role="dialog">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title" id="defaultModalLabel">EDIT SHOP
                                                    </h4>
                                                </div>
                                                <form action="" method="POST">
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="title"
                                                                    placeholder="Loại shop"
                                                                    value="<?=$row['title'];?>" class="form-control"
                                                                    required>
                                                                <input type="hidden" name="id" value="<?=$row['id'];?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="sotien"
                                                                    placeholder="Số tiền"
                                                                    class="form-control" value="<?=$row['sotien'];?>"
                                                                    required>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="anhdemo"
                                                                    placeholder="Ảnh demo"
                                                                    class="form-control" value="<?=$row['anhdemo'];?>"
                                                                    required>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="demoonline"
                                                                    placeholder="Demo trực tiếp"
                                                                    class="form-control" value="<?=$row['demoonline'];?>"
                                                                    required>
                                                            </div>
                                                        </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger waves-effect"
                                                            data-dismiss="modal"><span>ĐÓNG</span></button>
                                                        <button type="submit" name="btnSave"
                                                            class="btn btn-primary waves-effect"><span>LƯU
                                                                LẠI</span></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                 <?php } ?>
                                 </tbody>
                                <tfoot>
                                    <tr>

                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        <a type="button" href="#" data-toggle="modal" data-target="#AddBank"
                            class="btn btn-info btn-block"><i class="fas fa-plus-circle"></i> <span>THÊM SHOP MỚI</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>



<div class="modal fade" id="AddBank" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">THÊM MẪU SHOP MUỐN BÁN</h4>
            </div>
            <form action="" method="POST">
                <div class="modal-body">
                   <div class="form-group">
                        <div class="form-line">
                            <input type="text" name="title" placeholder="Loại shop" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" name="sotien" placeholder="Số tiền" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" name="anhdemo" placeholder="Ảnh demo" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" name="demoonline" placeholder="Demo trực tiếp" class="form-control" required>
                        </div>
                    </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger waves-effect"
                        data-dismiss="modal"><span>ĐÓNG</span></button>
                    <button type="submit" name="btnThemMien" class="btn btn-primary waves-effect"><span>THÊM
                            NGAY</span></button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
</div>
<script>
$(function() {
    $("#datatable").DataTable({
        "responsive": true,
        "autoWidth": false,
    });
    $("#datatable1").DataTable({
        "responsive": true,
        "autoWidth": false,
    });
});
</script>
<?php 
    require_once("./Footer.php");
?>