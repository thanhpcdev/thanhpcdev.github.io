<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'DASHBROAD | '.$NHNTAK->site('tenweb');
    require_once("../../public/admin/Header.php");
    require_once("../../public/admin/Sidebar.php");
?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="alert alert-dark">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <h5>Thông báo gửi đến quý khách hàng</h5>
            <ul>
                <li>Phiên bản: 1.2.7 - Phiên bản mặc định</li>
                <li>Cập nhật thêm tính năng, Bảo Trì, Fix Lỗi.</li>
            </ul>
        </div>
        
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3 id="total_users"><?=format_cash($NHNTAK->num_rows("SELECT * FROM `users` "));?></h3>

                <p>Tổng thành viên <i class="fa fa-spinner fa-spin"></i></p>
              </div>
              <div class="icon">
                <i class="fas fa-users"></i>
              </div>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3 id="total_money"><?=format_cash($NHNTAK->get_row("SELECT SUM(`money`) FROM `users` ")['SUM(`money`)']);?>đ</h3>
                <p>Tổng số dư thành viên <i class="fa fa-spinner fa-spin"></i></p>
              </div>
              <div class="icon">
                <i class="fas fa-money-bill-alt"></i>
              </div>
            </div>
          </div>
          <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                    <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-money-check-alt"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Tổng tiền nạp trong tháng</span>
                        <span class="info-box-number">
                            <?=format_cash(
                            $NHNTAK->get_row("SELECT SUM(`sotien`) FROM `napatm` WHERE YEAR(thoigian) = ".date('Y')." AND MONTH(thoigian) = ".date('m')." ")['SUM(`sotien`)'] +
                            $NHNTAK->get_row("SELECT SUM(`thucnhan`) FROM `cards` WHERE `status` = 'thanhcong' AND YEAR(thoigian) = ".date('Y')." AND MONTH(thoigian) = ".date('m')." ")['SUM(`thucnhan`)'] );?>
                            <small>đ</small>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                    <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-money-check-alt"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Tổng tiền nạp trong tuần</span>
                        <span class="info-box-number">
                            <?=format_cash(
                            $NHNTAK->get_row("SELECT SUM(`sotien`) FROM `napatm` WHERE WEEK(thoigian, 1) = WEEK(CURDATE(), 1) ")['SUM(`sotien`)'] +
                            $NHNTAK->get_row("SELECT SUM(`thucnhan`) FROM `cards` WHERE `status` = 'thanhcong' AND WEEK(thoigian, 1) = WEEK(CURDATE(), 1) ")['SUM(`thucnhan`)'] );?>
                            <small>đ</small>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                    <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-money-check-alt"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Tổng tiền nạp hôm nay</span>
                        <span class="info-box-number">
                            <b id="tong_tien_nap_hom_nay"> <?=format_cash(
                            $NHNTAK->get_row("SELECT SUM(`sotien`) FROM `napatm` WHERE `thoigian` >= DATE(NOW()) AND `thoigian` < DATE(NOW()) + INTERVAL 1 DAY ")['SUM(`sotien`)'] +
                            $NHNTAK->get_row("SELECT SUM(`thucnhan`) FROM `cards` WHERE `status` = 'thanhcong' AND `thoigian` >= DATE(NOW()) AND `thoigian` < DATE(NOW()) + INTERVAL 1 DAY ")['SUM(`thucnhan`)']
                            );?></b>
                            <small>đ</small>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                    <span class="info-box-icon bg-success elevation-1"><i class="fas fa-users"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Thành viên đăng ký trong tuần</span>
                        <span class="info-box-number">
                            <?=format_cash($NHNTAK->num_rows("SELECT * FROM `users` WHERE WEEK(createdate, 1) = WEEK(CURDATE(), 1) "));?>
                            <small>user</small>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                    <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-shopping-basket"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Tên miền đã bán hôm nay</span>
                        <span class="info-box-number"><b id="domain_da_ban_hom_nay">
                                 <?=format_cash($NHNTAK->num_rows(" SELECT * FROM `hisdomain` WHERE `status` = 'thanhcong'"));?>
                            </b> <small>tên miền</small>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                    <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-shopping-basket"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Shop đã tạo hôm nay</span>
                        <span class="info-box-number"><b id="shop_da_ban_hom_nay">
                                 <?=format_cash($NHNTAK->num_rows(" SELECT * FROM `history_shop` WHERE `status` = 'thanhcong'"));?>
                            </b> <small>shop</small>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                    <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-shopping-basket"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Tên miền đang xử lý</span>
                        <span class="info-box-number"><b id="domain_da_ban_hom_nay">
                                 <?=format_cash($NHNTAK->num_rows(" SELECT * FROM `hisdomain` WHERE `status` = 'xuly'"));?>
                            </b> <small>tên miền</small>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                    <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-shopping-basket"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Shop đang xử lý</span>
                        <span class="info-box-number"><b id="shop_da_ban_hom_nay">
                                 <?=format_cash($NHNTAK->num_rows(" SELECT * FROM `history_shop` WHERE `status` = 'xuly'"));?>
                            </b> <small>shop</small>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                    <span class="info-box-icon bg-success elevation-1"><i class="fas fa-users"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Thành viên đăng ký hôm nay</span>
                        <span class="info-box-number">
                            <b id="thanh_vien_dang_ky_hom_nay"><?=format_cash($NHNTAK->num_rows("SELECT * FROM `users` WHERE `createdate` >= DATE(NOW()) AND `createdate` < DATE(NOW()) + INTERVAL 1 DAY "));?>
                            </b><small>user</small>
                        </span>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <section class="col-lg-12 connectedSortable">
                <div class="card card-primary card-outline">
                    <div class="card-header">
                        <h3 class="card-title">
                            500 LỊCH SỬ GIAO DỊCH GẦN ĐÂY
                        </h3>
                        <div class="card-tools">
                            <button type="button" class="btn bg-success btn-sm" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>
                            <button type="button" class="btn bg-warning btn-sm" data-card-widget="maximize"><i
                                    class="fas fa-expand"></i>
                            </button>
                            <button type="button" class="btn bg-danger btn-sm" data-card-widget="remove">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="datatable" class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>USERNAME</th>
                                        <th>SỐ TIỀN TRƯỚC</th>
                                        <th>SỐ TIỀN THAY ĐỔI</th>
                                        <th>SỐ TIỀN HIỆN TẠI</th>
                                        <th>THỜI GIAN</th>
                                        <th>NỘI DUNG</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 0;
                                    foreach($NHNTAK->get_list(" SELECT * FROM `dongtien` ORDER BY id DESC LIMIT 500 ") as $row){
                                    ?>
                                    <tr>
                                        <td><?=$i++;?></td>
                                        <td><?=$row['username'];?>
                                        </td>
                                        <td><?=format_cash($row['sotientruoc']);?></td>
                                        <td><?=format_cash($row['sotienthaydoi']);?></td>
                                        <td><?=format_cash($row['sotiensau']);?></td>
                                        <td><span class="badge badge-dark"><?=$row['thoigian'];?></span></td>
                                        <td><?=$row['noidung'];?></td>
                                    </tr>
                                    <?php }?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>STT</th>
                                        <th>USERNAME</th>
                                        <th>SỐ TIỀN TRƯỚC</th>
                                        <th>SỐ TIỀN THAY ĐỔI</th>
                                        <th>SỐ TIỀN HIỆN TẠI</th>
                                        <th>THỜI GIAN</th>
                                        <th>NỘI DUNG</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
<!-- /.content -->
</div>
</div>
<script>
$(function() {
    $("#datatable").DataTable({
        "responsive": false,
        "autoWidth": false,
    });
    $("#datatable1").DataTable({
        "responsive": false,
        "autoWidth": false,
    });
});
</script>
<?php 
    require_once("../../public/admin/Footer.php");
?>