<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'TÊN MIỀN ĐÃ BÁN | '.$NHNTAK->site('tenweb');
    require_once(__DIR__."/Header.php");
    require_once(__DIR__."/Sidebar.php");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Đơn hàng mua tên miền</h1>
          </div>
          <div class="col-sm-6">
           
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card card-outline card-red">
              <div class="card-header">
                <h3 class="card-title">Lịch sử mua tên miền</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th width="5%">#</th>
                    <th>Username</th>
                    <th>Tên miền</th>
                    <th>Năm mua</th>
                    <th>Tổng tiền</th>
                    <th>Mua lúc</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                  </tr>
                  </thead>
                 <tbody>
                    <?php
                    $i = 0;
                    foreach($NHNTAK->get_list(" SELECT * FROM `hisdomain` ORDER BY id DESC ") as $row){
                    ?>
                   <tr>
                        <td><?=$i++;?></td>
                        <td><a href="<?=BASE_URL('Admin/User/Edit/'.$NHNTAK->getUser($row['username'])['id']);?>" target="_blank"><?=$row['username'];?></a></td>
                        <td><b><?=$row['domain'];?></b></td>
                        <td><b><?=$row['nam'];?> năm</b></td>
                        <td><b><?=format_cash($row['tongtien']);?>đ</b></td>
                        <td><b style="color: red;"><?=format_date($row['timemua']);?></b></td>
                        <td><?=status($row['status']);?></td>
                        <td>
                            <a href="<?=BASE_URL('Admin/Domain/Edit/'.$row['id']);?>"
                                style="color:white;"
                                class="btn btn-info btn-sm btn-icon-left m-b-10" type="button">
                                <i class="fas fa-edit mr-1"></i><span class="">Edit</span>
                            </a>
                            
                        </td>
                    </tr>
                    <?php }?>
                </tbody>
                  <tfoot>
                  <tr>
                    <th width="5%">#</th>
                    <th>Username</th>
                    <th>Tên miền</th>
                    <th>Năm mua</th>
                    <th>Tổng tiền</th>
                    <th>Mua lúc</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

<?php 
    require_once(__DIR__."/Footer.php");
?>