 <style>
    .text {
            text-align: center
}
  </style>
<div class="intro-y box mt-5">
<div class="flex flex-col sm:flex-row items-center p-5 border-b border-gray-200">
    <div class="py-2 text-white font-medium"  bis_skin_checked="1">
    <center>    <div class="max-w-6xl mx-auto text" bis_skin_checked="1">
        <h4 class="text-xl font-bold text mb-4">  <div class="text"> <script type="text/javascript">
farbbibliothek = new Array();
farbbibliothek[0] = new Array("#FF0000","#FF4000","#FF8000","#FFC000","#FFFF00","#C0FF00","#80FF00","#40FF00","#00FF00","#00FF40","#00FF80","#00FFC0","#00FFFF","#00C0FF","#0080FF","#0040FF","#0000FF","#4000FF","#8000FF","#C000FF","#FF00FF","#FF00C0","#FF0080","#FF0040");
farbbibliothek[1] = new Array("#FF0000","#FF4000","#FF8000","#FFC000","#FFFF00","#C0FF00","#80FF00","#40FF00","#00FF00","#00FF40","#00FF80","#00FFC0","#00FFFF","#00C0FF","#0080FF","#0040FF","#0000FF","#4000FF","#8000FF","#C000FF","#FF00FF","#FF00C0","#FF0080","#FF0040");
farben = farbbibliothek[0];
function farbschrift(){for(var b=0;b<Buchstabe.length;b++){document.all["a"+b].style.color=farben[b]}farbverlauf()}function string2array(b){Buchstabe=new Array();while(farben.length<b.length){farben=farben.concat(farben)}k=0;while(k<=b.length){Buchstabe[k]=b.charAt(k);k++}}function divserzeugen(){for(var b=0;b<Buchstabe.length;b++){document.write("<span id='a"+b+"' class='a"+b+"'>"+Buchstabe[b]+"</span>")}farbschrift()}var a=1;function farbverlauf(){for(var b=0;b<farben.length;b++){farben[b-1]=farben[b]}farben[farben.length-1]=farben[-1];setTimeout("farbschrift()",30)}var farbsatz=1;function farbtauscher(){farben=farbbibliothek[farbsatz];while(farben.length<text.length){farben=farben.concat(farben)}farbsatz=Math.floor(Math.random()*(farbbibliothek.length-0.0001))}setInterval("farbtauscher()",5000);
text= " OPERATION & DESIGN & DEVELOPER BY THANH PC DEV"; //h
string2array(text);
divserzeugen();
//document.write(text);
</script></center>
        </div>
    </div>
    </div> </div>
</footer>
</div><!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/65a0a68b0ff6374032bf1d31/1hjtol54l';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<script>
$(document).ready(function() {
    $('#mytable').DataTable();
});
$(document).ready(function() {
    $('#mytable1').DataTable();
});
</script>
<div id="thongbao"></div>
<script src="<?=BASE_URL('')?>template/js/admin_ndkdark.js"></script>
<script src="<?=BASE_URL('')?>template/js/app.js"></script>
<script src="<?=BASE_URL('')?>template/dist/js/toastr.min.js"></script>
<!-- CODE ĐƯỢC VIẾT LẠI BỞI NDK Dark | DICHVUWEB.ASIA -->
</body>
</html>