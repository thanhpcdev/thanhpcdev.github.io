<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'QUẢN LÍ HOSTING | '.$NHNTAK->site('mota');
    require_once("../../public/client/Header.php");
    CheckLogin();
   
?>
<?php $i = 1; foreach($NHNTAK->get_list(" SELECT * FROM `historyhost` WHERE `username` = '".$getUser['username']."' ORDER BY id DESC") as $row){ ?>
<body class="main">
<?php require_once("../../public/client/Sidebar.php");?>
    <?php require_once("../../public/client/Navbar.php");?>
    <div class="wrapper">
        <div class="wrapper-box">
        <?php require_once("../../public/client/SidebarPc.php");?>
        <div class="content">
                <div class="col-span-12 lg:col-span-12 2xl:col-span-12">
                    <!-- BEGIN: Bordered Table -->
                    <div class="intro-y box mt-5">
                        <div class="flex flex-col sm:flex-row items-center p-5 border-b border-gray-200">
                            <h2 class="font-bold text-2xl mr-auto">
                                Quản Lí Hosting Với Tên Miền <?=$row['domain'];?>
                            </h2>
                             <?php } ?>
                                    </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
               
            </div>
        </div>
<?php
require_once("../../public/client/Footer.php");
?>