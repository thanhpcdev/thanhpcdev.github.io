<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'CHUYỂN KHOẢN QR | '.$NHNTAK->site('mota');
    require_once("../../public/client/Header.php");
    CheckLogin();
?>
<body class="main">
<?php require_once("../../public/client/Sidebar.php");?>
    <?php require_once("../../public/client/Navbar.php");?>
    <div class="wrapper">
        <div class="wrapper-box">
        <?php require_once("../../public/client/SidebarPc.php");?>
        <div class="content">
                <!-- BEGIN: Pricing Tab -->
                <div class="flex mt-10">
                    <div class="tab-content">
                        <div id="layout-1-monthly-fees" class="tab-pane flex flex-col lg:flex-row active" role="tabpanel" aria-labelledby="layout-1-monthly-fees-tab">
                        <?php foreach($NHNTAK->get_list("SELECT * FROM `bank` ") as $bank) { ?>
                            <div class="intro-y flex-1 box py-16 lg:ml-5 mb-5 lg:mb-0">
                                <div style="height: 150px;">
                                <img class="mx-auto" src="<?=list_img_bank($bank['logo']);?>" width="100px" height="0px">
                               </div>
                                
                                <table class="table table-bordered">
                                    <tbody>
                                        <tr>
                                            <td class="text-right">
                                                <span>Tên tài khoản:</span>
                                                <br>
                                            </td>
                                            <td class="text-left payment-instruction">
                                                <div>
                                                    <span><?=$bank['bank_name'];?></span>
                                                    <br>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr class="" style="background-color:#FBFBFB;">
                                            <td class="text-right">
                                                <strong style="color: green;">Số tài khoản:</strong>
                                            </td>
                                            <td class="text-left payment-instruction">
                                                <strong>
                                                    <input style="color:red; border-style: none; background-color: #FBFBFB; font-weight: bold;  padding: 0px" value="<?=$bank['stk'];?>" id="input01" readonly="">
                                                </strong>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="text-right">
                                                 <span>Ngân hàng:</span>
                                                <br>
                                            </td>
                                            <td class="text-left payment-instruction">
                                                <div>
                                                    <span> <?=$bank['name'];?></span>
                                                    <br>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="text-right">
                                                <span>Nội dung:	</span>
                                            </td>
                                            <td class="text-left payment-instruction">
                                                <strong>
                                                    <input style="color:red; border-style: none; font-weight: bold;  padding: 0px" value="<?=$NHNTAK->site('noidung_naptien').$getUser['id'];?>" id="input02" readonly="">
                                                </strong>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <center><i><i class="fa fa-spinner fa-spin"></i> Xử lý giao dịch tự động trong vài
                                        giây...</i></center>
                             </div>
                            <?php }?>
                            </div>
    </div>
    </div>
    <?php
    require_once("../../public/client/Footer.php");
    ?>