<div class="mobile-menu md:hidden">
    <div class="mobile-menu-bar">
        <a href="<?=BASE_URL('')?>" class="flex mr-auto">
        <img alt="" class="w-6" src="<?=$NHNTAK->site('logo');?>">
        <a href="javascript:;" id="mobile-menu-toggler"> <i data-feather="bar-chart-2"
                class="w-8 h-8 text-white transform -rotate-90"></i> </a>
    </div>
    <ul class="border-t border-theme-2 py-5 hidden">
        <li>
            <a href="<?=BASE_URL('')?>" class="menu menu--active">
                <div class="menu__icon"> <i data-feather="home"></i> </div>
                <div class="menu__title"> Trang chủ </div>
            </a>
        </li>
        <li>
            <a href="javascript:;.html" class="menu menu--active">
                <div class="menu__icon"> <i data-feather="box"></i> </div>
                <div class="menu__title"> Dịch Vụ Tạo Shop <i data-feather="chevron-down"
                        class="menu__sub-icon transform rotate-180"></i> </div>
            </a>
            <ul class="menu__sub-open">
            <li>
                    <a href="<?=BASE_URL('create')?>" class="menu menu--active">
                        <div class="menu__icon"> <i data-feather="shopping-cart"></i> </div>
                        <div class="menu__title"> Tạo Shop Game </div>
                    </a>
            </li>
                <li>
                    <a href="<?=BASE_URL('list-shop')?>" class="menu menu--active">
                        <div class="menu__icon"> <i data-feather="rotate-ccw"></i> </div>
                        <div class="menu__title">  Lịch Sử Tạo Shop </div>
                    </a>
                </li>
            </ul>
        </li>
        <li>
            <a href="javascript:;.html" class="menu menu--active">
                <div class="menu__icon"> <i data-feather="box"></i> </div>
                <div class="menu__title"> Dịch Vụ Tên Miền <i data-feather="chevron-down"
                        class="menu__sub-icon transform rotate-180"></i> </div>
            </a>
            <ul class="menu__sub-open">
            <li>
                    <a href="<?=BASE_URL('Domain')?>" class="menu menu--active">
                        <div class="menu__icon"> <i data-feather="inbox"></i> </div>
                        <div class="menu__title"> Mua Domain </div>
                    </a>
                </li>
                <li>
                    <a href="<?=BASE_URL('Whois')?>" class="menu menu--active">
                        <div class="menu__icon"> <i data-feather="globe"></i> </div>
                        <div class="menu__title"> Kiểm Tra Domain </div>
                     </a>
                </li>
            </ul>
        </li>
        <li>
            <a href="javascript:;.html" class="menu menu--active">
                <div class="menu__icon"> <i data-feather="box"></i> </div>
                <div class="menu__title">Dịch Vụ Source<i data-feather="chevron-down"
                        class="menu__sub-icon transform rotate-180"></i> </div>
            </a>
            <ul class="menu__sub-open">
            <li>
                    <a href="<?=BASE_URL('View-Source')?>" class="menu menu--active">
                        <div class="menu__icon"> <i data-feather="inbox"></i> </div>
                        <div class="menu__title"> Mua Code </div>
                    </a>
                </li>
                <li>
                    <a href="<?=BASE_URL('History-Source')?>" class="menu menu--active">
                        <div class="menu__icon"> <i data-feather="globe"></i> </div>
                        <div class="menu__title"> History Source </div>
                     </a>
                </li>
            </ul>
        </li>
        <li>
            <a href="<?=$NHNTAK->site('zalo');?>" class="menu menu--active">
                <div class="menu__icon"> <i data-feather="phone-call"></i> </div>
                <div class="menu__title">
                Hỗ Trợ
                    <div class="menu__sub-icon transform rotate-180"> </div>
                </div>
            </a>
        </li>
        <li>
            <a href="<?=BASE_URL('user/cart');?>" class="menu menu--active">
                <div class="menu__icon"> <i data-feather="shopping-cart"></i> </div>
                <div class="menu__title">Giỏ hàng (<span><?=count($_SESSION['cart']);?></span>)<div class="menu__sub-icon transform rotate-180"></div>
                </div>
            </a>
        </li>
        <div class="side-nav__devider my-6"></div>
        <li>
            <a href="<?=BASE_URL('user/profile')?>" class="menu menu--active">
                <div class="menu__icon"> <i data-feather="users"></i> </div>
                <div class="menu__title"> Hồ sơ</div>
            </a>
        </li>
        <li>
        <a href="javascript:;" class="menu">
        <div class="menu__icon"> <i data-feather="credit-card"></i> </div>
        <div class="menu__title"> Nạp tiền <i data-feather="chevron-down" class="menu__sub-icon "></i> </div>
        </a>
        <ul class="">
        <li>
            <!-- CODE ĐƯỢC VIẾT LẠI BỞI NDK Dark | DICHVUWEB.ASIA -->
                                <a href="/recharge/card" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> Thẻ Cào </div>
                                </a>
                            </li>
                            <li>
                                <a href="/recharge/bank" class="menu">
                                    <div class="menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="menu__title"> ATM/MOMO </div>
                                </a>
                            </li>
                        </ul>
                    </li>
        <?php if(isset($_SESSION['username']) && $getUser['level'] == 'admin') { ?>
        <li>
            <a href="<?=BASE_URL('Admin/Home')?>" class="menu menu--active">
                <div class="menu__icon"> <i data-feather="codesandbox"></i> </div>
                <div class="menu__title">ADMIN PANEL</div>
            </a>
        </li>
        <?php }?>
        

    </ul>
    </li>
    </ul>
</div>