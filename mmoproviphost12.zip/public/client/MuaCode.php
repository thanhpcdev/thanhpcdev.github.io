<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'THANH TOÁN SOURCE CODE | '.$NHNTAK->site('mota');
    require_once("../../public/client/Header.php");
    CheckLogin();
?>
<?php
if(isset($_GET['id']))
{
    $row = $NHNTAK->get_row(" SELECT * FROM `SourceCode` WHERE `id` = '".check_string($_GET['id'])."'  ");
    if(!$row)
    {
        admin_msg_error("Liên kết không tồn tại", BASE_URL(''), 500);
    }
}
else
{
    admin_msg_error("Liên kết không tồn tại", BASE_URL(''), 0);
} 
?>
<body class="main">
<?php require_once("../../public/client/Sidebar.php");?>
    <?php require_once("../../public/client/Navbar.php");?>
    <div class="wrapper">
        <div class="wrapper-box">
        <?php require_once("../../public/client/SidebarPc.php");?>
        <div class="content">
                <div class="intro-y flex items-center mt-5">
                    <div class="quochuy">
                        <h2 class="font-bold text-2xl mr-auto">
                            THANH TOÁN SOURCE CODE #<?=$row['id'];?>
                        </h2>
                    </div>
                </div>
                <div class="grid grid-cols-12 gap-6 mt-5">
                    <div class="intro-y box col-span-12 md:col-span-6 lg:col-span-6 xl:col-span-6">
                        <div class="border-b border-gray-100 dark:border-gray-700 bg-black">
                            <h5 class="text-lg text font-semibold px-5 py-3">Hình Ảnh</h5>
                        </div>
                        <div class="px-4 pt-4">
                            <img src="<?=$row['image'];?>" data-sizes="auto" class="border rounded border-gray-400 w-full">
                        </div>
                    </div>
                    <div class="intro-y box col-span-12 md:col-span-6 lg:col-span-6 xl:col-span-6">
                        <div class="bg w-full mb-5">
                            <div class="border-b border-gray-100 dark:border-gray-700 bg-black">
                                <h5 class="text-lg font-semibold py-3 px-5">Thông Tin</h5>
                            </div>
                            <div class="table-content-2">
                                <div class="py-3 px-4 overflow-x-auto">
                                    <div class="preview">
                                        <div>
                                            <label for="regular-form-1" class="form-label">ID MÃ NGUÒN</label>
                                            <input name="id" type="text" class="form-control" placeholder="#<?=$row['id'];?>" disabled>
                                        </div>

                                        <div class="mt-3">
                                            <label for="regular-form-3" class="form-label">TÊN MÃ NGUỒN</label>
                                            <input name="title" type="text" class="form-control" placeholder="<?=$row['name'];?>" disabled>
                                        </div>
                                        <div class="mt-3">
                                            <label for="regular-form-4" class="form-label">GIÁ THANH TOÁN</label>
                                            <input name="gia" type="number" class="form-control" placeholder="<?=format_cash($row['price']);?> VNĐ" disabled>
                                        </div>
                                        <div class="mt-3">
                                            <label for="regular-form-4" class="form-label">HỖ TRỢ</label>
                                            <input name="baohanh" type="text" class="form-control" placeholder="KHÔNG" disabled>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                       
                            <div class="mt-4 rounded-b-sm grid grid-cols-12 gap-5 px-4">
                                <div class="col-span-6">
                                    <div class="w-full"> <button id="AddCart" class="cursor-pointer border rounded w-full text-center btn btn-primary inline-block mr-1"> <i class="fa fa-shopping-cart mr-2"></i> THÊM VÀO GIỎ HÀNG </button></div>
                                </div>
                                <div class="col-span-6">
                                    <input type="hidden" value="<?=$row['id']?>" id="id">
                                    <div class="w-full"> <a href="/" class="cursor-pointer border rounded w-full text-center btn btn-primary inline-block mr-1"> <i class="fa fa-eye mr-2"></i> XEM BẢN DEMO </a> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    </div>
                    </div>
                    </div>
                    <script type="text/javascript">
        var Noti = function(type, msg) {
            toastr.options = {
                closeButton: true,
                progressBar: true,
                showMethod: 'slideDown',
                timeOut: 1500
            };
            if (type == 2)
                toastr.success(msg, 'Thông báo');
            else
                toastr.error(msg, 'Thông báo');
        };
        $("#AddCart").on("click", function() {
            var id             =       $("<?=$row['id'];?>").val();
            $.LoadingOverlay("show");
            $.ajax({
                url: "<?= BASE_URL("assets/ajaxs/Giohang-Payment.php"); ?>",
                type: "POST",
                dataType: "JSON",
                data: {
                    type: 'add_products', // BY NGUYỄN KHÔI
                    id: <?=$row['id'];?> 
                },
                success: function(response) {
                    $.LoadingOverlay("hide");
                    Noti(response.status, response.msg);
                    if (response.status == 2) {
                        setTimeout(function() {
                            window.location.href = "";
                        }, 1000);
                    } else if (response.status == 1) {
                       $('#AddCart').html('<i class="fa fa-shopping-cart mr-2"></i> THÊM VÀO GIỎ HÀNG').prop('disabled', false);
                    }
                }
            });
        });
    </script>
            <?php
require_once("../../public/client/Footer.php");
?>