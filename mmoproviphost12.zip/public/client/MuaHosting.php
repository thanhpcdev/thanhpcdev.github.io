<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'MUA HOSTING | '.$NHNTAK->site('mota');
    require_once("../../public/client/Header.php");
    CheckLogin();
?>
<?php
if(isset($_GET['id']))
{
    $row = $NHNTAK->get_row(" SELECT * FROM `goihost` WHERE `id` = '".check_string($_GET['id'])."'  ");
    if(!$row)
    {
        admin_msg_error("Liên kết không tồn tại", BASE_URL('/'), 500);
    }
}
else
{
    admin_msg_error("Liên kết không tồn tại", BASE_URL('/'), 0);
} 
?>
<body class="main">
<?php require_once("../../public/client/Sidebar.php");?>
    <?php require_once("../../public/client/Navbar.php");?>
    <div class="wrapper">
        <div class="wrapper-box">
        <?php require_once("../../public/client/SidebarPc.php");?>

        <div class="content">
                <div class="intro-y flex items-center mt-5">
                    <div class="quochuy">
                        <h2 class="font-bold text-2xl mr-auto">
                            CHI TIẾT <?= $row['nameGoi'] ?>
                        </h2>
                    </div>
                </div>
                <div class="grid grid-cols-12 gap-6 mt-5">
                    <div class="intro-y box col-span-12 md:col-span-6 lg:col-span-6 xl:col-span-6">
                        <div class="border-b border-gray-100 dark:border-gray-700 bg-black">
                            <h5 class="text-lg text font-semibold px-5 py-3">THÔNG TIN GÓI</h5>
                        </div>
                        <div class="col-span-12 lg:col-span-6 mt-6">
                            <div class="box p-8 relative overflow-hidden intro-y">
                                <div class="leading-[2.15rem] w-full sm:w-52 text-primary dark:text-white text-xl -mt-3">
                                    HOSTING CHEAP PRO NVMe SSD
                                </div>
                                <div class="w-full sm:w-60 leading-relaxed text-slate-500 mt-2 flex align-center">
                                    <div class="domail-icon mr-2"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" icon-name="hard-drive" data-lucide="hard-drive" class="lucide lucide-hard-drive">
                                            <line x1="22" y1="12" x2="2" y2="12"></line>
                                            <path d="M5.45 5.11L2 12v6a2 2 0 002 2h16a2 2 0 002-2v-6l-3.45-6.89A2 2 0 0016.76 4H7.24a2 2 0 00-1.79 1.11z"></path>
                                            <line x1="6" y1="16" x2="6.01" y2="16"></line>
                                            <line x1="10" y1="16" x2="10.01" y2="16"></line>
                                        </svg></div>
                                    <div class="title-icon">
                                        DISK SSD <?=$row['dungluong']?> MB NVMe SSD
                                    </div>
                                </div>
                                 <div class="w-full sm:w-60 leading-relaxed text-slate-500 mt-2 flex align-center">
                                    <div class="domail-icon mr-2"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" icon-name="hard-drive" data-lucide="hard-drive" class="lucide lucide-hard-drive">
                                            <line x1="22" y1="12" x2="2" y2="12"></line>
                                            <path d="M5.45 5.11L2 12v6a2 2 0 002 2h16a2 2 0 002-2v-6l-3.45-6.89A2 2 0 0016.76 4H7.24a2 2 0 00-1.79 1.11z"></path>
                                            <line x1="6" y1="16" x2="6.01" y2="16"></line>
                                            <line x1="10" y1="16" x2="10.01" y2="16"></line>
                                        </svg></div>
                                    <div class="title-icon">
                                        BĂNG THÔNG <?=$row['bangthong']?> MB 
                                    </div>
                                </div>
                                <div class="w-full sm:w-60 leading-relaxed text-slate-500 mt-2 flex align-center">
                                    <div class="domail-icon mr-2"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" icon-name="box" data-lucide="box" class="lucide lucide-box">
                                            <path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"></path>
                                            <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
                                            <line x1="12" y1="22.08" x2="12" y2="12"></line>
                                        </svg></div>
                                    <div class="title-icon">
                                        SỐ MIỀN CON : <?=$row['miencon']?>
                                    </div>
                                </div>
                                <div class="w-full sm:w-60 leading-relaxed text-slate-500 mt-2 flex align-center">
                                    <div class="domail-icon mr-2"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" icon-name="box" data-lucide="box" class="lucide lucide-box">
                                            <path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"></path>
                                            <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
                                            <line x1="12" y1="22.08" x2="12" y2="12"></line>
                                        </svg></div>
                                    <div class="title-icon">
                                        SỐ MIỀN KHAC : <?=$row['mienkhac']?>
                                    </div>
                                </div>
                                <div class="w-full sm:w-60 leading-relaxed text-slate-500 mt-2 flex align-center">
                                    <div class="domail-icon mr-2"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" icon-name="credit-card" data-lucide="credit-card" class="lucide lucide-credit-card">
                                            <rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect>
                                            <line x1="1" y1="10" x2="23" y2="10"></line>
                                        </svg></div>
                                    <div class="title-icon">
                                        FREE SSL PRO
                                    </div>
                                </div>
                                <div class="w-48 relative mt-6 cursor-pointer tooltip">
                                    <a href="<?=BASE_URL('/hosting') ?>" class="btn btn-elevated-warning w-24 mr-1 mb-2">Thay Đổi</a>
                                </div>
                                <img class="hidden sm:block absolute top-0 right-0 w-1/2 mt-1 -mr-12" alt="Midone - HTML Admin Template" src="https://cloudcore.vn/wp-content/uploads/2021/04/Cloud-WordPRess-Hosting.png">
                            </div>
                        </div>
                    </div>
                    <div class="intro-y box col-span-12 md:col-span-6 lg:col-span-6 xl:col-span-6">
                        <div class="bg w-full mb-5">
                            <div class="border-b border-gray-100 dark:border-gray-700 bg-black">
                                <h5 class="text-lg font-semibold py-3 px-5">Thông Tin</h5>
                            </div>
                            <div class="table-content-2">
                                <div class="py-3 px-4 overflow-x-auto">
                                    <div class="preview">
                                        <div>
                                            <label for="regular-form-1" class="form-label">NAME GÓI</label>
                                            <input name="id" type="text" class="form-control" placeholder="<?=$row['nameGoi'] ?>" disabled>
                                        </div>

                                        <div class="mt-3">
                                            <label for="regular-form-3" class="form-label">TÊN SERVER</label>
                                            <?php foreach($NHNTAK->get_list(" SELECT * FROM `serverhost` ORDER BY id DESC") as $row1){ ?>
                                            <input name="title" type="text" class="form-control" placeholder="<?=$row1['nameServer'] ?>" <?php }?> disabled>
                                        </div>
                                        
                                        <div class="mt-3">
                                            <label for="regular-form-4" class="form-label">NHẬP TÊN MIỀN</label>
                                            <input id="domain" type="text" class="form-control" placeholder="Nhập tên miền của cậu vào">
                                        </div>
                                        
                                        <div class="mt-3">
                                            <label for="regular-form-3" class="form-label">NHẬP EMAIL</label>
                                            <input id="email" type="email" class="form-control" placeholder="Nhập email của bạn vào nhé">
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                                       
                            <div class="mt-4 rounded-b-sm grid grid-cols-12 gap-5 px-4">
                                <div class="col-span-6">
                                    <div class="w-full"> <button id="MuaHost" class="cursor-pointer border rounded w-full text-center btn btn-primary inline-block mr-1"> <i class="fa fa-shopping-cart mr-2"></i> MUA NGAY </button></div>
                                </div>
                                <div class="col-span-6">
                                </div>
                            </div>
                        </div>
                    </div>

            </div>
            <!-- END: Content -->
        </div>
    </div>
    <script type="text/javascript">
        var Noti = function(type, msg) {
            toastr.options = {
                closeButton: true,
                progressBar: true,
                showMethod: 'slideDown',
                timeOut: 1500
            };
            if (type == 2)
                toastr.success(msg, 'Thông báo');
            else
                toastr.error(msg, 'Thông báo');
        };
        $("#MuaHost").on("click", function() {
            $.LoadingOverlay("show");
            $.ajax({
                url: "<?= BASE_URL("assets/ajaxs/MuaHost.php"); ?>",
                type: "POST",
                dataType: "JSON",
                data: {
                    type: 'MuaHost',
                    email: $("#email").val(),
                    domain: $("#domain").val(),
                    theloai: '<?= htmlspecialchars($row['type'], ENT_QUOTES); ?>',
            loai: '<?= htmlspecialchars($row['loai'], ENT_QUOTES); ?>',
            server: '<?= isset($row['serverhost']) ? htmlspecialchars($row['serverhost'], ENT_QUOTES) : '0'; ?>',
            goi: '<?= isset($row['nameGoi']) ? htmlspecialchars($row['nameGoi'], ENT_QUOTES) : '0'; ?>'
        },
                success: function(response) {
                    $.LoadingOverlay("hide");
                    Noti(response.status, response.msg);
                    if (response.status == 2) {
                        setTimeout(function() {
                            window.location.href = "";
                        }, 1000);
                    } else if (response.status == 1) {
                       $('#MuaHost').html('MUA HOSTING NGAY').prop('disabled', false);
                    }
                }
            });
        });
    </script>
    <?php
    require_once("../../public/client/Footer.php");
    ?>