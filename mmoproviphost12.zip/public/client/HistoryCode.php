<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'QUẢN LÝ CODE | '.$NHNTAK->site('mota');
    require_once("../../public/client/Header.php");
    CheckLogin();
?> 
<body class="main">
<?php require_once("../../public/client/Sidebar.php");?>
    <?php require_once("../../public/client/Navbar.php");?>
    <div class="wrapper">
        <div class="wrapper-box">
        <?php require_once("../../public/client/SidebarPc.php");?>
        <div class="content">
                <div class="col-span-12 lg:col-span-12 2xl:col-span-12"> 
                    <!-- BEGIN: Bordered Table -->
                    <div class="intro-y box mt-5">
                        <div class="flex flex-col sm:flex-row items-center p-5 border-b border-gray-200">
                            <h2 class="font-bold text-2xl mr-auto">
                                Lịch Sử Mua Code
                            </h2>
                        </div>
                        <div class="p-5">
                            <div class="preview">
                                <div class="overflow-x-auto">
                                    <table class="table table-report w-full">
                                        <thead>
                                            <tr> 
                                                <th class="whitespace-nowrap">STT</th>
                                                <th class="whitespace-nowrap">TÊN CODE</th>
                                                <th class="whitespace-nowrap">GIÁ CODE</th>
                                                <th class="whitespace-nowrap">THỜI GIAN MUA</th>
                                                <th class="whitespace-nowrap">THAO TÁC</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                    <?php $i = 1; foreach($NHNTAK->get_list(" SELECT * FROM `HistorySource` WHERE `username` = '".$getUser['username']."' ORDER BY id DESC") as $row){ ?>
                                <tr>
                            <td class="text-center"><?=$i++;?></td>
                            <td class="text-center"><?=$row['name'];?></td>
                            <td class="text-center"><?=$row['price'];?></td>
                            <td class="text-center"><?=$row['time'];?></td>
                            <td><a href="<?=$row['link'];?>"<button type="button" class="btn btn-primary btn-sm">TẢI XUỐNG</button></a></td>
                        </tr>
                    <?php } ?>
                                    </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php
require_once("../../public/client/Footer.php");
?>