<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'THANH TOÁN SHOP | '.$NHNTAK->site('mota');
    require_once("../../public/client/Header.php");
    CheckLogin();
?>
<?php
if(isset($_GET['id']))
{
    $row = $NHNTAK->get_row(" SELECT * FROM `shopcreate` WHERE `id` = '".check_string($_GET['id'])."'  ");
    if(!$row)
    {
        admin_msg_error("Liên kết không tồn tại", BASE_URL(''), 500);
    }
}
else
{
    admin_msg_error("Liên kết không tồn tại", BASE_URL(''), 0);
} 
?>
<body class="main">
<?php require_once("../../public/client/Sidebar.php");?>
    <?php require_once("../../public/client/Navbar.php");?>
    <div class="wrapper">
        <div class="wrapper-box">
        <?php require_once("../../public/client/SidebarPc.php");?>
        <div class="content">
                <div class="intro-y flex items-center mt-5">
                    <div class="quochuy">
                        <h2 class="font-bold text-2xl mr-auto">
                            THANH TOÁN SHOP #<?=$row['id'];?>
                        </h2>
                    </div>
                </div>
                <div class="grid grid-cols-12 gap-6 mt-5">
                    <div class="intro-y box col-span-12 md:col-span-6 lg:col-span-6 xl:col-span-6">
                        <div class="border-b border-gray-100 dark:border-gray-700 bg-black">
                            <h5 class="text-lg text font-semibold px-5 py-3">Hình Ảnh</h5>
                        </div>
                        <div class="px-4 pt-4">
                            <img src="<?=$row['anhdemo'];?>" data-sizes="auto" class="border rounded border-gray-400 w-full">
                        </div>
                    </div>
                    <div class="intro-y box col-span-12 md:col-span-6 lg:col-span-6 xl:col-span-6">
                        <div class="bg w-full mb-5">
                            <div class="border-b border-gray-100 dark:border-gray-700 bg-black">
                                <h5 class="text-lg font-semibold py-3 px-5">Thông Tin</h5>
                            </div>
                            <div class="table-content-2">
                                <div class="py-3 px-4 overflow-x-auto">
                                    <div class="preview">
                                        <div>
                                            <label for="regular-form-1" class="form-label">TÊN MIỀN</label>
                                            <input id="domain" type="text" class="form-control" placeholder="Tên miền truy cập shop VD: dichvuweb.asia">
                                            <div class="form-help">Hệ thống sẽ tự động kiểm tra tên miền.</div>
                                        </div>
                                        <div class="mt-3">
                                            <label for="regular-form-4" class="form-label">TÀI KHOẢN (ADMIN)</label>
                                            <input id="tkadmin" type="text" class="form-control" placeholder="Nhập tài khoản admin">
                                        </div>
                                        <div class="mt-3">
                                            <label for="regular-form-3" class="form-label">MẬT KHẨU (ADMIN)</label>
                                            <input id="mkadmin" type="password" class="form-control" placeholder="Nhập mật khẩu admin">
                                            <div class="form-help">Không được để lộ Password Admin.</div>
                                        </div>
                                        <div class="mt-3">
                                            <label for="regular-form-5" class="form-label">THỜI HẠN SHOP</label>
                                            <select class="form-select" id="timeCreate">
                                                <option value="3">3 Tháng</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-4 rounded-b-sm grid grid-cols-12 gap-5 px-4">
                                <div class="col-span-6">
                                    <button id="TaoShop" class="cursor-pointer border rounded w-full text-center btn btn-primary inline-block mr-1"> <i class="fa fa-shopping-cart mr-2"></i> Tạo Ngay </button>
                                </div>
                                <div class="col-span-6">
                                    <div class="w-full"> <a href="<?=$row['demoonline'];?>" class="cursor-pointer border rounded w-full text-center btn btn-primary inline-block mr-1"> <i class="fa fa-eye mr-2"></i> Xem Demo </a> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            </div>
            <script type="text/javascript">
        var Noti = function(type, msg) {
            toastr.options = {
                closeButton: true,
                progressBar: true,
                showMethod: 'slideDown',
                timeOut: 1500
            };
            if (type == 2)
                toastr.success(msg, 'Thông báo');
            else
                toastr.error(msg, 'Thông báo');
        };
        $("#TaoShop").on("click", function() {
            var id             =       $("<?=$row['id'];?>").val();
            var timeCreate     =       $("#timeCreate").val();
            var domain         =       $("#domain").val();
            var tkadmin        =       $("#tkadmin").val();
            var mkadmin        =       $("#mkadmin").val();
            $.LoadingOverlay("show");
            $.ajax({
                url: "<?= BASE_URL("assets/ajaxs/CreateShop.php"); ?>",
                type: "POST",
                dataType: "JSON",
                data: {
                    type: 'TaoShop',
                    timeCreate:       $("#timeCreate").val(),
                    domain:           $("#domain").val(),
                    tkadmin:          $("#tkadmin").val(), 
                    mkadmin:          $("#mkadmin").val(),
                    id: <?=$row['id'];?>
                },
                success: function(response) {
                    $.LoadingOverlay("hide");
                    Noti(response.status, response.msg);
                    if (response.status == 2) {
                        setTimeout(function() {
                            window.location.href = "";
                        }, 1000);
                    } else if (response.status == 1) {
                       $('#TaoShop').html('<i class="fa fa-shopping-cart mr-2"></i> Tạo Ngay').prop('disabled', false);
                    }
                }
            });
        });
    </script>
            <?php
require_once("../../public/client/Footer.php");
?>