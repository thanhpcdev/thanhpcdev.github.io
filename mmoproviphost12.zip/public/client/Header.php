<!DOCTYPE html>
<html lang="en" class="light">
<head>
    <meta charset="utf-8">
    <title><?=$title?></title> 
    <meta property="og:type" content="Website">
    <meta property="og:url" content="<?=BASE_URL('')?>">
    <meta property="og:image" content="<?=$NHNTAK->site('anhbia');?>">
    <meta property="og:site_name" content="<?=$NHNTAK->site('tenweb');?>">
    <meta property="article:section" content="<?=$NHNTAK->site('tenweb');?>">
    <meta property="article:tag"
        content="<?=$NHNTAK->site('mota');?>">
    <meta name="twitter:card" content="<?=$NHNTAK->site('anhbia');?>">
    <meta name="twitter:site" content="">
    <!-- CODE ĐƯỢC VIẾT LẠI BỞI NDK Dark | DICHVUWEB.ASIA -->
    <meta name="twitter:image:src" content="<?=$NHNTAK->site('anhbia');?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?=$NHNTAK->site('tukhoa');?>">
    <meta name="keywords" content="<?=$NHNTAK->site('mota');?>">
    <meta name="author" content="<?=$NHNTAK->site('tukhoa');?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?=$NHNTAK->site('favicon');?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?=$NHNTAK->site('favicon');?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?=$NHNTAK->site('favicon');?>">
    <script src="<?=BASE_URL('');?>assets/js/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="<?=BASE_URL('')?>template/css/app.css" />
    <!-- CODE ĐƯỢC VIẾT LẠI BỞI NDK Dark | DICHVUWEB.ASIA -->
    <link rel="stylesheet" href="<?=BASE_URL('');?>template/dichvuweb/toastr.min.css" />
    <link rel="stylesheet" href="<?=BASE_URL('');?>template/dichvuweb/ext-component-toastr.css" />
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.bootstrap4.min.css" /> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.bootstrap4.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>
    <script src="https://intercloudnet.asia/assets/css/tabletxx.css"></script>
    <script src="<?=BASE_URL('')?>template/dist/js/loadingoverlay.min.js"></script>
    <!-- CODE ĐƯỢC VIẾT LẠI BỞI NDK Dark | DICHVUWEB.ASIA -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>