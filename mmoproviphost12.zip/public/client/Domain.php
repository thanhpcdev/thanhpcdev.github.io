<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'MUA TÊN MIỀN | '.$NHNTAK->site('mota');
    require_once("../../public/client/Header.php");
    CheckLogin();
?>
<body class="main">
<?php require_once("../../public/client/Sidebar.php");?>
    <?php require_once("../../public/client/Navbar.php");?>
    <div class="wrapper">
        <div class="wrapper-box">
        <?php require_once("../../public/client/SidebarPc.php");?>
        <div class="content">
                <div class="intro-y box flex flex-col lg:flex-row mt-5">
                    <div class="bg w-full mb-5">
                        <div class="flex flex-col sm:flex-row items-center p-5 border-b border-gray-200">
                            <h2 class="font-bold text-2xl mr-auto">
                                Mua Miền
                            </h2>
                        </div>
                        <div class="table-content-2">
                            <div class="py-3 px-4 overflow-x-auto">
                                <div class="preview">
                                    <div class="mt-3">
                                        <label for="regular-form-4" class="form-label">TÊN MIỀN</label>
                                        <input id="domain" type="text" class="form-control" placeholder="VD : dichvuweb">
                                    </div>
                                    <div class="mt-3">
                                        <label for="regular-form-5" class="form-label">ĐUÔI MIỀN</label>
                                        <select class="form-select" id="duoi" aria-label="Default select example">
                                        <option value="">-- Đuôi miền --</option>
                                        <?php foreach($NHNTAK->get_list(" SELECT * FROM `tongdomain` WHERE `status` = 'SHOW' ORDER BY id DESC") as $row){ ?>
                                        <option value="<?=$row['id'];?>">.<?=$row['duoimien'].' - '.format_cash($row['sotien']);?>đ / 1 Năm</option>
                                        <?php } ?>
                                        </select>
                                    </div>
                                    <div class="mt-3">
                                        <label for="regular-form-4" class="form-label">THỜI GIAN</label>
                                        <select class="form-select" value="1" max="10" id="nam">
                                        <option value="">-- Thời Hạn --</option>
                                        <option value="1">1 Năm</option>
                                        <option value="3">3 Năm</option>
                                        <option value="4">4 Năm</option>
                                        <option value="5">5 Năm</option>
                                        <option value="6">6 Năm</option>
                                        <option value="7">7 Năm</option>
                                        <option value="8">8 Năm</option>
                                        <option value="9">9 Năm</option>
                                        <option value="10">10 Năm</option>
                                        </select>
                                    </div>
                                    <div class="mt-3">
                                        <label for="regular-form-4" class="form-label">NAMESERVER</label>
                                        <i>(Khách hàng đã nhập <span id="all_ns">0 NS</span>)</i>
                                        <textarea class="form-control" id="ns" rows="4" placeholder=" fatima.ns.cloudflare.com 
                                    finley.ns.cloudflare.com"></textarea>
                                    </div>
                                </div>
                        </div>
                    </div>
                        <div class="col-span-12 px-4 pt-4">
                            <div class="w-full">
                                <button id="btnMuaDomain" class="cursor-pointer border rounded w-full text-center btn btn-primary inline-block mr-1"> <i class="fa fa-shopping-cart mr-2"></i> Mua Ngay </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-span-12 lg:col-span-12 2xl:col-span-12">
                    <div class="intro-y box mt-5">
                        <div class="flex flex-col sm:flex-row items-center p-5 border-b border-gray-200">
                            <h2 class="font-bold text-2xl mr-auto">
                                Lịch Sử Mua Miền
                            </h2>
                        </div>
                        <div class="p-5">
                            <div class="preview">
                                <div class="overflow-x-auto">
                                    <table class="table table-report w-full">
                                        <thead>
                                            <tr class="text-center">
                                                <th width="5%">STT</th>
                                                <th class="whitespace-nowrap">TÊN MIỀN</th>
                                                <th class="whitespace-nowrap">NĂM MUA</th>
                                                <th class="whitespace-nowrap">TỔNG TIỀN</th>
                                                <th class="whitespace-nowrap">NGÀY MUA</th>
                                                <th class="whitespace-nowrap">NGÀY HẾT HẠN</th>
                                                <th class="whitespace-nowrap">TRẠNG THÁI</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tbody>
                    <?php $i = 1; foreach($NHNTAK->get_list(" SELECT * FROM `hisdomain` WHERE `username` = '".$getUser['username']."' ORDER BY id DESC") as $row){ ?>
                        <tr>
                            <td class="text-center"><?=$i++;?></td>
                            <td class="text-center"><?=$row['domain'];?></td>
                            <td class="text-center"><?=$row['nam'];?> năm</td>
                            <td class="text-center"><?=format_cash($row['tongtien']);?>đ</td>
                            <td class="text-center"><?=format_date($row['timemua']);?></td>
                            <td class="text-center"><?=format_date($row['timedie']);?></td>
                            <td class="text-center"><?=status($row['status']);?></td>
                        </tr>
                    <?php } ?>
                                    </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
        var Noti = function(type, msg) {
            toastr.options = {
                closeButton: true,
                progressBar: true,
                showMethod: 'slideDown',
                timeOut: 1500
            };
            if (type == 2)
                toastr.success(msg, 'Thông báo');
            else
                toastr.error(msg, 'Thông báo');
        };
        $("#btnMuaDomain").on("click", function() {
            var duoi    =       $("#duoi").val();
            var domain  =       $("#domain").val();
            var nam     =       $("#nam").val();
            var ns      =       $("#ns").val();
            $.LoadingOverlay("show");
            $.ajax({
                url: "<?= BASE_URL("assets/ajaxs/Cart.php"); ?>",
                type: "POST",
                dataType: "JSON",
                data: {
                    type: 'MuaDomain',
                    duoi:       $("#duoi").val(),
                    domain:     $("#domain").val(),
                    nam:        $("#nam").val(),
                    ns:         $("#ns").val()
                },
                success: function(response) {
                    $.LoadingOverlay("hide");
                    Noti(response.status, response.msg);
                    if (response.status == 2) {
                        setTimeout(function() {
                            window.location.href = "";
                        }, 1000);
                    } else if (response.status == 1) {
                       $('#btnMuaDomain').html('<i class="fa fa-shopping-cart mr-2"></i> Mua Ngay').prop('disabled', false);
                    }
                }
            });
        });
        setInterval(function(){
var giamien = {
    '': 0,
<?php foreach($NHNTAK->get_list(" SELECT * FROM `tongdomain` WHERE `status` = 'SHOW' ORDER BY id DESC") as $row2){ ?>
    '<?=$row2['id'];?>': <?=$row2['sotien'];?>,
<?php } ?>
} 
var duoi = $("#duoi").val();
var nam = $("#nam").val();
let tongtien = giamien[duoi]*nam;
$('#ketqua').html(tongtien.toString().replace(/(.)(?=(\d{3})+$)/g, '$1,'));
var arrayOfLines = $('textarea[id="ns"]').val().match(/.+/g);
var count = parseFloat(arrayOfLines.length);
$('#all_ns').html(count + ' NS');
    
}, 10);
</script>
<?php
require_once("../../public/client/Footer.php");
?>