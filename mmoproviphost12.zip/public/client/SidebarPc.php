<nav class="side-nav">
    <ul>
        <li>
            <a href="<?=BASE_URL('')?>" class="side-menu">
                <div class="side-menu__icon"> <i data-feather="home"></i> </div>
                <div class="side-menu__title">
                    Trang chủ
                    <div class="side-menu__sub-icon transform rotate-180"> </div>
                </div>
            </a>
        </li>
        <li>
            <a href="#" class="side-menu">
                <div class="side-menu__icon"> <i data-feather="box"></i> </div>
                <div class="side-menu__title">
                    Dịch Vụ Tạo Shop
                    <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                </div>
            </a>
            <ul class="">
                <li>
                    <a href="<?=BASE_URL('create')?>" class="side-menu">
                        <div class="side-menu__icon"> <i data-feather="shopping-cart"></i> </div>
                        <div class="side-menu__title"> Tạo Shop Game</div>
                    </a>
                </li>
                <li>
                    <a href="<?=BASE_URL('list-shop')?>" class="side-menu">
                        <div class="side-menu__icon"> <i data-feather="rotate-ccw"></i> </div>
                        <div class="side-menu__title"> Lịch Sử Tạo Shop </div>
                    </a>
                </li>
            </ul>
        </li>
        <li>
            <a href="#" class="side-menu">
                <div class="side-menu__icon"> <i data-feather="inbox"></i> </div>
                <div class="side-menu__title">
                    Dịch Vụ Tên Miền
                    <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                </div>
            </a>
            <ul class="">
                <li>
                    <a href="<?=BASE_URL('Domain')?>" class="side-menu">
                        <div class="side-menu__icon"> <i data-feather="shopping-cart"></i> </div>
                        <div class="side-menu__title">Mua Domain</div>
                    </a>
                </li>
                <li>
                    <a href="<?=BASE_URL('Whois')?>" class="side-menu">
                        <div class="side-menu__icon"> <i data-feather="rotate-ccw"></i> </div>
                        <div class="side-menu__title"> Check Domain </div>
                    </a>
                </li>
            </ul>
        </li>
        <li>
            <a href="#" class="side-menu">
                <div class="side-menu__icon"> <i data-feather="layers"></i> </div>
                <div class="side-menu__title">
                    Dịch Vụ Source
                    <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                </div>
            </a>
            <ul class="">
                <li>
                    <a href="<?=BASE_URL('View-Source')?>" class="side-menu">
                        <div class="side-menu__icon"> <i data-feather="shopping-cart"></i> </div>
                        <div class="side-menu__title">Mua Source Code</div>
                    </a>
                </li>
                <li>
                    <a href="<?=BASE_URL('History-Source')?>" class="side-menu">
                        <div class="side-menu__icon"> <i data-feather="rotate-ccw"></i> </div>
                        <div class="side-menu__title"> Lịch Sử Mua Source </div>
                    </a>
                </li>
            </ul>
        </li>
        <li>
            
            <a href="<?=$NHNTAK->site('zalo');?>" class="side-menu">
                <div class="side-menu__icon"> <i data-feather="phone-call"></i> </div>
                <div class="side-menu__title">
                    Hỗ Trợ
                    <div class="side-menu__sub-icon transform rotate-180"> </div>
                </div>
            </a>
        </li>
        <li>
            <a href="<?=BASE_URL('user/cart');?>" class="side-menu">
                <div class="side-menu__icon"> <i data-feather="shopping-cart"></i> </div>
                <div class="side-menu__title">Giỏ hàng (<span><?=count($_SESSION['cart']);?></span>)<div class="side-menu__sub-icon transform rotate-180"> </div>
                </div>
            </a>
        </li>
        <div class="side-nav__devider my-6"></div>
        <li>
            <a href="<?=$NHNTAK->site('user/profile')?>" class="side-menu">
                <div class="side-menu__icon"> <i data-feather="users"></i> </div>
                <div class="side-menu__title">
                    Hồ sơ
                    <div class="side-menu__sub-icon transform rotate-180"> </div>
                </div>
            </a>
        </li>
        <li>
            <!-- CODE ĐƯỢC VIẾT LẠI BỞI NDK Dark | DICHVUWEB.ASIA -->
                        <a href="javascript:;" class="side-menu">
                            <div class="side-menu__icon"> <i data-feather="credit-card"></i> </div>
                            <div class="side-menu__title">
                                Nạp tiền
                                <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/recharge/card" class="side-menu">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Thẻ cào </div>
                                </a>
                            </li>
                            <li>
                                <a href="/recharge/bank" class="side-menu">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title">ATM/MOMO </div>
                                </a>
                            </li>
                        </ul>
                    </li>
        <?php if(isset($_SESSION['username']) && $getUser['level'] == 'admin') { ?>
        <div class="side-nav__devider my-6"></div>
        <li>
            <a href="<?=BASE_URL('Admin/Home')?>" class="side-menu">
                <div class="side-menu__icon"> <i data-feather="codesandbox"></i> </div>
                <div class="side-menu__title">
                    ADMIN PANEL
                </div>
            </a>
        </li>
        <?php }?>
    </ul>
</nav>