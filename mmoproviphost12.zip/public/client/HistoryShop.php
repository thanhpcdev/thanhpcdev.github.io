<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'QUẢN LÝ SHOP | '.$NHNTAK->site('mota');
    require_once("../../public/client/Header.php");
    CheckLogin();
?>
<body class="main">
<?php require_once("../../public/client/Sidebar.php");?>
    <?php require_once("../../public/client/Navbar.php");?>
    <div class="wrapper">
        <div class="wrapper-box">
        <?php require_once("../../public/client/SidebarPc.php");?>
        <div class="content">
                <div class="col-span-12 lg:col-span-12 2xl:col-span-12">
                    <!-- BEGIN: Bordered Table -->
                    <div class="intro-y box mt-5">
                        <div class="flex flex-col sm:flex-row items-center p-5 border-b border-gray-200">
                            <h2 class="font-bold text-2xl mr-auto">
                                Lịch Sử Tạo Shop
                            </h2>
                        </div>
                        <div class="p-5">
                            <div class="preview">
                                <div class="overflow-x-auto">
                                    <table class="table table-report w-full">
                                        <thead>
                                            <tr>
                                                <th width="0%">STT</th>
                                                <th class="whitespace-nowrap">MẪU SHOP</th>
                                                <th class="whitespace-nowrap">TÀI KHOẢN</th>
                                                <th class="whitespace-nowrap">MẬT KHẨU</th>
                                                <th class="whitespace-nowrap">TÊN MIỀN</th>
                                                <th class="whitespace-nowrap">SỐ TIỀN</th>
                                                <th class="whitespace-nowrap">THỜI GIAN TẠO</th>
                                                <th class="whitespace-nowrap">TRẠNG THÁI</th>
                                                <th class="whitespace-nowrap">THỜI HẠN</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tbody>
                                    <?php $i = 1; foreach($NHNTAK->get_list(" SELECT * FROM `history_shop` WHERE `username` = '".$getUser['username']."' ORDER BY id DESC") as $row){ ?>
                                <tr>
                            <td class="text-center"><?=$i++;?></td>
                            <td class="text-center"><?=$row['title'];?></td>
                            <td class="text-center"><?=$row['tkadmin'];?></td>
                            <td class="text-center"><?=$row['mkadmin'];?></td>
                            <td class="text-center"><?=$row['domain'];?></td>
                            <td class="text-center"><?=format_cash($row['moneycreate']);?>đ</td>
                            <td class="text-center"><?=$row['create_date'];?></td>
                            <td class="text-center"><?=status($row['status']);?></td>
                            <td class="text-center"><?=$row['timeCreate'];?></td>
                        </tr>
                    <?php } ?>
                                    </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php
require_once("../../public/client/Footer.php");
?>