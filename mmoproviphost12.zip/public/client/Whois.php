<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'KIỂM TRA TÊN MỀN | '.$NHNTAK->site('mota');
    require_once("../../public/client/Header.php");
    CheckLogin();
?>
<body class="main">
<?php require_once("../../public/client/Sidebar.php");?>
    <?php require_once("../../public/client/Navbar.php");?>
    <div class="wrapper">
        <div class="wrapper-box">
        <?php require_once("../../public/client/SidebarPc.php");?>
        
<div class="content">
                <!-- CODE ĐƯỢC VIẾT LẠI BỞI NDK Dark | DICHVUWEB.ASIA -->
                <div class="intro-y box flex flex-col lg:flex-row mt-5">
                    <div class="bg w-full mb-5">
                    <div class="flex flex-col sm:flex-row items-center p-5 border-b border-gray-200">
                            <h2 class="font-bold text-2xl mr-auto">
                                Kiểm Tra Tên Miền
                            </h2>
                        </div>

                        <div class="table-content-2">
                            <!-- CODE ĐƯỢC VIẾT LẠI BỞI NDK Dark | DICHVUWEB.ASIA -->
                            <div class="py-3 px-4 overflow-x-auto">
                                <div class="preview">
                                    <div class="mt-3">
                                        <label for="regular-form-4" class="form-label">NHẬP MIỀN</label>
                                        <input name="domain" id="domain" type="text" class="form-control" placeholder="VD : ndkdark.com">
                                    </div>
                                </div>
                                <p style="padding-top: 20px;color: #c84b4b;font-size: 15px;font-weight: 600;" color="red">(*) Nhập Tên Miền Bạn Muốn Kiểm Tra</p>
                            </div>
                        </div>
                        <div class="col-span-12 px-4 pt-3">
                            <div class="w-full">
                                <button type="submit" id='btnwhois' class="cursor-pointer border rounded w-full text-center btn btn-primary inline-block mr-1">Kiểm Tra </button>
                            </div>
                        </div>
                    </div>
                    <script>
        var Noti = function(type, msg) {
            toastr.options = {
                closeButton: true,
                progressBar: true,
                showMethod: 'slideDown',
                timeOut: 1500
            };
            if (type == 2)
                toastr.success(msg, 'Thông báo');
            else
                toastr.error(msg, 'Thông báo');
        };
        $("#btnwhois").on("click", function() {
            $.LoadingOverlay("show");
            $.ajax({
                url: "<?= BASE_URL("assets/ajaxs/whoisdomain.php"); ?>",
                type: "POST",
                dataType: "JSON",
                data: {
                    type: 'Kiemtradomain', // NGUỒN BY NDK Dark
                    domain: $("#domain").val()
                },
                success: function(response) {
                    $.LoadingOverlay("hide");
                    Noti(response.status, response.msg);
                    if (response.status == 2) {
                    } else if (response.status == 1) {
                    }
                    $('#btnwhois').html('Kiểm Tra ').prop('disabled', false);
                }
            })
        });
    </script>
     </div>
      </div>
       </div>
       
<!-- CODE ĐƯỢC VIẾT LẠI BỞI NDK Dark | DICHVUWEB.ASIA -->
<?php
    require_once("../../public/client/Footer.php");
?>