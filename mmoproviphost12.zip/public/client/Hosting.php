<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'MUA SOURCE CODE | '.$NHNTAK->site('mota');
    require_once("../../public/client/Header.php");
    if(empty($_GET['hosting']))
    {
        $_GET['hosting'] = $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `status` = 'SHOW' AND `loai` = 'hosting'")['nameGetServer'];
    }
    $datarow = $NHNTAK->get_row(" SELECT * FROM `serverhost` WHERE `nameGetServer` = '".$_GET['hosting']."' AND `status` = 'SHOW' AND `loai` = 'hosting'");
    CheckLogin();
?>
<body class="">
<?php require_once("../../public/client/Sidebar.php");?>
    <?php require_once("../../public/client/Navbar.php");?>
    <div class="wrapper">
        <div class="wrapper-box">
        <?php require_once("../../public/client/SidebarPc.php");?>
        <div class="content">
                <div class="grid grid-cols-12 gap-7">
                    <div class="col-span-12 2xl:col-span-12">
                                       
                                        <?php foreach($NHNTAK->get_list(" SELECT * FROM `serverhost` WHERE `status` = 'SHOW' AND `loai` = 'hosting' ORDER BY id ASC ") as $row){ 
                        if($NHNTAK->num_rows(" SELECT * FROM `goihost` WHERE `serverhost` = '".$row['nameGetServer']."'") >= 1) {
                            ?>
                        <span class="h5 fw-normal me-4 mt-2">
                            <?php if($_GET['hosting'] == $row['nameGetServer'])
                            {
                                $active = 'active';
                            }
                            else
                            {
                                $active = '';
                            }
                            ?>
                            <a class="btn btn-pill btn-outline-success <?=$active;?>" href="<?=BASE_URL('host/'.$row['nameGetServer']);?>"><?=$row['nameServer'];?></a>
                        </span>
                        <?php } }?>
                                    </div>
                                </div>
                                
                     
                   
                   <div class="grid grid-cols-12 gap-6 mt-5">
<?php foreach($NHNTAK->get_list(" SELECT * FROM `goihost` WHERE `serverhost` = '".$_GET['hosting']."' AND `status` = 'SHOW' AND `loai` = 'hosting' ORDER BY id ASC ") as $row2){ ?>
    
  <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y">
    <div class="report-box zoom-in h-full">
      <div class="box p-5 h-full flex flex-col justify-between">
        <div class="flex flex-col items-center text-center">
          <img src="https://vhost.vn/wp-content/uploads/2016/08/cpanel-logo.png" alt="cPanel Logo" class="w-40 h-auto mb-4">
          <h4 class="text-xl font-bold text-center mb-4"><?= strtoupper($row2['nameGoi']); ?></h4>

          <ul class="text-sm text-gray-700 space-y-1">
            <li><span class="font-semibold text-red-600">Anti Ddos:</span> Có</li>
            <li><span class="font-semibold">Dung Lượng:</span> <?= strtoupper($row2['dungluong']); ?> MB</li>
            <li><span class="font-semibold">Băng Thông:</span> <?= strtoupper($row2['bangthong']); ?> MB</li>
            <li><span class="font-semibold text-blue-600">Miễn Phí Chứng Chỉ SSL</span></li>
            <li><span class="font-semibold">Miền Khác:</span> <?= strtoupper($row2['mienkhac']); ?></li>
            <li><span class="font-semibold">Miền Bí Danh:</span> <?= strtoupper($row2['mienbidanh']); ?></li>
            <li><span class="font-semibold">Backup:</span> Có</li>
          </ul>
        </div>

        <div class="mt-4 text-center">
          <button class=" btn-primary w-full mb-2"><?= strtoupper($row2['money']); ?>đ / 1 Tháng</button>
          <a href="/Buy-Hosting/<?= $row2['id']; ?>" class="btn btn-primary w-full">MUA NGAY</a>
        </div>
      </div>
    </div>
  </div>

<?php }?>
</div>


       
                
<?php
require_once("../../public/client/Footer.php");
?>