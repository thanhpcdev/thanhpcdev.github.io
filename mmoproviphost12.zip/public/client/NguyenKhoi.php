<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    require_once("../../config/giohang.php");
    $title = 'QUẢN LÝ CODE | '.$NHNTAK->site('mota');
    require_once("../../public/client/Header.php");
    CheckLogin();
    $Cart = new Cart();
?>
<?php
if (isset($_GET['remove'])) {
        unset($_SESSION['cart'][$_GET['remove']]);
        $_SESSION['cart'] = array_values($_SESSION['cart']);
        die('<script type="text/javascript">if(!alert("Xóa sản phẩm thành công!")){window.history.back().location.reload();}</script>');
}
if (isset($_GET['delete'])) {
unset($_SESSION['cart']);
session_regenerate_id(true);
die('<script type="text/javascript">if(!alert("Xóa giỏ hàng thành công!")){window.history.back().location.reload();}</script>');
}
?>
<body class="main">
<?php require_once("../../public/client/Sidebar.php");?>
    <?php require_once("../../public/client/Navbar.php");?>
    <div class="wrapper">
        <div class="wrapper-box">
        <?php require_once("../../public/client/SidebarPc.php");?>
        <div class="content">
                <div class="col-span-12 lg:col-span-12 2xl:col-span-12">
                    <!-- BEGIN: Bordered Table -->
                    <div class="intro-y box mt-5">
                        <div class="flex flex-col sm:flex-row items-center p-5 border-b border-gray-200">
                            <h2 class="font-bold text-2xl mr-auto">
                                Giỏ hàng
                            </h2>
                            <button type="button" id="TraTien" class="btn btn-primary btn-sm">PAYMENTS</button> - <button type="button" type="?delete<?=$id;?>" class="btn btn-danger btn-sm">DELETE ALL</button>
                        </div>
                        <div class="p-5">
                            <div class="preview">
                                <div class="overflow-x-auto">
                                    <?php if (count($_SESSION['cart']) == 0) { ?>
                            <tr>
                            </tr>
                    <?php } ?>
                    
                                    <table class="table table-report w-full">
                                        <thead>
                                            <tr>
                                                <th width="10%">TÊN CODE</th>
                                                <th width="10%">GIÁ TIỀN</th>
                                                <th width="10%">ẢNH MẪU</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (isset($_SESSION['cart'])) {
foreach ($_SESSION['cart'] as $id => $item) {
?>
<td class="text-center"><?=$item['name'];?></td>
<td class="text-center"><?=number_format($item['price']);?>đ</td>
<td><img class="text-center" width="60%" src="<?=$item['image'];?>"></td>
                                    </tbody>
                                    <?php }} ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
        var Noti = function(type, msg) {
            toastr.options = {
                closeButton: true,
                progressBar: true,
                showMethod: 'slideDown',
                timeOut: 1500
            };
            if (type == 2)
                toastr.success(msg, 'Thông báo');
            else
                toastr.error(msg, 'Thông báo');
        };
        $("#TraTien").on("click", function() {
            $.LoadingOverlay("show");
            $.ajax({
                url: "<?= BASE_URL("assets/ajaxs/Giohang-Payment.php"); ?>",
                type: "POST",
                dataType: "JSON",
                data: {
                    type: "payments" // BY NGUYỄN KHÔI - JTECHMMO.TECH
                },
                success: function(response) {
                    $.LoadingOverlay("hide");
                    Noti(response.status, response.msg);
                    if (response.status == 2) {
                        setTimeout(function() {
                            window.location.href = "";
                        }, 1000);
                    } else if (response.status == 1) {
                       $('#TraTien').html('PAYMENTS').prop('disabled', false);
                    }
                }
            });
        });
    </script>
<?php
require_once("../../public/client/Footer.php");
?>