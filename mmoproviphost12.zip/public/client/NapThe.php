<?php
    require_once("../../config/config.php");
    require_once("../../config/function.php");
    $title = 'NẠP THẺ CÀO | '.$NHNTAK->site('mota');
    require_once("../../public/client/Header.php");
    CheckLogin();
?>
<body class="main">
<?php require_once("../../public/client/Sidebar.php");?>
    <?php require_once("../../public/client/Navbar.php");?>
    <div class="wrapper">
        <div class="wrapper-box">
        <?php require_once("../../public/client/SidebarPc.php");?>

        <div class="content">

                <div class="col-span-12 lg:col-span-12 2xl:col-span-12">
                    <div class="intro-y box mt-5">
                        <div class="flex flex-col sm:flex-row items-center p-5 border-b border-gray-200">
                            <h2 class="font-bold text-2xl mr-auto">
                                Nạp thẻ cào
                            </h2>
                        </div>
                        <form method="POST">
                            <div class="row p-5">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="card_type" class="form-label">Loại thẻ</label>
                                        <select class="form-control" id="loaithe">
                                            <option value="">-- Chọn loại thẻ --</option>
                                            <option value="VIETTEL">Viettel</option>
                                            <option value="VINAPHONE">Vinaphone</option>
                                            <option value="MOBIFONE">Mobifone</option>
                                            <option value="VNMOBI">Vietnamobile</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- CODE ĐƯỢC VIẾT LẠI BỞI NDK Dark | DICHVUWEB.ASIA -->
                                <div class="col-md-3 mt-2">
                                    <div class="form-group">
                                        <label for="card_price" class="form-label">Mệnh giá</label>
                                        <select class="form-control" onchange="totalPrice()" id="menhgia">
                                            <option value="">-- Chọn mệnh giá --</option>
                                            <option value="10000">10.000đ</option>
                                            <option value="20000">20.000đ</option>
                                            <option value="30000">30.000đ</option>
                                            <option value="50000">50.000đ</option>
                                            <option value="100000">100.000đ</option>
                                            <option value="200000">200.000đ</option>
                                            <option value="300000">300.000đ</option>
                                            <option value="500000">500.000đ</option>
                                            <option value="1000000">1.000.000đ</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3 mt-2">
                                    <div class="form-group">
                                        <label for="pin" class="form-label">Mã thẻ</label>
                                        <input type="text" id="pin" class="form-control" placeholder="Nhập mã thẻ" />
                                    </div>
                                </div>
                                <div class="col-md-3 mt-2">
                                    <div class="form-group">
                                        <label for="pin" class="form-label">Số seri</label>
                                        <input type="text" id="seri" class="form-control" placeholder="Nhập số seri" />
                                    </div>
                                </div>
                                 <div class="form-group text-center p-5">
                                <div class="alert alert-info alert-dismissible alert-outline fade show" role="alert">
                                    Số tiền thực nhận : <b id="ketqua" style="color: red;">0</b> VNĐ
                                </div>
                            </div>
                            <div class="flex justify-center">
                            <centre>
                            <div class="form-group p-5 flex justify-end">
                            <button type="button" id="btnNapthe" class="btn btn-primary btn-block btn-lg">Nạp Ngay</button>
                            </div>
                            </div>
</centre>
                        </form>
                    </div>
                </div>

                <div class="col-span-12 lg:col-span-12 2xl:col-span-12">
                    <!-- CODE ĐƯỢC VIẾT LẠI BỞI NDK Dark | DICHVUWEB.ASIA -->
                    <div class="intro-y box mt-5">
                        <div class="flex flex-col sm:flex-row items-center p-5 border-b border-gray-200">
                            <h2 class="font-bold text-2xl mr-auto">
                            Lịch sử nạp thẻ cào
                            </h2>
                        </div>
                        <div class="p-5">
                            <div class="preview">
                                <div class="overflow-x-auto">
                                    <table class="table table-report w-full" id="mytable">
                                        <thead>
                                            <tr class="text-center">
                                                <th width="5%">STT</th>
                                                <th class="whitespace-nowrap">Loại Thẻ</th>
                                                <th class="whitespace-nowrap">Mã Thẻ</th>
                                                <th class="whitespace-nowrap">Seri</th>
                                                <th class="whitespace-nowrap">Mệnh Giá</th>
                                                <th class="whitespace-nowrap">Thực Nhận</th>
                                                <th class="whitespace-nowrap">Trạng Thái</th>
                                                <th class="whitespace-nowrap">Thời Gian</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $i = 1; foreach($NHNTAK->get_list(" SELECT * FROM `cards` WHERE `username` = '".$getUser['username']."' ORDER BY id DESC LIMIT 30") as $row){ ?>
                        <tr>
                            <td class="text-center"><?=$i++;?></td>
                            <td class="text-center"><?=$row['loaithe'];?></td>
                            <td class="text-center"><?=$row['pin'];?></td>
                            <td class="text-center"><?=$row['seri'];?></td>
                            <td class="text-center"><?=format_cash($row['menhgia']);?>đ</td>
                            <td class="text-center"><?=format_cash($row['thucnhan']);?>đ</td>
                            <td class="text-center"><?=status($row['status']);?></td>
                            <td class="text-center"><?=$row['thoigian'];?></td>
                        </tr>
                    <?php } ?>                                       
                                 </tbody>
                                 </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- CODE ĐƯỢC VIẾT LẠI BỞI NDK Dark | DICHVUWEB.ASIA -->
            </div>
        </div>
    </div>
    </div>
    <script>
        function totalPrice() {
            var total = 0;
            var amount = $("#menhgia").val();
            total = amount - amount * <?=$NHNTAK->site('ckcard');?> / 100;
            $('#ketqua').html(total.toString().replace(/(.)(?=(\d{3})+$)/g, '$1.'));
        }
    </script>
    <script>
        var Noti = function(type, msg) {
            toastr.options = {
                closeButton: true,
                progressBar: true,
                showMethod: 'slideDown',
                timeOut: 1500
            };
            if (type == 2)
                toastr.success(msg, 'Thông báo');
            else
                toastr.error(msg, 'Thông báo');
        };
        $("#btnNapthe").on("click", function() {
            var seri      = $("#seri").val();
            var pin       = $("#pin").val();
            var loaithe   = $("#loaithe").val();
            var menhgia   = $("#menhgia").val();
            $.LoadingOverlay("show");
            $.ajax({
                type: "POST",
                dataType: "JSON",
                url: "<?= BASE_URL("assets/ajaxs/NapThe.php"); ?>",
                data: {
                    type: 'Ntcao',
                    seri:       $("#seri").val(),
                    pin:        $("#pin").val(),
                    loaithe:    $("#loaithe").val(),
                    menhgia:    $("#menhgia").val()
                },
                success: function(res) {
                    $.LoadingOverlay("hide");
                    Noti(res.status, res.msg);
                    if (res.status == 2) {
                        setTimeout(function() {
                            window.location.href = ""; // nguồn by NDK Dark
                        }, 2000);
                      } else if (res.status == 1) {
                        $('#btnNapthe').html('Nạp Ngay').prop('disabled', false);
                    }
                }
            });
        });
    </script>
    <script>
    $(document).ready(function() {
        $('#mytable').DataTable();
    });
    </script>
    <?php
    require_once("../../public/client/Footer.php");
    ?>