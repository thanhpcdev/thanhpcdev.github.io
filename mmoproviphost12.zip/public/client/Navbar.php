<div class="top-bar-boxed border-b border-theme-2 -mt-7 md:-mt-5 -mx-3 sm:-mx-8 px-3 sm:px-8 md:pt-0 mb-12">
    <div class="h-full flex items-center">
        <!-- BEGIN: Logo -->
        <a href="<?=BASE_URL('')?>" class="-intro-x hidden md:flex">
        <img alt="" class="w-6" src="<?=$NHNTAK->site('logo');?>" style="width: 20% ; hight: 20% ">
        <div class="-intro-x breadcrumb mr-auto"> <a href="/">Trang chủ</a> <i data-feather="chevron-right"
                class="breadcrumb__icon"></i> <a href="" class="breadcrumb--active">Application </a> </div>

        <div class="intro-x dropdown w-8 h-8">
            <div class="dropdown-toggle w-8 h-8 rounded-full overflow-hidden shadow-lg image-fit zoom-in scale-110"
                role="button" aria-expanded="false">
                <img alt="Thông tin tài khoản" src="https://i.imgur.com/VlndPPv.jpg">
            </div>
            <div class="dropdown-menu w-56">
                <div class="dropdown-menu__content box bg-theme-11 dark:bg-dark-6 text-white">
                    <div class="p-4 border-b border-theme-12 dark:border-dark-3">
                        <div class="font-medium">Xin chào: <?=$getUser['username']?></div>
                    </div>
                    <div class="p-2">
                        <a href="<?=BASE_URL('user/profile')?>"
                            class="flex items-center block p-2 transition duration-300 ease-in-out hover:bg-theme-1 dark:hover:bg-dark-3 rounded-md">
                            <i data-feather="user" class="w-4 h-4 mr-2"></i> Thông tin tài khoản </a>
                        <a href="<?=BASE_URL('recharge/bank')?>"
                            class="flex items-center block p-2 transition duration-300 ease-in-out hover:bg-theme-1 dark:hover:bg-dark-3 rounded-md">
                            <i data-feather="edit" class="w-4 h-4 mr-2"></i> Nạp tiền </a>
                    </div>
                    <div class="p-2 border-t border-theme-12 dark:border-dark-3">
                        <a href="<?=BASE_URL('Auth/Logout')?>"
                            class="flex items-center block p-2 transition duration-300 ease-in-out hover:bg-theme-1 dark:hover:bg-dark-3 rounded-md">
                            <i data-feather="toggle-right" class="w-4 h-4 mr-2"></i> Đăng xuất </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- END: Account Menu -->
    </div>
</div>